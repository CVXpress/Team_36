#!/usr/bin/env python3
"""
Render Deploy Fix Finale con Owner ID Corretto

Fix deploy Render con ownerID corretto: tea-d2k58um3jp1c73fr2vr0
"""

import asyncio
import json
import time
import httpx
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def fix_render_deploy_with_correct_owner():
    """Fix deploy Render con ownerID corretto."""
    logger.info("🔧 Fix Deploy Render con Owner ID Corretto")
    
    # Configurazione corretta
    render_api_key = "rnd_3zUfxJUXfFLeP5CyVmCxv9ppypPF"
    mistral_api_key = "gJ200l66zgUiRZcUji9Sbr0bz8H8ALwz"
    correct_owner_id = "tea-d2k58um3jp1c73fr2vr0"  # Owner ID corretto
    
    headers = {
        "Authorization": f"Bearer {render_api_key}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    
    # Payload con ownerID corretto
    payload = {
        "ownerId": correct_owner_id,
        "name": "mistral-agents-dashboard",
        "type": "web_service",
        "repo": "https://github.com/Team_36/mistral-agents-dashboard.git",
        "branch": "main",
        "buildCommand": "pip install -r requirements.txt",
        "startCommand": "gunicorn --bind 0.0.0.0:$PORT app:app",
        "envVars": [
            {
                "key": "MISTRAL_API_KEY",
                "value": mistral_api_key
            }
        ]
    }
    
    logger.info(f"🔑 Owner ID Corretto: {correct_owner_id}")
    logger.info("🚀 Creazione servizio con owner ID corretto...")
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                "https://api.render.com/v1/services",
                headers=headers,
                json=payload
            )
            
            if response.status_code == 201:
                data = response.json()
                service_id = data.get("id")
                
                logger.info(f"✅ Servizio creato con successo!")
                logger.info(f"   Service ID: {service_id}")
                logger.info(f"   Nome: {data.get('name')}")
                logger.info(f"   URL: {data.get('serviceDetails', {}).get('url', 'N/A')}")
                
                # Salva risultato
                result = {
                    "status": "success",
                    "service_id": service_id,
                    "service_data": data,
                    "owner_id_used": correct_owner_id,
                    "timestamp": datetime.now().isoformat()
                }
                
                with open('render_deploy_success.json', 'w') as f:
                    json.dump(result, f, indent=2)
                
                return result
            
            else:
                error_data = response.json() if response.headers.get('content-type', '').startswith('application/json') else {}
                logger.error(f"❌ Errore {response.status_code}: {error_data}")
                
                result = {
                    "status": "failed",
                    "error_code": response.status_code,
                    "error_data": error_data,
                    "owner_id_used": correct_owner_id,
                    "timestamp": datetime.now().isoformat()
                }
                
                with open('render_deploy_error.json', 'w') as f:
                    json.dump(result, f, indent=2)
                
                return result
    
    except Exception as e:
        logger.error(f"❌ Exception: {e}")
        
        result = {
            "status": "exception",
            "error": str(e),
            "owner_id_used": correct_owner_id,
            "timestamp": datetime.now().isoformat()
        }
        
        with open('render_deploy_exception.json', 'w') as f:
            json.dump(result, f, indent=2)
        
        return result

async def main():
    """Main function."""
    print("🔧 Fix Deploy Render con Owner ID Corretto")
    print("=" * 50)
    
    result = await fix_render_deploy_with_correct_owner()
    
    print("\n📊 RISULTATO:")
    print(f"Status: {result['status']}")
    if result['status'] == 'success':
        print(f"✅ Service ID: {result['service_id']}")
        print("✅ Deploy riuscito con owner ID corretto!")
    else:
        print(f"❌ Errore: {result.get('error_data', result.get('error', 'Unknown'))}")
    
    return result

if __name__ == "__main__":
    asyncio.run(main())

