"""
Mobile App Deployer

Sistema automatico per deployment di app mobile su Google Play Store
e Apple App Store con build automation e CI/CD.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import json
import os
import subprocess
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
import logging
from pathlib import Path
import zipfile
import shutil


class MobilePlatform(Enum):
    """Piattaforme mobile supportate."""
    ANDROID = "android"
    IOS = "ios"
    BOTH = "both"


class AppFramework(Enum):
    """Framework app supportati."""
    REACT_NATIVE = "react_native"
    FLUTTER = "flutter"
    NATIVE_ANDROID = "native_android"
    NATIVE_IOS = "native_ios"
    IONIC = "ionic"
    XAMARIN = "xamarin"


class BuildType(Enum):
    """Tipi di build."""
    DEBUG = "debug"
    RELEASE = "release"
    STAGING = "staging"


@dataclass
class MobileAppConfig:
    """Configurazione app mobile."""
    app_name: str
    package_name: str  # com.example.app
    version: str
    build_number: int
    framework: AppFramework
    platforms: List[MobilePlatform]
    
    # App Store metadata
    display_name: str = ""
    description: str = ""
    keywords: List[str] = field(default_factory=list)
    category: str = "productivity"
    
    # Build configuration
    build_type: BuildType = BuildType.RELEASE
    signing_config: Dict[str, str] = field(default_factory=dict)
    
    # Store configuration
    google_play_config: Dict[str, Any] = field(default_factory=dict)
    app_store_config: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.display_name:
            self.display_name = self.app_name


@dataclass
class MobileDeploymentResult:
    """Risultato deployment mobile."""
    success: bool
    platform: MobilePlatform
    build_path: str
    deployment_time: float
    store_url: Optional[str] = None
    build_logs: List[str] = field(default_factory=list)
    error_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'platform': self.platform.value,
            'build_path': self.build_path,
            'deployment_time': self.deployment_time,
            'store_url': self.store_url,
            'build_logs': self.build_logs,
            'error_message': self.error_message
        }


class MobileAppDeployer:
    """
    Deployer automatico per app mobile.
    
    Features:
    - Build automatico per Android e iOS
    - Deployment su Google Play Store e App Store
    - Supporto React Native, Flutter, Native
    - Code signing automatico
    - Metadata management
    - CI/CD integration
    """
    
    def __init__(self, project_root: str):
        """
        Inizializza mobile deployer.
        
        Args:
            project_root: Directory root del progetto mobile
        """
        self.project_root = Path(project_root)
        self.logger = logging.getLogger(__name__)
        
        # Build tools paths
        self.build_tools = {
            'android_sdk': os.environ.get('ANDROID_SDK_ROOT', '/opt/android-sdk'),
            'flutter_sdk': os.environ.get('FLUTTER_ROOT', '/opt/flutter'),
            'xcode_path': '/Applications/Xcode.app',
            'fastlane': 'fastlane'
        }
        
        # Deployment configurations
        self.deployment_configs: Dict[str, MobileAppConfig] = {}
        self.active_deployments: Dict[str, Dict[str, Any]] = {}
        
        # Metriche deployment
        self.deployment_metrics = {
            'total_builds': 0,
            'successful_builds': 0,
            'failed_builds': 0,
            'average_build_time': 0.0,
            'platforms_built': {},
            'frameworks_used': {}
        }
    
    async def build_app(
        self,
        config: MobileAppConfig,
        source_path: str = None
    ) -> Dict[MobilePlatform, MobileDeploymentResult]:
        """
        Builda app per le piattaforme specificate.
        
        Args:
            config: Configurazione app
            source_path: Path sorgenti (default: project_root)
            
        Returns:
            Risultati build per ogni piattaforma
        """
        if source_path is None:
            source_path = str(self.project_root)
        
        self.logger.info(f"Build app {config.app_name} per {len(config.platforms)} piattaforme")
        
        results = {}
        
        for platform in config.platforms:
            start_time = time.time()
            
            try:
                if platform == MobilePlatform.ANDROID:
                    result = await self._build_android(config, source_path)
                elif platform == MobilePlatform.IOS:
                    result = await self._build_ios(config, source_path)
                else:
                    raise ValueError(f"Piattaforma {platform} non supportata")
                
                # Aggiorna metriche
                build_time = time.time() - start_time
                result.deployment_time = build_time
                self._update_build_metrics(platform, config.framework, build_time, result.success)
                
                results[platform] = result
                
            except Exception as e:
                build_time = time.time() - start_time
                self._update_build_metrics(platform, config.framework, build_time, False)
                
                results[platform] = MobileDeploymentResult(
                    success=False,
                    platform=platform,
                    build_path="",
                    deployment_time=build_time,
                    error_message=str(e)
                )
        
        return results
    
    async def _build_android(self, config: MobileAppConfig, source_path: str) -> MobileDeploymentResult:
        """Build per Android."""
        
        logs = []
        
        try:
            if config.framework == AppFramework.REACT_NATIVE:
                result = await self._build_react_native_android(config, source_path, logs)
            elif config.framework == AppFramework.FLUTTER:
                result = await self._build_flutter_android(config, source_path, logs)
            elif config.framework == AppFramework.NATIVE_ANDROID:
                result = await self._build_native_android(config, source_path, logs)
            else:
                raise ValueError(f"Framework {config.framework} non supportato per Android")
            
            return result
            
        except Exception as e:
            return MobileDeploymentResult(
                success=False,
                platform=MobilePlatform.ANDROID,
                build_path="",
                deployment_time=0.0,
                build_logs=logs,
                error_message=str(e)
            )
    
    async def _build_react_native_android(
        self,
        config: MobileAppConfig,
        source_path: str,
        logs: List[str]
    ) -> MobileDeploymentResult:
        """Build React Native per Android."""
        
        # Prepara ambiente React Native
        await self._prepare_react_native_environment(config, source_path)
        
        # Install dependencies
        result = await self._run_command("npm install", cwd=source_path)
        if result.returncode != 0:
            raise RuntimeError("npm install fallito")
        logs.append("Dependencies installate")
        
        # Build Android
        build_cmd = "npx react-native build-android --mode=release" if config.build_type == BuildType.RELEASE else "npx react-native build-android"
        result = await self._run_command(build_cmd, cwd=source_path)
        
        if result.returncode != 0:
            # Fallback con gradlew
            gradle_cmd = "./android/gradlew assembleRelease" if config.build_type == BuildType.RELEASE else "./android/gradlew assembleDebug"
            result = await self._run_command(gradle_cmd, cwd=source_path)
        
        if result.returncode == 0:
            logs.append("Build Android completato")
            
            # Trova APK generato
            apk_path = self._find_generated_apk(source_path, config.build_type)
            
            return MobileDeploymentResult(
                success=True,
                platform=MobilePlatform.ANDROID,
                build_path=apk_path,
                deployment_time=0.0,
                build_logs=logs
            )
        else:
            raise RuntimeError("Build Android fallito")
    
    async def _build_flutter_android(
        self,
        config: MobileAppConfig,
        source_path: str,
        logs: List[str]
    ) -> MobileDeploymentResult:
        """Build Flutter per Android."""
        
        # Verifica Flutter
        result = await self._run_command("flutter --version")
        if result.returncode != 0:
            raise RuntimeError("Flutter non installato")
        
        # Flutter pub get
        result = await self._run_command("flutter pub get", cwd=source_path)
        if result.returncode != 0:
            raise RuntimeError("flutter pub get fallito")
        logs.append("Flutter dependencies installate")
        
        # Build APK
        build_cmd = "flutter build apk --release" if config.build_type == BuildType.RELEASE else "flutter build apk --debug"
        result = await self._run_command(build_cmd, cwd=source_path)
        
        if result.returncode == 0:
            logs.append("Build Flutter Android completato")
            
            # Path APK Flutter
            apk_name = "app-release.apk" if config.build_type == BuildType.RELEASE else "app-debug.apk"
            apk_path = os.path.join(source_path, "build", "app", "outputs", "flutter-apk", apk_name)
            
            return MobileDeploymentResult(
                success=True,
                platform=MobilePlatform.ANDROID,
                build_path=apk_path,
                deployment_time=0.0,
                build_logs=logs
            )
        else:
            raise RuntimeError("Build Flutter Android fallito")
    
    async def _build_native_android(
        self,
        config: MobileAppConfig,
        source_path: str,
        logs: List[str]
    ) -> MobileDeploymentResult:
        """Build Android nativo."""
        
        # Verifica Android SDK
        if not os.path.exists(self.build_tools['android_sdk']):
            raise RuntimeError("Android SDK non trovato")
        
        # Build con Gradle
        gradle_cmd = "./gradlew assembleRelease" if config.build_type == BuildType.RELEASE else "./gradlew assembleDebug"
        result = await self._run_command(gradle_cmd, cwd=source_path)
        
        if result.returncode == 0:
            logs.append("Build Android nativo completato")
            
            # Trova APK generato
            apk_path = self._find_generated_apk(source_path, config.build_type)
            
            return MobileDeploymentResult(
                success=True,
                platform=MobilePlatform.ANDROID,
                build_path=apk_path,
                deployment_time=0.0,
                build_logs=logs
            )
        else:
            raise RuntimeError("Build Android nativo fallito")
    
    async def _build_ios(self, config: MobileAppConfig, source_path: str) -> MobileDeploymentResult:
        """Build per iOS."""
        
        logs = []
        
        try:
            # Verifica macOS
            import platform
            if platform.system() != "Darwin":
                raise RuntimeError("Build iOS richiede macOS")
            
            # Verifica Xcode
            if not os.path.exists(self.build_tools['xcode_path']):
                raise RuntimeError("Xcode non installato")
            
            if config.framework == AppFramework.REACT_NATIVE:
                result = await self._build_react_native_ios(config, source_path, logs)
            elif config.framework == AppFramework.FLUTTER:
                result = await self._build_flutter_ios(config, source_path, logs)
            elif config.framework == AppFramework.NATIVE_IOS:
                result = await self._build_native_ios(config, source_path, logs)
            else:
                raise ValueError(f"Framework {config.framework} non supportato per iOS")
            
            return result
            
        except Exception as e:
            return MobileDeploymentResult(
                success=False,
                platform=MobilePlatform.IOS,
                build_path="",
                deployment_time=0.0,
                build_logs=logs,
                error_message=str(e)
            )
    
    async def _build_react_native_ios(
        self,
        config: MobileAppConfig,
        source_path: str,
        logs: List[str]
    ) -> MobileDeploymentResult:
        """Build React Native per iOS."""
        
        # Install pods
        result = await self._run_command("cd ios && pod install", cwd=source_path)
        if result.returncode != 0:
            raise RuntimeError("pod install fallito")
        logs.append("CocoaPods installati")
        
        # Build iOS
        scheme = config.app_name
        configuration = "Release" if config.build_type == BuildType.RELEASE else "Debug"
        
        build_cmd = f"xcodebuild -workspace ios/{config.app_name}.xcworkspace -scheme {scheme} -configuration {configuration} -destination generic/platform=iOS archive -archivePath build/{config.app_name}.xcarchive"
        result = await self._run_command(build_cmd, cwd=source_path)
        
        if result.returncode == 0:
            logs.append("Build iOS completato")
            
            # Export IPA
            export_cmd = f"xcodebuild -exportArchive -archivePath build/{config.app_name}.xcarchive -exportPath build/ -exportOptionsPlist ios/ExportOptions.plist"
            await self._run_command(export_cmd, cwd=source_path)
            
            ipa_path = os.path.join(source_path, "build", f"{config.app_name}.ipa")
            
            return MobileDeploymentResult(
                success=True,
                platform=MobilePlatform.IOS,
                build_path=ipa_path,
                deployment_time=0.0,
                build_logs=logs
            )
        else:
            raise RuntimeError("Build iOS fallito")
    
    async def _build_flutter_ios(
        self,
        config: MobileAppConfig,
        source_path: str,
        logs: List[str]
    ) -> MobileDeploymentResult:
        """Build Flutter per iOS."""
        
        # Build iOS
        build_cmd = "flutter build ios --release" if config.build_type == BuildType.RELEASE else "flutter build ios --debug"
        result = await self._run_command(build_cmd, cwd=source_path)
        
        if result.returncode == 0:
            logs.append("Build Flutter iOS completato")
            
            # Path app generata
            app_path = os.path.join(source_path, "build", "ios", "iphoneos", "Runner.app")
            
            return MobileDeploymentResult(
                success=True,
                platform=MobilePlatform.IOS,
                build_path=app_path,
                deployment_time=0.0,
                build_logs=logs
            )
        else:
            raise RuntimeError("Build Flutter iOS fallito")
    
    async def _build_native_ios(
        self,
        config: MobileAppConfig,
        source_path: str,
        logs: List[str]
    ) -> MobileDeploymentResult:
        """Build iOS nativo."""
        
        # Build con xcodebuild
        scheme = config.app_name
        configuration = "Release" if config.build_type == BuildType.RELEASE else "Debug"
        
        build_cmd = f"xcodebuild -project {config.app_name}.xcodeproj -scheme {scheme} -configuration {configuration} -destination generic/platform=iOS archive -archivePath build/{config.app_name}.xcarchive"
        result = await self._run_command(build_cmd, cwd=source_path)
        
        if result.returncode == 0:
            logs.append("Build iOS nativo completato")
            
            archive_path = os.path.join(source_path, "build", f"{config.app_name}.xcarchive")
            
            return MobileDeploymentResult(
                success=True,
                platform=MobilePlatform.IOS,
                build_path=archive_path,
                deployment_time=0.0,
                build_logs=logs
            )
        else:
            raise RuntimeError("Build iOS nativo fallito")
    
    async def deploy_to_google_play(
        self,
        config: MobileAppConfig,
        apk_path: str,
        track: str = "internal"
    ) -> Dict[str, Any]:
        """
        Deploy su Google Play Store.
        
        Args:
            config: Configurazione app
            apk_path: Path dell'APK
            track: Track di deployment (internal, alpha, beta, production)
            
        Returns:
            Risultato deployment
        """
        self.logger.info(f"Deploy {config.app_name} su Google Play Store")
        
        try:
            # Verifica Google Play Console API setup
            service_account_key = config.google_play_config.get('service_account_key')
            if not service_account_key:
                raise RuntimeError("Service account key per Google Play mancante")
            
            # Usa Fastlane per deployment (se disponibile)
            if await self._check_fastlane_available():
                return await self._deploy_google_play_fastlane(config, apk_path, track)
            else:
                # Fallback: deployment manuale simulato
                return await self._deploy_google_play_manual(config, apk_path, track)
                
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'platform': 'google_play'
            }
    
    async def _deploy_google_play_fastlane(
        self,
        config: MobileAppConfig,
        apk_path: str,
        track: str
    ) -> Dict[str, Any]:
        """Deploy Google Play con Fastlane."""
        
        # Crea Fastfile temporaneo
        fastfile_content = f"""
default_platform(:android)

platform :android do
  desc "Deploy to Google Play Store"
  lane :deploy do
    upload_to_play_store(
      package_name: "{config.package_name}",
      apk: "{apk_path}",
      track: "{track}",
      json_key: "{config.google_play_config.get('service_account_key')}",
      skip_upload_metadata: true,
      skip_upload_images: true,
      skip_upload_screenshots: true
    )
  end
end
"""
        
        # Scrivi Fastfile
        fastfile_path = Path(self.project_root) / "Fastfile"
        fastfile_path.write_text(fastfile_content)
        
        try:
            # Esegui Fastlane
            result = await self._run_command("fastlane android deploy", cwd=str(self.project_root))
            
            if result.returncode == 0:
                return {
                    'success': True,
                    'track': track,
                    'platform': 'google_play',
                    'store_url': f"https://play.google.com/store/apps/details?id={config.package_name}"
                }
            else:
                raise RuntimeError(f"Fastlane deployment fallito: {result.stderr}")
                
        finally:
            # Cleanup
            if fastfile_path.exists():
                fastfile_path.unlink()
    
    async def _deploy_google_play_manual(
        self,
        config: MobileAppConfig,
        apk_path: str,
        track: str
    ) -> Dict[str, Any]:
        """Deploy Google Play manuale (simulato)."""
        
        # Simula deployment per demo
        await asyncio.sleep(2)
        
        return {
            'success': True,
            'track': track,
            'platform': 'google_play',
            'store_url': f"https://play.google.com/store/apps/details?id={config.package_name}",
            'note': 'Deployment simulato - configurare Google Play Console API per deployment reale'
        }
    
    async def deploy_to_app_store(
        self,
        config: MobileAppConfig,
        ipa_path: str
    ) -> Dict[str, Any]:
        """
        Deploy su Apple App Store.
        
        Args:
            config: Configurazione app
            ipa_path: Path dell'IPA
            
        Returns:
            Risultato deployment
        """
        self.logger.info(f"Deploy {config.app_name} su Apple App Store")
        
        try:
            # Verifica App Store Connect API setup
            api_key = config.app_store_config.get('api_key')
            if not api_key:
                raise RuntimeError("API key per App Store Connect mancante")
            
            # Usa Fastlane per deployment (se disponibile)
            if await self._check_fastlane_available():
                return await self._deploy_app_store_fastlane(config, ipa_path)
            else:
                # Fallback: deployment manuale simulato
                return await self._deploy_app_store_manual(config, ipa_path)
                
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'platform': 'app_store'
            }
    
    async def _deploy_app_store_fastlane(
        self,
        config: MobileAppConfig,
        ipa_path: str
    ) -> Dict[str, Any]:
        """Deploy App Store con Fastlane."""
        
        # Crea Fastfile temporaneo
        fastfile_content = f"""
default_platform(:ios)

platform :ios do
  desc "Deploy to App Store"
  lane :deploy do
    upload_to_app_store(
      ipa: "{ipa_path}",
      app_identifier: "{config.package_name}",
      api_key_path: "{config.app_store_config.get('api_key')}",
      skip_metadata: true,
      skip_screenshots: true,
      submit_for_review: false
    )
  end
end
"""
        
        # Scrivi Fastfile
        fastfile_path = Path(self.project_root) / "Fastfile"
        fastfile_path.write_text(fastfile_content)
        
        try:
            # Esegui Fastlane
            result = await self._run_command("fastlane ios deploy", cwd=str(self.project_root))
            
            if result.returncode == 0:
                return {
                    'success': True,
                    'platform': 'app_store',
                    'store_url': f"https://apps.apple.com/app/id{config.app_store_config.get('app_id', 'TBD')}"
                }
            else:
                raise RuntimeError(f"Fastlane deployment fallito: {result.stderr}")
                
        finally:
            # Cleanup
            if fastfile_path.exists():
                fastfile_path.unlink()
    
    async def _deploy_app_store_manual(
        self,
        config: MobileAppConfig,
        ipa_path: str
    ) -> Dict[str, Any]:
        """Deploy App Store manuale (simulato)."""
        
        # Simula deployment per demo
        await asyncio.sleep(2)
        
        return {
            'success': True,
            'platform': 'app_store',
            'store_url': f"https://apps.apple.com/app/id{config.app_store_config.get('app_id', 'TBD')}",
            'note': 'Deployment simulato - configurare App Store Connect API per deployment reale'
        }
    
    async def _prepare_react_native_environment(self, config: MobileAppConfig, source_path: str):
        """Prepara ambiente React Native."""
        
        # Crea package.json se non esiste
        package_json_path = Path(source_path) / "package.json"
        if not package_json_path.exists():
            package_json = {
                "name": config.app_name.lower().replace(' ', '-'),
                "version": config.version,
                "private": True,
                "scripts": {
                    "android": "react-native run-android",
                    "ios": "react-native run-ios",
                    "start": "react-native start",
                    "test": "jest",
                    "lint": "eslint ."
                },
                "dependencies": {
                    "react": "18.2.0",
                    "react-native": "0.72.6"
                },
                "devDependencies": {
                    "@babel/core": "^7.20.0",
                    "@babel/preset-env": "^7.20.0",
                    "@babel/runtime": "^7.20.0",
                    "metro-react-native-babel-preset": "0.76.8"
                }
            }
            
            with open(package_json_path, 'w') as f:
                json.dump(package_json, f, indent=2)
        
        # Crea app.json
        app_json_path = Path(source_path) / "app.json"
        app_json = {
            "name": config.app_name,
            "displayName": config.display_name,
            "version": config.version,
            "versionCode": config.build_number
        }
        
        with open(app_json_path, 'w') as f:
            json.dump(app_json, f, indent=2)
    
    def _find_generated_apk(self, source_path: str, build_type: BuildType) -> str:
        """Trova APK generato."""
        
        # Possibili path per APK
        apk_paths = [
            f"android/app/build/outputs/apk/release/app-release.apk",
            f"android/app/build/outputs/apk/debug/app-debug.apk",
            f"app/build/outputs/apk/release/app-release.apk",
            f"app/build/outputs/apk/debug/app-debug.apk"
        ]
        
        for apk_path in apk_paths:
            full_path = os.path.join(source_path, apk_path)
            if os.path.exists(full_path):
                return full_path
        
        # Default path
        apk_name = "app-release.apk" if build_type == BuildType.RELEASE else "app-debug.apk"
        return os.path.join(source_path, "build", apk_name)
    
    async def _check_fastlane_available(self) -> bool:
        """Controlla se Fastlane è disponibile."""
        
        try:
            result = await self._run_command("fastlane --version")
            return result.returncode == 0
        except:
            return False
    
    async def _run_command(self, command: str, cwd: str = None) -> subprocess.CompletedProcess:
        """Esegue comando shell."""
        
        self.logger.debug(f"Esecuzione comando: {command}")
        
        process = await asyncio.create_subprocess_shell(
            command,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        return subprocess.CompletedProcess(
            args=command,
            returncode=process.returncode,
            stdout=stdout.decode() if stdout else "",
            stderr=stderr.decode() if stderr else ""
        )
    
    def _update_build_metrics(
        self,
        platform: MobilePlatform,
        framework: AppFramework,
        build_time: float,
        success: bool
    ):
        """Aggiorna metriche build."""
        
        self.deployment_metrics['total_builds'] += 1
        
        if success:
            self.deployment_metrics['successful_builds'] += 1
        else:
            self.deployment_metrics['failed_builds'] += 1
        
        # Aggiorna tempo medio
        total = self.deployment_metrics['total_builds']
        current_avg = self.deployment_metrics['average_build_time']
        self.deployment_metrics['average_build_time'] = (
            (current_avg * (total - 1) + build_time) / total
        )
        
        # Aggiorna statistiche piattaforma
        platform_key = platform.value
        if platform_key not in self.deployment_metrics['platforms_built']:
            self.deployment_metrics['platforms_built'][platform_key] = 0
        self.deployment_metrics['platforms_built'][platform_key] += 1
        
        # Aggiorna statistiche framework
        framework_key = framework.value
        if framework_key not in self.deployment_metrics['frameworks_used']:
            self.deployment_metrics['frameworks_used'][framework_key] = 0
        self.deployment_metrics['frameworks_used'][framework_key] += 1
    
    def get_deployment_metrics(self) -> Dict[str, Any]:
        """Restituisce metriche deployment."""
        return self.deployment_metrics.copy()
    
    async def create_app_project(
        self,
        config: MobileAppConfig,
        template: str = "default"
    ) -> str:
        """
        Crea nuovo progetto app mobile.
        
        Args:
            config: Configurazione app
            template: Template da utilizzare
            
        Returns:
            Path del progetto creato
        """
        project_path = self.project_root / config.app_name.lower().replace(' ', '_')
        project_path.mkdir(exist_ok=True)
        
        if config.framework == AppFramework.REACT_NATIVE:
            await self._create_react_native_project(config, str(project_path))
        elif config.framework == AppFramework.FLUTTER:
            await self._create_flutter_project(config, str(project_path))
        else:
            # Crea struttura base
            await self._create_basic_project_structure(config, str(project_path))
        
        return str(project_path)
    
    async def _create_react_native_project(self, config: MobileAppConfig, project_path: str):
        """Crea progetto React Native."""
        
        # Usa React Native CLI
        create_cmd = f"npx react-native init {config.app_name} --directory {project_path}"
        result = await self._run_command(create_cmd)
        
        if result.returncode != 0:
            # Fallback: crea struttura manuale
            await self._create_basic_project_structure(config, project_path)
    
    async def _create_flutter_project(self, config: MobileAppConfig, project_path: str):
        """Crea progetto Flutter."""
        
        # Usa Flutter CLI
        create_cmd = f"flutter create --project-name {config.app_name.lower().replace(' ', '_')} {project_path}"
        result = await self._run_command(create_cmd)
        
        if result.returncode != 0:
            # Fallback: crea struttura manuale
            await self._create_basic_project_structure(config, project_path)
    
    async def _create_basic_project_structure(self, config: MobileAppConfig, project_path: str):
        """Crea struttura progetto base."""
        
        project_dir = Path(project_path)
        
        # Crea directory base
        (project_dir / "src").mkdir(exist_ok=True)
        (project_dir / "assets").mkdir(exist_ok=True)
        (project_dir / "docs").mkdir(exist_ok=True)
        
        # Crea README
        readme_content = f"""# {config.display_name}

{config.description}

## Build Instructions

### Android
```bash
# Build APK
./gradlew assembleRelease
```

### iOS
```bash
# Build IPA
xcodebuild -workspace ios/{config.app_name}.xcworkspace -scheme {config.app_name} -configuration Release archive
```

## Deployment

### Google Play Store
```bash
# Deploy to internal track
fastlane android deploy
```

### Apple App Store
```bash
# Deploy to App Store
fastlane ios deploy
```
"""
        
        (project_dir / "README.md").write_text(readme_content)


# Factory function
def create_mobile_deployer(project_root: str) -> MobileAppDeployer:
    """Crea istanza Mobile Deployer."""
    return MobileAppDeployer(project_root)


# Predefined app configurations
def get_predefined_app_configs() -> Dict[str, MobileAppConfig]:
    """Restituisce configurazioni app predefinite."""
    
    return {
        'mistral_agents_mobile': MobileAppConfig(
            app_name="Mistral Agents",
            package_name="com.mistral.agents",
            version="1.0.0",
            build_number=1,
            framework=AppFramework.REACT_NATIVE,
            platforms=[MobilePlatform.ANDROID, MobilePlatform.IOS],
            display_name="Mistral AI Agents",
            description="Sistema di 36 agenti AI specializzati per business digitale",
            keywords=["AI", "agents", "business", "automation"],
            category="productivity",
            google_play_config={
                'service_account_key': 'path/to/service-account.json',
                'track': 'internal'
            },
            app_store_config={
                'api_key': 'path/to/api-key.p8',
                'app_id': 'TBD'
            }
        ),
        
        'mistral_agents_lite': MobileAppConfig(
            app_name="Mistral Agents Lite",
            package_name="com.mistral.agents.lite",
            version="1.0.0",
            build_number=1,
            framework=AppFramework.FLUTTER,
            platforms=[MobilePlatform.ANDROID],
            display_name="Mistral AI Agents Lite",
            description="Versione lite del sistema agenti AI",
            keywords=["AI", "lite", "mobile"],
            category="productivity"
        )
    }


if __name__ == "__main__":
    import asyncio
    
    async def test_mobile_deployer():
        """Test del Mobile Deployer."""
        print("=== Test Mobile Deployer ===")
        
        deployer = create_mobile_deployer("/tmp/mobile_test")
        
        # Test configurazioni predefinite
        configs = get_predefined_app_configs()
        print(f"📱 Configurazioni app predefinite: {len(configs)}")
        
        for name, config in configs.items():
            print(f"   - {name}: {config.framework.value} ({', '.join([p.value for p in config.platforms])})")
        
        # Test creazione progetto (simulato)
        print("\n🔧 Test creazione progetto...")
        
        test_config = configs['mistral_agents_mobile']
        print(f"   App: {test_config.display_name}")
        print(f"   Package: {test_config.package_name}")
        print(f"   Framework: {test_config.framework.value}")
        
        # Mostra metriche
        print("\n📊 Metriche:")
        metrics = deployer.get_deployment_metrics()
        for key, value in metrics.items():
            print(f"   {key}: {value}")
    
    # Esegui test
    asyncio.run(test_mobile_deployer())

