"""
Web Search Engine Tool

Tool avanzato per ricerca web, SEO analysis e traffico organico
con multiple search engines e analytics.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import aiohttp
import json
import time
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
from enum import Enum
import logging
from urllib.parse import urlencode, urlparse
import re
from bs4 import BeautifulSoup


class SearchEngine(Enum):
    """Search engines supportati."""
    GOOGLE = "google"
    BING = "bing"
    DUCKDUCKGO = "duckduckgo"
    YANDEX = "yandex"


class SearchType(Enum):
    """Tipi di ricerca."""
    WEB = "web"
    IMAGES = "images"
    NEWS = "news"
    VIDEOS = "videos"
    ACADEMIC = "academic"


@dataclass
class SearchResult:
    """Singolo risultato di ricerca."""
    title: str
    url: str
    snippet: str
    position: int
    domain: str = ""
    meta_description: str = ""
    keywords: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        if not self.domain and self.url:
            self.domain = urlparse(self.url).netloc


@dataclass
class SearchResponse:
    """Risposta completa di ricerca."""
    query: str
    engine: SearchEngine
    search_type: SearchType
    results: List[SearchResult]
    total_results: int
    search_time: float
    suggestions: List[str] = field(default_factory=list)
    related_searches: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'query': self.query,
            'engine': self.engine.value,
            'search_type': self.search_type.value,
            'results': [
                {
                    'title': r.title,
                    'url': r.url,
                    'snippet': r.snippet,
                    'position': r.position,
                    'domain': r.domain
                }
                for r in self.results
            ],
            'total_results': self.total_results,
            'search_time': self.search_time,
            'suggestions': self.suggestions,
            'related_searches': self.related_searches
        }


@dataclass
class SEOAnalysis:
    """Analisi SEO di una pagina."""
    url: str
    title: str
    meta_description: str
    h1_tags: List[str]
    h2_tags: List[str]
    keywords_density: Dict[str, float]
    internal_links: int
    external_links: int
    images_count: int
    page_size: int
    load_time: float
    mobile_friendly: bool
    ssl_enabled: bool
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'url': self.url,
            'title': self.title,
            'meta_description': self.meta_description,
            'h1_tags': self.h1_tags,
            'h2_tags': self.h2_tags,
            'keywords_density': self.keywords_density,
            'internal_links': self.internal_links,
            'external_links': self.external_links,
            'images_count': self.images_count,
            'page_size': self.page_size,
            'load_time': self.load_time,
            'mobile_friendly': self.mobile_friendly,
            'ssl_enabled': self.ssl_enabled
        }


class WebSearchEngine:
    """
    Motore di ricerca web avanzato con SEO analytics.
    
    Features:
    - Multiple search engines
    - SEO analysis e keyword research
    - Competitor analysis
    - SERP tracking
    - Organic traffic insights
    """
    
    def __init__(self, api_keys: Dict[str, str] = None):
        """
        Inizializza web search engine.
        
        Args:
            api_keys: API keys per search engines
        """
        self.api_keys = api_keys or {}
        self.logger = logging.getLogger(__name__)
        
        # HTTP session
        self.session: Optional[aiohttp.ClientSession] = None
        
        # Search engines configuration
        self.engines_config = {
            SearchEngine.GOOGLE: {
                'base_url': 'https://www.googleapis.com/customsearch/v1',
                'requires_api_key': True
            },
            SearchEngine.BING: {
                'base_url': 'https://api.bing.microsoft.com/v7.0/search',
                'requires_api_key': True
            },
            SearchEngine.DUCKDUCKGO: {
                'base_url': 'https://api.duckduckgo.com/',
                'requires_api_key': False
            }
        }
        
        # Metriche
        self.search_metrics = {
            'total_searches': 0,
            'successful_searches': 0,
            'failed_searches': 0,
            'average_search_time': 0.0,
            'engines_used': {},
            'popular_queries': {}
        }
        
        # Cache risultati
        self.results_cache: Dict[str, SearchResponse] = {}
        self.cache_ttl = 3600  # 1 ora
    
    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self.session:
            await self.session.close()
    
    async def search(
        self,
        query: str,
        engine: SearchEngine = SearchEngine.DUCKDUCKGO,
        search_type: SearchType = SearchType.WEB,
        num_results: int = 10,
        language: str = "it",
        region: str = "IT"
    ) -> SearchResponse:
        """
        Esegue ricerca web.
        
        Args:
            query: Query di ricerca
            engine: Motore di ricerca
            search_type: Tipo di ricerca
            num_results: Numero risultati
            language: Lingua
            region: Regione
            
        Returns:
            Risultati della ricerca
        """
        start_time = time.time()
        
        # Controlla cache
        cache_key = f"{engine.value}:{query}:{num_results}"
        if cache_key in self.results_cache:
            cached_result = self.results_cache[cache_key]
            if time.time() - cached_result.search_time < self.cache_ttl:
                self.logger.debug(f"Risultato da cache per: {query}")
                return cached_result
        
        self.logger.info(f"Ricerca '{query}' su {engine.value}")
        
        try:
            if engine == SearchEngine.GOOGLE:
                response = await self._search_google(query, search_type, num_results, language, region)
            elif engine == SearchEngine.BING:
                response = await self._search_bing(query, search_type, num_results, language, region)
            elif engine == SearchEngine.DUCKDUCKGO:
                response = await self._search_duckduckgo(query, search_type, num_results, language, region)
            else:
                raise ValueError(f"Search engine {engine} non supportato")
            
            # Aggiorna metriche
            search_time = time.time() - start_time
            response.search_time = search_time
            self._update_search_metrics(engine, query, search_time, True)
            
            # Salva in cache
            self.results_cache[cache_key] = response
            
            return response
            
        except Exception as e:
            search_time = time.time() - start_time
            self._update_search_metrics(engine, query, search_time, False)
            
            self.logger.error(f"Errore ricerca '{query}': {e}")
            
            # Ritorna risultato vuoto in caso di errore
            return SearchResponse(
                query=query,
                engine=engine,
                search_type=search_type,
                results=[],
                total_results=0,
                search_time=search_time
            )
    
    async def _search_google(
        self,
        query: str,
        search_type: SearchType,
        num_results: int,
        language: str,
        region: str
    ) -> SearchResponse:
        """Ricerca su Google Custom Search API."""
        
        api_key = self.api_keys.get('google_api_key')
        search_engine_id = self.api_keys.get('google_search_engine_id')
        
        if not api_key or not search_engine_id:
            raise ValueError("Google API key o Search Engine ID mancanti")
        
        params = {
            'key': api_key,
            'cx': search_engine_id,
            'q': query,
            'num': min(num_results, 10),  # Google limita a 10
            'hl': language,
            'gl': region
        }
        
        if search_type == SearchType.IMAGES:
            params['searchType'] = 'image'
        
        url = f"{self.engines_config[SearchEngine.GOOGLE]['base_url']}?{urlencode(params)}"
        
        async with self.session.get(url) as response:
            data = await response.json()
            
            results = []
            items = data.get('items', [])
            
            for i, item in enumerate(items):
                result = SearchResult(
                    title=item.get('title', ''),
                    url=item.get('link', ''),
                    snippet=item.get('snippet', ''),
                    position=i + 1
                )
                results.append(result)
            
            return SearchResponse(
                query=query,
                engine=SearchEngine.GOOGLE,
                search_type=search_type,
                results=results,
                total_results=int(data.get('searchInformation', {}).get('totalResults', 0)),
                suggestions=[]
            )
    
    async def _search_bing(
        self,
        query: str,
        search_type: SearchType,
        num_results: int,
        language: str,
        region: str
    ) -> SearchResponse:
        """Ricerca su Bing Search API."""
        
        api_key = self.api_keys.get('bing_api_key')
        
        if not api_key:
            raise ValueError("Bing API key mancante")
        
        headers = {
            'Ocp-Apim-Subscription-Key': api_key
        }
        
        params = {
            'q': query,
            'count': min(num_results, 50),
            'mkt': f"{language}-{region}",
            'responseFilter': 'Webpages'
        }
        
        if search_type == SearchType.IMAGES:
            params['responseFilter'] = 'Images'
        elif search_type == SearchType.NEWS:
            params['responseFilter'] = 'News'
        
        url = f"{self.engines_config[SearchEngine.BING]['base_url']}?{urlencode(params)}"
        
        async with self.session.get(url, headers=headers) as response:
            data = await response.json()
            
            results = []
            webpages = data.get('webPages', {}).get('value', [])
            
            for i, item in enumerate(webpages):
                result = SearchResult(
                    title=item.get('name', ''),
                    url=item.get('url', ''),
                    snippet=item.get('snippet', ''),
                    position=i + 1
                )
                results.append(result)
            
            return SearchResponse(
                query=query,
                engine=SearchEngine.BING,
                search_type=search_type,
                results=results,
                total_results=data.get('webPages', {}).get('totalEstimatedMatches', 0),
                suggestions=[]
            )
    
    async def _search_duckduckgo(
        self,
        query: str,
        search_type: SearchType,
        num_results: int,
        language: str,
        region: str
    ) -> SearchResponse:
        """Ricerca su DuckDuckGo (simulata per demo)."""
        
        # DuckDuckGo non ha API pubblica, simuliamo risultati
        await asyncio.sleep(0.5)  # Simula latenza
        
        # Genera risultati simulati basati sulla query
        results = []
        
        for i in range(min(num_results, 10)):
            result = SearchResult(
                title=f"Risultato {i+1} per '{query}'",
                url=f"https://example{i+1}.com/page-about-{query.replace(' ', '-')}",
                snippet=f"Questo è un risultato simulato per la query '{query}'. Contiene informazioni rilevanti e utili per l'utente.",
                position=i + 1,
                domain=f"example{i+1}.com"
            )
            results.append(result)
        
        return SearchResponse(
            query=query,
            engine=SearchEngine.DUCKDUCKGO,
            search_type=search_type,
            results=results,
            total_results=len(results) * 100,  # Simula totale
            suggestions=[f"{query} tutorial", f"{query} guida", f"come {query}"]
        )
    
    async def analyze_seo(self, url: str) -> SEOAnalysis:
        """
        Analizza SEO di una pagina web.
        
        Args:
            url: URL da analizzare
            
        Returns:
            Analisi SEO completa
        """
        self.logger.info(f"Analisi SEO per: {url}")
        
        start_time = time.time()
        
        try:
            async with self.session.get(url) as response:
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Estrai elementi SEO
                title = soup.find('title')
                title_text = title.text.strip() if title else ""
                
                meta_desc = soup.find('meta', attrs={'name': 'description'})
                meta_description = meta_desc.get('content', '') if meta_desc else ""
                
                h1_tags = [h1.text.strip() for h1 in soup.find_all('h1')]
                h2_tags = [h2.text.strip() for h2 in soup.find_all('h2')]
                
                # Analizza keywords density
                text_content = soup.get_text().lower()
                words = re.findall(r'\b\w+\b', text_content)
                word_count = len(words)
                
                keywords_density = {}
                if word_count > 0:
                    word_freq = {}
                    for word in words:
                        if len(word) > 3:  # Solo parole > 3 caratteri
                            word_freq[word] = word_freq.get(word, 0) + 1
                    
                    # Top 10 keywords
                    top_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:10]
                    keywords_density = {word: (count / word_count) * 100 for word, count in top_words}
                
                # Conta link
                internal_links = 0
                external_links = 0
                base_domain = urlparse(url).netloc
                
                for link in soup.find_all('a', href=True):
                    href = link['href']
                    if href.startswith('http'):
                        link_domain = urlparse(href).netloc
                        if link_domain == base_domain:
                            internal_links += 1
                        else:
                            external_links += 1
                    elif href.startswith('/'):
                        internal_links += 1
                
                # Conta immagini
                images_count = len(soup.find_all('img'))
                
                # Calcola dimensione pagina
                page_size = len(html.encode('utf-8'))
                
                load_time = time.time() - start_time
                
                return SEOAnalysis(
                    url=url,
                    title=title_text,
                    meta_description=meta_description,
                    h1_tags=h1_tags,
                    h2_tags=h2_tags,
                    keywords_density=keywords_density,
                    internal_links=internal_links,
                    external_links=external_links,
                    images_count=images_count,
                    page_size=page_size,
                    load_time=load_time,
                    mobile_friendly=True,  # Semplificato
                    ssl_enabled=url.startswith('https://')
                )
                
        except Exception as e:
            self.logger.error(f"Errore analisi SEO per {url}: {e}")
            
            return SEOAnalysis(
                url=url,
                title="",
                meta_description="",
                h1_tags=[],
                h2_tags=[],
                keywords_density={},
                internal_links=0,
                external_links=0,
                images_count=0,
                page_size=0,
                load_time=0.0,
                mobile_friendly=False,
                ssl_enabled=False
            )
    
    async def keyword_research(
        self,
        seed_keyword: str,
        num_suggestions: int = 20
    ) -> Dict[str, Any]:
        """
        Ricerca keyword correlate e suggerimenti.
        
        Args:
            seed_keyword: Keyword di partenza
            num_suggestions: Numero suggerimenti
            
        Returns:
            Ricerca keyword completa
        """
        self.logger.info(f"Keyword research per: {seed_keyword}")
        
        # Genera suggerimenti basati su pattern comuni
        suggestions = []
        
        # Pattern comuni per keyword research
        patterns = [
            f"{seed_keyword} come fare",
            f"{seed_keyword} tutorial",
            f"{seed_keyword} guida",
            f"{seed_keyword} migliore",
            f"{seed_keyword} prezzo",
            f"{seed_keyword} recensioni",
            f"{seed_keyword} gratis",
            f"{seed_keyword} online",
            f"{seed_keyword} Italia",
            f"migliore {seed_keyword}",
            f"come scegliere {seed_keyword}",
            f"{seed_keyword} vs",
            f"{seed_keyword} 2025",
            f"{seed_keyword} professionale"
        ]
        
        # Simula volume di ricerca e difficoltà
        for i, pattern in enumerate(patterns[:num_suggestions]):
            suggestions.append({
                'keyword': pattern,
                'search_volume': max(100, 10000 - i * 500),  # Simula volume decrescente
                'difficulty': min(100, 20 + i * 3),  # Simula difficoltà crescente
                'cpc': round(0.5 + i * 0.1, 2),  # Simula CPC
                'competition': 'low' if i < 5 else 'medium' if i < 10 else 'high'
            })
        
        return {
            'seed_keyword': seed_keyword,
            'suggestions': suggestions,
            'total_suggestions': len(suggestions),
            'research_date': time.time()
        }
    
    async def competitor_analysis(
        self,
        domain: str,
        competitors: List[str] = None
    ) -> Dict[str, Any]:
        """
        Analizza competitor per SEO e traffico organico.
        
        Args:
            domain: Dominio da analizzare
            competitors: Lista competitor (opzionale)
            
        Returns:
            Analisi competitor completa
        """
        self.logger.info(f"Competitor analysis per: {domain}")
        
        if not competitors:
            # Genera competitor simulati
            competitors = [
                f"competitor1-{domain.split('.')[0]}.com",
                f"competitor2-{domain.split('.')[0]}.com",
                f"competitor3-{domain.split('.')[0]}.com"
            ]
        
        analysis = {
            'target_domain': domain,
            'competitors': [],
            'analysis_date': time.time()
        }
        
        # Analizza ogni competitor
        for competitor in competitors:
            competitor_data = {
                'domain': competitor,
                'estimated_traffic': max(1000, hash(competitor) % 100000),  # Simula traffico
                'top_keywords': [
                    {'keyword': f'keyword1-{competitor}', 'position': 1, 'volume': 5000},
                    {'keyword': f'keyword2-{competitor}', 'position': 3, 'volume': 3000},
                    {'keyword': f'keyword3-{competitor}', 'position': 5, 'volume': 2000}
                ],
                'backlinks': max(100, hash(competitor) % 10000),  # Simula backlinks
                'domain_authority': min(100, 30 + hash(competitor) % 50)  # Simula DA
            }
            
            analysis['competitors'].append(competitor_data)
        
        return analysis
    
    async def track_serp_positions(
        self,
        keywords: List[str],
        domain: str,
        engine: SearchEngine = SearchEngine.GOOGLE
    ) -> Dict[str, Any]:
        """
        Traccia posizioni SERP per keywords specifiche.
        
        Args:
            keywords: Lista keywords da tracciare
            domain: Dominio da tracciare
            engine: Motore di ricerca
            
        Returns:
            Posizioni SERP per ogni keyword
        """
        self.logger.info(f"SERP tracking per {len(keywords)} keywords")
        
        tracking_results = {
            'domain': domain,
            'engine': engine.value,
            'keywords': [],
            'tracking_date': time.time()
        }
        
        for keyword in keywords:
            # Esegui ricerca per keyword
            search_response = await self.search(keyword, engine, num_results=50)
            
            # Trova posizione del dominio
            position = None
            for result in search_response.results:
                if domain in result.domain:
                    position = result.position
                    break
            
            keyword_data = {
                'keyword': keyword,
                'position': position,
                'url': None,
                'title': None
            }
            
            if position:
                # Trova il risultato specifico
                for result in search_response.results:
                    if result.position == position:
                        keyword_data['url'] = result.url
                        keyword_data['title'] = result.title
                        break
            
            tracking_results['keywords'].append(keyword_data)
        
        return tracking_results
    
    def _update_search_metrics(
        self,
        engine: SearchEngine,
        query: str,
        search_time: float,
        success: bool
    ):
        """Aggiorna metriche di ricerca."""
        
        self.search_metrics['total_searches'] += 1
        
        if success:
            self.search_metrics['successful_searches'] += 1
        else:
            self.search_metrics['failed_searches'] += 1
        
        # Aggiorna tempo medio
        total = self.search_metrics['total_searches']
        current_avg = self.search_metrics['average_search_time']
        self.search_metrics['average_search_time'] = (
            (current_avg * (total - 1) + search_time) / total
        )
        
        # Aggiorna statistiche engine
        engine_key = engine.value
        if engine_key not in self.search_metrics['engines_used']:
            self.search_metrics['engines_used'][engine_key] = 0
        self.search_metrics['engines_used'][engine_key] += 1
        
        # Aggiorna query popolari
        if query not in self.search_metrics['popular_queries']:
            self.search_metrics['popular_queries'][query] = 0
        self.search_metrics['popular_queries'][query] += 1
    
    def get_metrics(self) -> Dict[str, Any]:
        """Restituisce metriche di ricerca."""
        return self.search_metrics.copy()
    
    def clear_cache(self):
        """Pulisce cache risultati."""
        self.results_cache.clear()
        self.logger.info("Cache risultati pulita")


# Factory function
def create_web_search_engine(api_keys: Dict[str, str] = None) -> WebSearchEngine:
    """Crea istanza Web Search Engine."""
    return WebSearchEngine(api_keys)


# Singleton globale
_global_search_engine: Optional[WebSearchEngine] = None


async def get_global_search_engine() -> WebSearchEngine:
    """Ottiene search engine globale singleton."""
    global _global_search_engine
    
    if _global_search_engine is None:
        _global_search_engine = create_web_search_engine()
    
    return _global_search_engine


# Utility functions
async def quick_search(query: str, num_results: int = 10) -> SearchResponse:
    """Ricerca rapida con search engine globale."""
    engine = await get_global_search_engine()
    async with engine:
        return await engine.search(query, num_results=num_results)


async def quick_seo_analysis(url: str) -> SEOAnalysis:
    """Analisi SEO rapida con search engine globale."""
    engine = await get_global_search_engine()
    async with engine:
        return await engine.analyze_seo(url)


if __name__ == "__main__":
    import asyncio
    
    async def test_web_search():
        """Test del Web Search Engine."""
        print("=== Test Web Search Engine ===")
        
        async with create_web_search_engine() as engine:
            # Test ricerca base
            print("🔍 Test ricerca base...")
            results = await engine.search("intelligenza artificiale", num_results=5)
            print(f"   Query: {results.query}")
            print(f"   Risultati: {len(results.results)}")
            print(f"   Tempo: {results.search_time:.2f}s")
            
            if results.results:
                print(f"   Primo risultato: {results.results[0].title}")
            
            # Test keyword research
            print("\n🔑 Test keyword research...")
            keywords = await engine.keyword_research("marketing digitale", 5)
            print(f"   Suggerimenti: {len(keywords['suggestions'])}")
            
            for kw in keywords['suggestions'][:3]:
                print(f"     - {kw['keyword']} (vol: {kw['search_volume']})")
            
            # Test analisi SEO (simulata)
            print("\n📊 Test analisi SEO...")
            seo = await engine.analyze_seo("https://example.com")
            print(f"   URL: {seo.url}")
            print(f"   SSL: {seo.ssl_enabled}")
            print(f"   Load time: {seo.load_time:.2f}s")
            
            # Mostra metriche
            print("\n📈 Metriche:")
            metrics = engine.get_metrics()
            for key, value in metrics.items():
                if isinstance(value, dict) and value:
                    print(f"   {key}: {list(value.keys())}")
                else:
                    print(f"   {key}: {value}")
    
    # Esegui test
    asyncio.run(test_web_search())

