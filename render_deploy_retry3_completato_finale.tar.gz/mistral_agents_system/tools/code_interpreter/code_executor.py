"""
Code Interpreter Tool

Tool avanzato per esecuzione e interpretazione di codice
in multiple linguaggi con sandbox sicuro.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import subprocess
import tempfile
import os
import json
import time
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass
from enum import Enum
import logging
import docker
from pathlib import Path


class CodeLanguage(Enum):
    """Linguaggi supportati."""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    JAVA = "java"
    GO = "go"
    RUST = "rust"
    CPP = "cpp"
    BASH = "bash"
    SQL = "sql"


@dataclass
class CodeExecutionRequest:
    """Richiesta di esecuzione codice."""
    code: str
    language: CodeLanguage
    timeout: int = 30
    memory_limit: str = "128MB"
    environment: Dict[str, str] = None
    files: Dict[str, str] = None  # filename -> content
    
    def __post_init__(self):
        if self.environment is None:
            self.environment = {}
        if self.files is None:
            self.files = {}


@dataclass
class CodeExecutionResult:
    """Risultato esecuzione codice."""
    success: bool
    stdout: str
    stderr: str
    return_code: int
    execution_time: float
    memory_used: str
    files_created: List[str]
    error_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'return_code': self.return_code,
            'execution_time': self.execution_time,
            'memory_used': self.memory_used,
            'files_created': self.files_created,
            'error_message': self.error_message
        }


class CodeInterpreter:
    """
    Interprete di codice avanzato con sandbox sicuro.
    
    Features:
    - Esecuzione multi-linguaggio
    - Sandbox Docker per sicurezza
    - Gestione timeout e memory limits
    - File system isolato
    - Logging e monitoring
    """
    
    def __init__(self, use_docker: bool = True):
        """
        Inizializza code interpreter.
        
        Args:
            use_docker: Se utilizzare Docker per sandbox
        """
        self.use_docker = use_docker
        self.logger = logging.getLogger(__name__)
        
        # Docker client
        self.docker_client = None
        if use_docker:
            try:
                self.docker_client = docker.from_env()
                self.logger.info("Docker client inizializzato")
            except Exception as e:
                self.logger.warning(f"Docker non disponibile: {e}")
                self.use_docker = False
        
        # Configurazioni linguaggi
        self.language_configs = {
            CodeLanguage.PYTHON: {
                'extension': '.py',
                'command': ['python3'],
                'docker_image': 'python:3.11-slim',
                'packages': ['numpy', 'pandas', 'matplotlib', 'requests']
            },
            CodeLanguage.JAVASCRIPT: {
                'extension': '.js',
                'command': ['node'],
                'docker_image': 'node:18-slim',
                'packages': ['lodash', 'axios', 'moment']
            },
            CodeLanguage.TYPESCRIPT: {
                'extension': '.ts',
                'command': ['npx', 'ts-node'],
                'docker_image': 'node:18-slim',
                'packages': ['typescript', 'ts-node', '@types/node']
            },
            CodeLanguage.JAVA: {
                'extension': '.java',
                'command': ['java'],
                'docker_image': 'openjdk:17-slim',
                'compile_command': ['javac']
            },
            CodeLanguage.GO: {
                'extension': '.go',
                'command': ['go', 'run'],
                'docker_image': 'golang:1.21-slim'
            },
            CodeLanguage.RUST: {
                'extension': '.rs',
                'command': ['rustc', '--edition', '2021'],
                'docker_image': 'rust:1.75-slim'
            },
            CodeLanguage.BASH: {
                'extension': '.sh',
                'command': ['bash'],
                'docker_image': 'ubuntu:22.04'
            }
        }
        
        # Metriche
        self.execution_metrics = {
            'total_executions': 0,
            'successful_executions': 0,
            'failed_executions': 0,
            'average_execution_time': 0.0,
            'languages_used': {}
        }
    
    async def execute_code(self, request: CodeExecutionRequest) -> CodeExecutionResult:
        """
        Esegue codice con sandbox sicuro.
        
        Args:
            request: Richiesta di esecuzione
            
        Returns:
            Risultato dell'esecuzione
        """
        start_time = time.time()
        
        self.logger.info(f"Esecuzione codice {request.language.value}")
        
        try:
            if self.use_docker and self.docker_client:
                result = await self._execute_in_docker(request)
            else:
                result = await self._execute_local(request)
            
            # Aggiorna metriche
            execution_time = time.time() - start_time
            self._update_metrics(request.language, execution_time, result.success)
            
            return result
            
        except Exception as e:
            execution_time = time.time() - start_time
            self._update_metrics(request.language, execution_time, False)
            
            return CodeExecutionResult(
                success=False,
                stdout="",
                stderr=str(e),
                return_code=-1,
                execution_time=execution_time,
                memory_used="0MB",
                files_created=[],
                error_message=str(e)
            )
    
    async def _execute_in_docker(self, request: CodeExecutionRequest) -> CodeExecutionResult:
        """Esegue codice in container Docker."""
        
        config = self.language_configs[request.language]
        
        # Crea directory temporanea
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Scrivi file di codice
            code_file = temp_path / f"main{config['extension']}"
            code_file.write_text(request.code)
            
            # Scrivi file aggiuntivi
            for filename, content in request.files.items():
                file_path = temp_path / filename
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content)
            
            # Prepara comando
            if request.language == CodeLanguage.JAVA:
                # Compila Java
                compile_cmd = config['compile_command'] + [str(code_file)]
                await self._run_docker_command(
                    config['docker_image'],
                    compile_cmd,
                    temp_dir,
                    request.timeout // 2
                )
                
                # Esegui Java
                class_name = code_file.stem
                command = ['java', class_name]
            else:
                command = config['command'] + [str(code_file)]
            
            # Esegui in Docker
            return await self._run_docker_command(
                config['docker_image'],
                command,
                temp_dir,
                request.timeout,
                request.memory_limit,
                request.environment
            )
    
    async def _run_docker_command(
        self,
        image: str,
        command: List[str],
        working_dir: str,
        timeout: int,
        memory_limit: str = "128MB",
        environment: Dict[str, str] = None
    ) -> CodeExecutionResult:
        """Esegue comando in container Docker."""
        
        start_time = time.time()
        
        try:
            # Configurazione container
            container_config = {
                'image': image,
                'command': command,
                'working_dir': '/workspace',
                'volumes': {working_dir: {'bind': '/workspace', 'mode': 'rw'}},
                'mem_limit': memory_limit,
                'network_disabled': True,  # Sicurezza
                'remove': True,
                'stdout': True,
                'stderr': True,
                'environment': environment or {}
            }
            
            # Esegui container
            container = self.docker_client.containers.run(**container_config)
            
            # Attendi completamento con timeout
            try:
                exit_code = container.wait(timeout=timeout)['StatusCode']
                logs = container.logs(stdout=True, stderr=True).decode('utf-8')
                
                # Separa stdout e stderr (semplificato)
                stdout = logs
                stderr = ""
                
            except Exception as e:
                # Timeout o errore
                try:
                    container.kill()
                except:
                    pass
                
                return CodeExecutionResult(
                    success=False,
                    stdout="",
                    stderr=f"Execution timeout or error: {e}",
                    return_code=-1,
                    execution_time=time.time() - start_time,
                    memory_used="0MB",
                    files_created=[]
                )
            
            # Controlla file creati
            files_created = []
            try:
                for item in os.listdir(working_dir):
                    if item not in ['main.py', 'main.js', 'main.java', 'main.go', 'main.rs', 'main.sh']:
                        files_created.append(item)
            except:
                pass
            
            return CodeExecutionResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                return_code=exit_code,
                execution_time=time.time() - start_time,
                memory_used=memory_limit,  # Semplificato
                files_created=files_created
            )
            
        except Exception as e:
            return CodeExecutionResult(
                success=False,
                stdout="",
                stderr=f"Docker execution error: {e}",
                return_code=-1,
                execution_time=time.time() - start_time,
                memory_used="0MB",
                files_created=[]
            )
    
    async def _execute_local(self, request: CodeExecutionRequest) -> CodeExecutionResult:
        """Esegue codice localmente (meno sicuro)."""
        
        config = self.language_configs[request.language]
        start_time = time.time()
        
        # Crea directory temporanea
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Scrivi file di codice
            code_file = temp_path / f"main{config['extension']}"
            code_file.write_text(request.code)
            
            # Scrivi file aggiuntivi
            for filename, content in request.files.items():
                file_path = temp_path / filename
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content)
            
            # Prepara comando
            if request.language == CodeLanguage.JAVA:
                # Compila Java
                compile_process = await asyncio.create_subprocess_exec(
                    *config['compile_command'], str(code_file),
                    cwd=temp_dir,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                
                await compile_process.communicate()
                
                if compile_process.returncode != 0:
                    return CodeExecutionResult(
                        success=False,
                        stdout="",
                        stderr="Compilation failed",
                        return_code=compile_process.returncode,
                        execution_time=time.time() - start_time,
                        memory_used="0MB",
                        files_created=[]
                    )
                
                # Esegui Java
                class_name = code_file.stem
                command = ['java', class_name]
            else:
                command = config['command'] + [str(code_file)]
            
            # Esegui comando
            try:
                process = await asyncio.create_subprocess_exec(
                    *command,
                    cwd=temp_dir,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    env={**os.environ, **request.environment}
                )
                
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=request.timeout
                )
                
                # Controlla file creati
                files_created = []
                for item in os.listdir(temp_dir):
                    if item not in [code_file.name] and not item.endswith('.class'):
                        files_created.append(item)
                
                return CodeExecutionResult(
                    success=process.returncode == 0,
                    stdout=stdout.decode('utf-8'),
                    stderr=stderr.decode('utf-8'),
                    return_code=process.returncode,
                    execution_time=time.time() - start_time,
                    memory_used="Unknown",
                    files_created=files_created
                )
                
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                
                return CodeExecutionResult(
                    success=False,
                    stdout="",
                    stderr="Execution timeout",
                    return_code=-1,
                    execution_time=time.time() - start_time,
                    memory_used="Unknown",
                    files_created=[]
                )
    
    async def execute_python_code(
        self,
        code: str,
        timeout: int = 30,
        packages: List[str] = None
    ) -> CodeExecutionResult:
        """Shortcut per esecuzione codice Python."""
        
        # Aggiungi import packages se specificati
        if packages:
            imports = '\n'.join([f"import {pkg}" for pkg in packages])
            code = f"{imports}\n\n{code}"
        
        request = CodeExecutionRequest(
            code=code,
            language=CodeLanguage.PYTHON,
            timeout=timeout
        )
        
        return await self.execute_code(request)
    
    async def execute_javascript_code(
        self,
        code: str,
        timeout: int = 30,
        packages: List[str] = None
    ) -> CodeExecutionResult:
        """Shortcut per esecuzione codice JavaScript."""
        
        # Aggiungi require packages se specificati
        if packages:
            requires = '\n'.join([f"const {pkg} = require('{pkg}');" for pkg in packages])
            code = f"{requires}\n\n{code}"
        
        request = CodeExecutionRequest(
            code=code,
            language=CodeLanguage.JAVASCRIPT,
            timeout=timeout
        )
        
        return await self.execute_code(request)
    
    async def analyze_code(self, code: str, language: CodeLanguage) -> Dict[str, Any]:
        """Analizza codice senza eseguirlo."""
        
        analysis = {
            'language': language.value,
            'lines_of_code': len(code.split('\n')),
            'estimated_complexity': 'medium',
            'potential_issues': [],
            'suggestions': []
        }
        
        # Analisi semplificata
        if language == CodeLanguage.PYTHON:
            if 'import os' in code or 'import subprocess' in code:
                analysis['potential_issues'].append('System calls detected')
            
            if 'while True:' in code:
                analysis['potential_issues'].append('Infinite loop detected')
            
            if len(code.split('\n')) > 100:
                analysis['suggestions'].append('Consider breaking into smaller functions')
        
        elif language == CodeLanguage.JAVASCRIPT:
            if 'eval(' in code:
                analysis['potential_issues'].append('eval() usage detected')
            
            if 'require(' in code and 'fs' in code:
                analysis['potential_issues'].append('File system access detected')
        
        return analysis
    
    async def format_code(self, code: str, language: CodeLanguage) -> str:
        """Formatta codice usando formatter appropriato."""
        
        if language == CodeLanguage.PYTHON:
            # Usa black per Python (se disponibile)
            try:
                import black
                return black.format_str(code, mode=black.FileMode())
            except ImportError:
                return code
        
        elif language == CodeLanguage.JAVASCRIPT:
            # Placeholder per prettier
            return code
        
        else:
            return code
    
    def _update_metrics(self, language: CodeLanguage, execution_time: float, success: bool):
        """Aggiorna metriche di esecuzione."""
        
        self.execution_metrics['total_executions'] += 1
        
        if success:
            self.execution_metrics['successful_executions'] += 1
        else:
            self.execution_metrics['failed_executions'] += 1
        
        # Aggiorna tempo medio
        total = self.execution_metrics['total_executions']
        current_avg = self.execution_metrics['average_execution_time']
        self.execution_metrics['average_execution_time'] = (
            (current_avg * (total - 1) + execution_time) / total
        )
        
        # Aggiorna statistiche per linguaggio
        lang_key = language.value
        if lang_key not in self.execution_metrics['languages_used']:
            self.execution_metrics['languages_used'][lang_key] = 0
        self.execution_metrics['languages_used'][lang_key] += 1
    
    def get_metrics(self) -> Dict[str, Any]:
        """Restituisce metriche di esecuzione."""
        return self.execution_metrics.copy()
    
    def get_supported_languages(self) -> List[str]:
        """Restituisce linguaggi supportati."""
        return [lang.value for lang in CodeLanguage]


# Factory function
def create_code_interpreter(use_docker: bool = True) -> CodeInterpreter:
    """Crea istanza Code Interpreter."""
    return CodeInterpreter(use_docker)


# Singleton globale
_global_interpreter: Optional[CodeInterpreter] = None


def get_global_interpreter() -> CodeInterpreter:
    """Ottiene interpreter globale singleton."""
    global _global_interpreter
    
    if _global_interpreter is None:
        _global_interpreter = create_code_interpreter()
    
    return _global_interpreter


# Utility functions
async def execute_python(code: str, **kwargs) -> CodeExecutionResult:
    """Esegue codice Python con interpreter globale."""
    interpreter = get_global_interpreter()
    return await interpreter.execute_python_code(code, **kwargs)


async def execute_javascript(code: str, **kwargs) -> CodeExecutionResult:
    """Esegue codice JavaScript con interpreter globale."""
    interpreter = get_global_interpreter()
    return await interpreter.execute_javascript_code(code, **kwargs)


if __name__ == "__main__":
    import asyncio
    
    async def test_code_interpreter():
        """Test del Code Interpreter."""
        print("=== Test Code Interpreter ===")
        
        interpreter = create_code_interpreter(use_docker=False)  # Test locale
        
        # Test Python
        python_code = """
print("Hello from Python!")
import math
result = math.sqrt(16)
print(f"Square root of 16: {result}")
        """
        
        print("🐍 Test Python...")
        result = await interpreter.execute_python_code(python_code)
        print(f"   Success: {result.success}")
        print(f"   Output: {result.stdout.strip()}")
        
        # Test JavaScript
        js_code = """
console.log("Hello from JavaScript!");
const result = Math.sqrt(16);
console.log(`Square root of 16: ${result}`);
        """
        
        print("\n📜 Test JavaScript...")
        result = await interpreter.execute_javascript_code(js_code)
        print(f"   Success: {result.success}")
        print(f"   Output: {result.stdout.strip()}")
        
        # Test analisi codice
        print("\n🔍 Test analisi codice...")
        analysis = await interpreter.analyze_code(python_code, CodeLanguage.PYTHON)
        print(f"   Lines of code: {analysis['lines_of_code']}")
        print(f"   Issues: {analysis['potential_issues']}")
        
        # Mostra metriche
        print("\n📊 Metriche:")
        metrics = interpreter.get_metrics()
        for key, value in metrics.items():
            print(f"   {key}: {value}")
    
    # Esegui test
    asyncio.run(test_code_interpreter())

