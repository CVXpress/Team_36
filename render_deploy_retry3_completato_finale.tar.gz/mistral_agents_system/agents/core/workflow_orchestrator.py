"""
Workflow Orchestrator Agent

Agente principale per l'orchestrazione di workflow complessi
che coinvolgono multiple agenti specializzati.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import uuid

from agents.base_agent import BaseAgent, Task, TaskStatus, TaskPriority, agent_decorator
from config.mistral_config import AgentConfig


@dataclass
class WorkflowStep:
    """Singolo step di un workflow."""
    id: str
    agent_name: str
    task_description: str
    expected_output: str
    dependencies: List[str] = None
    priority: TaskPriority = TaskPriority.MEDIUM
    context: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []
        if self.context is None:
            self.context = {}


@dataclass
class Workflow:
    """Definizione di un workflow complesso."""
    id: str
    name: str
    description: str
    steps: List[WorkflowStep]
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


@agent_decorator('workflow_orchestrator')
class WorkflowOrchestratorAgent(BaseAgent):
    """
    Agente orchestratore per workflow complessi multi-agente.
    
    Responsabilità:
    - Coordinare esecuzione di workflow complessi
    - Gestire dipendenze tra task
    - Ottimizzare parallelizzazione
    - Monitorare progresso e performance
    - Gestire fallimenti e recovery
    """
    
    def __init__(self, config: AgentConfig, mistral_client=None):
        super().__init__(config, mistral_client)
        
        # Workflow predefiniti
        self.predefined_workflows = self._initialize_predefined_workflows()
        
        # Stato orchestrazione
        self.active_workflows: Dict[str, Dict[str, Any]] = {}
        self.workflow_history: List[Dict[str, Any]] = []
        
        # Metriche orchestrazione
        self.orchestration_metrics = {
            'total_workflows': 0,
            'completed_workflows': 0,
            'failed_workflows': 0,
            'average_workflow_time': 0.0,
            'total_steps_executed': 0
        }
    
    async def _execute_specific_task(self, task: Task) -> Dict[str, Any]:
        """Esegue task specifico dell'orchestratore."""
        
        # Analizza tipo di task
        task_type = task.context.get('task_type', 'workflow_execution')
        
        if task_type == 'workflow_execution':
            return await self._execute_workflow_task(task)
        elif task_type == 'workflow_analysis':
            return await self._analyze_workflow_task(task)
        elif task_type == 'workflow_optimization':
            return await self._optimize_workflow_task(task)
        elif task_type == 'workflow_monitoring':
            return await self._monitor_workflows_task(task)
        else:
            return await self._general_orchestration_task(task)
    
    async def _execute_workflow_task(self, task: Task) -> Dict[str, Any]:
        """Esegue un workflow specifico."""
        
        workflow_name = task.context.get('workflow_name')
        workflow_params = task.context.get('workflow_params', {})
        
        if workflow_name and workflow_name in self.predefined_workflows:
            # Esegui workflow predefinito
            workflow = self.predefined_workflows[workflow_name]
            return await self._execute_predefined_workflow(workflow, workflow_params)
        else:
            # Crea workflow dinamico basato su task
            return await self._create_and_execute_dynamic_workflow(task)
    
    async def _execute_predefined_workflow(
        self,
        workflow: Workflow,
        params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Esegue workflow predefinito."""
        
        workflow_id = str(uuid.uuid4())
        
        self.logger.info(f"Esecuzione workflow predefinito: {workflow.name}")
        
        # Inizializza tracking workflow
        workflow_state = {
            'id': workflow_id,
            'name': workflow.name,
            'status': 'running',
            'steps_completed': 0,
            'total_steps': len(workflow.steps),
            'results': {},
            'errors': [],
            'start_time': asyncio.get_event_loop().time()
        }
        
        self.active_workflows[workflow_id] = workflow_state
        
        try:
            # Esegui steps del workflow
            for step in workflow.steps:
                step_result = await self._execute_workflow_step(step, workflow_state, params)
                workflow_state['results'][step.id] = step_result
                workflow_state['steps_completed'] += 1
            
            workflow_state['status'] = 'completed'
            workflow_state['end_time'] = asyncio.get_event_loop().time()
            
            # Aggiorna metriche
            self.orchestration_metrics['completed_workflows'] += 1
            self.orchestration_metrics['total_workflows'] += 1
            
            return {
                'workflow_id': workflow_id,
                'status': 'completed',
                'results': workflow_state['results'],
                'execution_time': workflow_state['end_time'] - workflow_state['start_time'],
                'steps_completed': workflow_state['steps_completed']
            }
            
        except Exception as e:
            workflow_state['status'] = 'failed'
            workflow_state['error'] = str(e)
            
            self.orchestration_metrics['failed_workflows'] += 1
            self.orchestration_metrics['total_workflows'] += 1
            
            raise
        
        finally:
            # Sposta in history
            self.workflow_history.append(workflow_state.copy())
            if workflow_id in self.active_workflows:
                del self.active_workflows[workflow_id]
    
    async def _execute_workflow_step(
        self,
        step: WorkflowStep,
        workflow_state: Dict[str, Any],
        params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Esegue singolo step del workflow."""
        
        self.logger.info(f"Esecuzione step {step.id}: {step.agent_name}")
        
        # Verifica dipendenze
        for dep in step.dependencies:
            if dep not in workflow_state['results']:
                raise RuntimeError(f"Dipendenza {dep} non soddisfatta per step {step.id}")
        
        # Prepara context per step
        step_context = step.context.copy()
        step_context.update(params)
        
        # Aggiungi risultati dipendenze al context
        for dep in step.dependencies:
            step_context[f'dependency_{dep}'] = workflow_state['results'][dep]
        
        # Delega task all'agente appropriato
        if self.on_delegation_request:
            delegation_task = Task(
                id=str(uuid.uuid4()),
                agent_name=step.agent_name,
                description=step.task_description,
                expected_output=step.expected_output,
                context=step_context,
                priority=step.priority
            )
            
            result = await self.on_delegation_request(self, delegation_task)
            self.orchestration_metrics['total_steps_executed'] += 1
            
            return result
        else:
            # Fallback: simula esecuzione
            return {
                'status': 'simulated',
                'message': f'Step {step.id} simulato (no delegation callback)',
                'agent': step.agent_name
            }
    
    async def _create_and_execute_dynamic_workflow(self, task: Task) -> Dict[str, Any]:
        """Crea ed esegue workflow dinamico basato su task."""
        
        # Usa Mistral per analizzare task e creare workflow
        analysis_prompt = f"""
        Analizza questo task complesso e crea un workflow ottimale:
        
        Task: {task.description}
        Output atteso: {task.expected_output}
        Context: {json.dumps(task.context, indent=2)}
        
        Crea un workflow che:
        1. Identifica gli agenti necessari
        2. Definisce la sequenza ottimale di step
        3. Gestisce le dipendenze tra step
        4. Massimizza la parallelizzazione quando possibile
        
        Rispondi con un JSON che definisce il workflow.
        """
        
        workflow_json = await self._call_mistral(
            analysis_prompt,
            max_tokens=1000
        )
        
        try:
            # Parse workflow JSON
            workflow_data = json.loads(workflow_json)
            
            # Crea workflow object
            workflow = Workflow(
                id=str(uuid.uuid4()),
                name=workflow_data.get('name', 'Dynamic Workflow'),
                description=workflow_data.get('description', 'Workflow generato dinamicamente'),
                steps=[
                    WorkflowStep(
                        id=step['id'],
                        agent_name=step['agent_name'],
                        task_description=step['task_description'],
                        expected_output=step['expected_output'],
                        dependencies=step.get('dependencies', []),
                        priority=TaskPriority(step.get('priority', 2))
                    )
                    for step in workflow_data.get('steps', [])
                ]
            )
            
            # Esegui workflow
            return await self._execute_predefined_workflow(workflow, task.context)
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Errore parsing workflow JSON: {e}")
            return {
                'status': 'failed',
                'error': 'Impossibile parsare workflow generato',
                'raw_response': workflow_json
            }
    
    async def _analyze_workflow_task(self, task: Task) -> Dict[str, Any]:
        """Analizza performance e ottimizzazioni per workflow."""
        
        analysis_prompt = f"""
        Analizza le performance dei workflow e suggerisci ottimizzazioni:
        
        Metriche attuali:
        - Workflow totali: {self.orchestration_metrics['total_workflows']}
        - Workflow completati: {self.orchestration_metrics['completed_workflows']}
        - Workflow falliti: {self.orchestration_metrics['failed_workflows']}
        - Step totali eseguiti: {self.orchestration_metrics['total_steps_executed']}
        
        Workflow attivi: {len(self.active_workflows)}
        
        Fornisci:
        1. Analisi delle performance
        2. Identificazione di bottleneck
        3. Suggerimenti di ottimizzazione
        4. Raccomandazioni per migliorare l'efficienza
        """
        
        analysis = await self._call_mistral(analysis_prompt, max_tokens=800)
        
        return {
            'analysis': analysis,
            'metrics': self.orchestration_metrics.copy(),
            'active_workflows': len(self.active_workflows),
            'workflow_history_size': len(self.workflow_history)
        }
    
    async def _optimize_workflow_task(self, task: Task) -> Dict[str, Any]:
        """Ottimizza workflow esistenti."""
        
        workflow_name = task.context.get('workflow_name')
        
        if workflow_name not in self.predefined_workflows:
            return {
                'status': 'failed',
                'error': f'Workflow {workflow_name} non trovato'
            }
        
        workflow = self.predefined_workflows[workflow_name]
        
        optimization_prompt = f"""
        Ottimizza questo workflow per migliorare performance ed efficienza:
        
        Workflow: {workflow.name}
        Descrizione: {workflow.description}
        
        Step attuali:
        {json.dumps([{
            'id': step.id,
            'agent': step.agent_name,
            'description': step.task_description,
            'dependencies': step.dependencies
        } for step in workflow.steps], indent=2)}
        
        Suggerisci:
        1. Riorganizzazione step per massimizzare parallelizzazione
        2. Eliminazione di ridondanze
        3. Ottimizzazione dipendenze
        4. Miglioramenti nella sequenza di esecuzione
        """
        
        optimization = await self._call_mistral(optimization_prompt, max_tokens=1000)
        
        return {
            'workflow_name': workflow_name,
            'current_steps': len(workflow.steps),
            'optimization_suggestions': optimization,
            'status': 'completed'
        }
    
    async def _monitor_workflows_task(self, task: Task) -> Dict[str, Any]:
        """Monitora stato dei workflow attivi."""
        
        monitoring_data = {
            'active_workflows': {},
            'system_health': {},
            'performance_metrics': self.orchestration_metrics.copy()
        }
        
        # Dettagli workflow attivi
        for workflow_id, workflow_state in self.active_workflows.items():
            current_time = asyncio.get_event_loop().time()
            runtime = current_time - workflow_state['start_time']
            
            monitoring_data['active_workflows'][workflow_id] = {
                'name': workflow_state['name'],
                'status': workflow_state['status'],
                'progress': f"{workflow_state['steps_completed']}/{workflow_state['total_steps']}",
                'runtime': f"{runtime:.2f}s",
                'errors': len(workflow_state.get('errors', []))
            }
        
        # Health check del sistema
        monitoring_data['system_health'] = {
            'orchestrator_active': self.is_active,
            'total_active_workflows': len(self.active_workflows),
            'workflow_success_rate': (
                self.orchestration_metrics['completed_workflows'] / 
                max(self.orchestration_metrics['total_workflows'], 1)
            ),
            'average_steps_per_workflow': (
                self.orchestration_metrics['total_steps_executed'] /
                max(self.orchestration_metrics['total_workflows'], 1)
            )
        }
        
        return monitoring_data
    
    async def _general_orchestration_task(self, task: Task) -> Dict[str, Any]:
        """Gestisce task generali di orchestrazione."""
        
        orchestration_prompt = f"""
        Come orchestratore di sistema multi-agente, analizza e risolvi questo task:
        
        Task: {task.description}
        Output richiesto: {task.expected_output}
        Context: {json.dumps(task.context, indent=2)}
        
        Considera:
        1. Quali agenti coinvolgere
        2. Come strutturare l'approccio
        3. Potenziali sfide e soluzioni
        4. Strategie di ottimizzazione
        
        Fornisci una strategia dettagliata e actionable.
        """
        
        strategy = await self._call_mistral(orchestration_prompt, max_tokens=1200)
        
        return {
            'orchestration_strategy': strategy,
            'task_analysis': {
                'complexity': 'high' if len(task.description) > 200 else 'medium',
                'estimated_agents_needed': len(task.context.get('required_agents', [])),
                'priority': task.priority.name
            },
            'recommendations': {
                'parallel_execution': True,
                'monitoring_required': True,
                'fallback_strategy': 'sequential_execution'
            }
        }
    
    def _initialize_predefined_workflows(self) -> Dict[str, Workflow]:
        """Inizializza workflow predefiniti."""
        
        workflows = {}
        
        # Workflow: Sviluppo Applicazione Completa
        workflows['full_app_development'] = Workflow(
            id='full_app_dev',
            name='Sviluppo Applicazione Completa',
            description='Workflow completo per sviluppo app da concept a deployment',
            steps=[
                WorkflowStep(
                    id='requirements_analysis',
                    agent_name='business_analyst',
                    task_description='Analizza requisiti e crea specifiche dettagliate',
                    expected_output='Documento specifiche tecniche e business'
                ),
                WorkflowStep(
                    id='architecture_design',
                    agent_name='tech_lead',
                    task_description='Progetta architettura tecnica dell\'applicazione',
                    expected_output='Documento architettura e stack tecnologico',
                    dependencies=['requirements_analysis']
                ),
                WorkflowStep(
                    id='ui_ux_design',
                    agent_name='ui_ux_designer',
                    task_description='Progetta interfaccia utente e user experience',
                    expected_output='Mockup e prototipi UI/UX',
                    dependencies=['requirements_analysis']
                ),
                WorkflowStep(
                    id='backend_development',
                    agent_name='backend_developer',
                    task_description='Sviluppa backend e API',
                    expected_output='Backend funzionante con API documentate',
                    dependencies=['architecture_design']
                ),
                WorkflowStep(
                    id='frontend_development',
                    agent_name='frontend_developer',
                    task_description='Sviluppa frontend dell\'applicazione',
                    expected_output='Frontend completo e responsive',
                    dependencies=['ui_ux_design', 'backend_development']
                ),
                WorkflowStep(
                    id='mobile_development',
                    agent_name='mobile_developer',
                    task_description='Sviluppa app mobile',
                    expected_output='App mobile per iOS e Android',
                    dependencies=['backend_development', 'ui_ux_design']
                ),
                WorkflowStep(
                    id='testing',
                    agent_name='qa_engineer',
                    task_description='Esegui testing completo dell\'applicazione',
                    expected_output='Report testing e bug fixes',
                    dependencies=['frontend_development', 'mobile_development']
                ),
                WorkflowStep(
                    id='deployment',
                    agent_name='devops_engineer',
                    task_description='Deploy applicazione in produzione',
                    expected_output='Applicazione deployata e monitorata',
                    dependencies=['testing']
                )
            ]
        )
        
        # Workflow: Lancio Prodotto Digitale
        workflows['digital_product_launch'] = Workflow(
            id='product_launch',
            name='Lancio Prodotto Digitale',
            description='Workflow completo per lancio prodotto digitale',
            steps=[
                WorkflowStep(
                    id='market_research',
                    agent_name='market_researcher',
                    task_description='Ricerca di mercato e analisi competitor',
                    expected_output='Report ricerca mercato completo'
                ),
                WorkflowStep(
                    id='product_strategy',
                    agent_name='product_manager',
                    task_description='Definisci strategia prodotto e roadmap',
                    expected_output='Strategia prodotto e roadmap dettagliata',
                    dependencies=['market_research']
                ),
                WorkflowStep(
                    id='brand_identity',
                    agent_name='brand_designer',
                    task_description='Crea identità brand e materiali visivi',
                    expected_output='Brand identity e asset visivi',
                    dependencies=['product_strategy']
                ),
                WorkflowStep(
                    id='content_strategy',
                    agent_name='content_creator',
                    task_description='Sviluppa strategia contenuti e materiali marketing',
                    expected_output='Piano contenuti e materiali marketing',
                    dependencies=['brand_identity']
                ),
                WorkflowStep(
                    id='digital_marketing',
                    agent_name='seo_specialist',
                    task_description='Ottimizza presenza online e SEO',
                    expected_output='Strategia SEO e ottimizzazione online',
                    dependencies=['content_strategy']
                ),
                WorkflowStep(
                    id='social_media_campaign',
                    agent_name='social_media_manager',
                    task_description='Lancia campagna social media',
                    expected_output='Campagna social media attiva',
                    dependencies=['content_strategy']
                ),
                WorkflowStep(
                    id='sales_strategy',
                    agent_name='sales_manager',
                    task_description='Sviluppa strategia vendite e pipeline',
                    expected_output='Strategia vendite e processo commerciale',
                    dependencies=['product_strategy']
                ),
                WorkflowStep(
                    id='launch_execution',
                    agent_name='project_manager',
                    task_description='Coordina esecuzione lancio prodotto',
                    expected_output='Lancio prodotto eseguito con successo',
                    dependencies=['digital_marketing', 'social_media_campaign', 'sales_strategy']
                )
            ]
        )
        
        # Workflow: Ottimizzazione Business
        workflows['business_optimization'] = Workflow(
            id='biz_optimization',
            name='Ottimizzazione Business',
            description='Workflow per ottimizzazione processi e performance business',
            steps=[
                WorkflowStep(
                    id='business_analysis',
                    agent_name='business_analyst',
                    task_description='Analizza processi business attuali',
                    expected_output='Analisi processi e identificazione gap'
                ),
                WorkflowStep(
                    id='data_analysis',
                    agent_name='data_analyst',
                    task_description='Analizza dati performance e KPI',
                    expected_output='Dashboard analytics e insights',
                    dependencies=['business_analysis']
                ),
                WorkflowStep(
                    id='operations_optimization',
                    agent_name='operations_manager',
                    task_description='Ottimizza processi operativi',
                    expected_output='Piano ottimizzazione operazioni',
                    dependencies=['business_analysis', 'data_analysis']
                ),
                WorkflowStep(
                    id='automation_strategy',
                    agent_name='automation_specialist',
                    task_description='Identifica opportunità di automazione',
                    expected_output='Piano automazione processi',
                    dependencies=['operations_optimization']
                ),
                WorkflowStep(
                    id='implementation_plan',
                    agent_name='project_manager',
                    task_description='Crea piano implementazione ottimizzazioni',
                    expected_output='Piano implementazione dettagliato',
                    dependencies=['automation_strategy']
                )
            ]
        )
        
        return workflows
    
    def get_predefined_workflows(self) -> Dict[str, Dict[str, Any]]:
        """Restituisce lista workflow predefiniti."""
        return {
            name: {
                'id': workflow.id,
                'name': workflow.name,
                'description': workflow.description,
                'steps_count': len(workflow.steps),
                'estimated_time': len(workflow.steps) * 2  # Stima 2 min per step
            }
            for name, workflow in self.predefined_workflows.items()
        }
    
    def get_orchestration_metrics(self) -> Dict[str, Any]:
        """Restituisce metriche di orchestrazione."""
        return {
            **self.orchestration_metrics,
            'active_workflows_count': len(self.active_workflows),
            'workflow_history_size': len(self.workflow_history)
        }

