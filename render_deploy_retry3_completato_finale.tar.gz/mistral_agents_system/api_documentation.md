# 📡 API Documentation - Sistema 36 Agenti AI

**Base URL:** `https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer`  
**Versione:** 3.0  
**Autenticazione:** Nessuna (uso personale)  
**Content-Type:** `application/json`  

---

## 📊 Endpoints Principali

### 1. GET /api/stats
**Descrizione:** Ottieni statistiche sistema in tempo reale

**Request:**
```bash
curl -X GET https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/stats \
  -H "Accept: application/json"
```

**Response:**
```json
{
  "active_agents": 36,
  "deployment": {
    "environment": "production",
    "platform": "Railway + Render",
    "version": "3.0"
  },
  "last_updated": "2025-08-22T08:37:15.123456",
  "mistral_api_key": "gJ200l66zgUiRZcUji9S...",
  "mistral_model": "mistral-medium-latest",
  "status": "online",
  "total_agents": 36,
  "uptime": "99.9%"
}
```

**JavaScript:**
```javascript
const stats = await fetch('/api/stats').then(r => r.json());
console.log('Agenti attivi:', stats.active_agents);
```

---

### 2. GET /api/agents
**Descrizione:** Lista completa di tutti i 36 agenti AI disponibili

**Request:**
```bash
curl -X GET https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/agents \
  -H "Accept: application/json"
```

**Response:**
```json
{
  "agents": [
    {
      "category": "core",
      "id": "vision_planner",
      "name": "VisionPlanner AI",
      "status": "active"
    },
    {
      "category": "strategy",
      "id": "market_researcher",
      "name": "MarketResearcher AI",
      "status": "active"
    }
  ],
  "categories": ["core", "strategy", "marketing", "operations", "product", "hr", "tech", "compliance", "innovation", "development"],
  "total": 36
}
```

**JavaScript:**
```javascript
const agents = await fetch('/api/agents').then(r => r.json());
agents.agents.forEach(agent => {
  console.log(`${agent.name} (${agent.id}) - ${agent.status}`);
});
```

---

### 3. GET /api/workflows
**Descrizione:** Lista workflow predefiniti disponibili

**Request:**
```bash
curl -X GET https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/workflows \
  -H "Accept: application/json"
```

**Response:**
```json
{
  "workflows": [
    {
      "id": "business_analysis",
      "name": "Business Analysis Complete",
      "description": "Analisi business completa con 8 agenti",
      "agents_count": 8,
      "estimated_time": "15-20 minuti"
    },
    {
      "id": "product_launch",
      "name": "Product Launch Workflow",
      "description": "Lancio prodotto coordinato con 8 agenti",
      "agents_count": 8,
      "estimated_time": "20-25 minuti"
    }
  ],
  "total": 4
}
```

---

### 4. GET /api/health
**Descrizione:** Health check completo del sistema

**Request:**
```bash
curl -X GET https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/health \
  -H "Accept: application/json"
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-08-22T08:37:15.123456",
  "checks": {
    "mistral_api": "✅ Connected",
    "database": "✅ Online",
    "agents": "✅ 36/36 Active",
    "memory": "✅ 45% Used",
    "cpu": "✅ 12% Used"
  },
  "uptime_seconds": 86400,
  "version": "3.0"
}
```

---

## 🤖 Esecuzione Agenti

### 5. POST /api/agents/{agent_id}/execute
**Descrizione:** Esegui agente specifico con task personalizzato

**Parametri URL:**
- `agent_id` (string): ID agente (es. `vision_planner`, `seo_manager`)

**Request Body:**
```json
{
  "task": "Descrizione task da eseguire",
  "options": {
    "priority": "high",
    "timeout": 30
  }
}
```

**Esempi Request:**

**VisionPlanner AI:**
```bash
curl -X POST https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/agents/vision_planner/execute \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Pianifica strategia per startup AI nel settore e-commerce"
  }'
```

**SEOManager AI:**
```bash
curl -X POST https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/agents/seo_manager/execute \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Ottimizza SEO per keyword 'AI business automation'"
  }'
```

**MarketResearcher AI:**
```bash
curl -X POST https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/agents/market_researcher/execute \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Analizza mercato fintech Italia 2025"
  }'
```

**Response:**
```json
{
  "agent_id": "vision_planner",
  "agent_name": "VisionPlanner AI",
  "details": {
    "input_tokens": 150,
    "output_tokens": 300,
    "total_cost": "$0.002"
  },
  "execution_time": "2.3s",
  "mistral_model": "mistral-medium-latest",
  "result": "Task 'Pianifica strategia...' eseguito con successo da VisionPlanner AI",
  "status": "completed",
  "task": "Pianifica strategia per startup AI nel settore e-commerce",
  "timestamp": "2025-08-22T08:37:15.123456"
}
```

**JavaScript:**
```javascript
const executeAgent = async (agentId, task) => {
  const response = await fetch(`/api/agents/${agentId}/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ task })
  });
  return await response.json();
};

// Esempi utilizzo
const visionResult = await executeAgent('vision_planner', 'Pianifica app e-commerce');
const seoResult = await executeAgent('seo_manager', 'Ottimizza per keyword AI');
const marketResult = await executeAgent('market_researcher', 'Analizza competitor');
```

---

## 🔄 Esecuzione Workflow

### 6. POST /api/workflows/{workflow_id}/execute
**Descrizione:** Esegui workflow completo con multiple agenti coordinati

**Parametri URL:**
- `workflow_id` (string): ID workflow (`business_analysis`, `product_launch`, `marketing_automation`, `development_cycle`)

**Request Body:**
```json
{
  "project": "Nome progetto",
  "options": {
    "priority": "high",
    "parallel": true
  }
}
```

**Esempi Request:**

**Business Analysis Complete:**
```bash
curl -X POST https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/workflows/business_analysis/execute \
  -H "Content-Type: application/json" \
  -d '{
    "project": "Startup AI per PMI italiane"
  }'
```

**Product Launch Workflow:**
```bash
curl -X POST https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/workflows/product_launch/execute \
  -H "Content-Type: application/json" \
  -d '{
    "project": "App mobile fitness innovativa"
  }'
```

**Response:**
```json
{
  "agents_executed": 8,
  "execution_time": "15.7s",
  "project": "Startup AI per PMI italiane",
  "result": "Workflow 'Business Analysis Complete' completato per progetto 'Startup AI per PMI italiane'",
  "status": "completed",
  "steps": [
    {
      "agent": "VisionPlanner",
      "status": "completed",
      "step": 1,
      "time": "2.1s"
    },
    {
      "agent": "MarketResearcher",
      "status": "completed",
      "step": 2,
      "time": "2.1s"
    }
  ],
  "timestamp": "2025-08-22T08:37:15.123456",
  "workflow_id": "business_analysis",
  "workflow_name": "Business Analysis Complete"
}
```

---

## 🤖 Lista Completa Agenti (36)

### Core & Orchestrazione (2)
- `vision_planner` - VisionPlanner AI
- `workflow_orchestrator` - WorkflowOrchestrator AI

### Strategy & Business (4)
- `market_researcher` - MarketResearcher AI
- `finance_planner` - FinancePlanner AI
- `legal_advisor` - LegalAdvisor AI
- `brand_designer` - BrandDesigner AI

### Marketing & Content (6)
- `seo_manager` - SEOManager AI
- `copywriter` - Copywriter AI
- `content_strategist` - ContentStrategist AI
- `social_manager` - SocialManager AI
- `ad_optimizer` - AdOptimizer AI
- `email_marketer` - EmailMarketer AI

### Operations & Sales (5)
- `crm_manager` - CRMManager AI
- `sales_assistant` - SalesAssistant AI
- `customer_support` - CustomerSupport AI
- `chatbot` - Chatbot AI
- `feedback_analyzer` - FeedbackAnalyzer AI

### Product & E-commerce (6)
- `ecommerce_manager` - ECommerceManager AI
- `inventory_manager` - InventoryManager AI
- `supplier_coordinator` - SupplierCoordinator AI
- `production_planner` - ProductionPlanner AI
- `quality_control` - QualityControl AI
- `it_manager` - ITManager AI

### HR & Training (2)
- `hr_manager` - HRManager AI
- `training_coach` - TrainingCoach AI

### Data & Analytics (2)
- `data_analyst` - DataAnalyst AI
- `performance_tracker` - PerformanceTracker AI

### Compliance & Security (2)
- `compliance_monitor` - ComplianceMonitor AI
- `security_auditor` - SecurityAuditor AI

### Innovation & Growth (2)
- `innovation_scout` - InnovationScout AI
- `growth_strategist` - GrowthStrategist AI

### Development (5)
- `frontend_developer` - FrontendDeveloper AI
- `backend_developer` - BackendDeveloper AI
- `mobile_developer` - MobileDeveloper AI
- `devops_engineer` - DevOpsEngineer AI
- `qa_engineer` - QAEngineer AI

---

## 🔄 Workflow Predefiniti

### 1. Business Analysis Complete
**ID:** `business_analysis`  
**Agenti:** 8  
**Tempo:** 15-20 minuti  
**Descrizione:** Analisi business completa con visione, mercato, finanze, legale

### 2. Product Launch Workflow
**ID:** `product_launch`  
**Agenti:** 8  
**Tempo:** 20-25 minuti  
**Descrizione:** Lancio prodotto coordinato con marketing, sviluppo, operations

### 3. Marketing Automation
**ID:** `marketing_automation`  
**Agenti:** 6  
**Tempo:** 10-15 minuti  
**Descrizione:** Automazione marketing con SEO, content, social, email

### 4. Development Cycle
**ID:** `development_cycle`  
**Agenti:** 5  
**Tempo:** 15-20 minuti  
**Descrizione:** Ciclo sviluppo completo frontend, backend, mobile, QA

---

## 📝 Esempi Pratici JavaScript

### Inizializzazione Client
```javascript
// Usando la classe MistralAgentsAPI
const api = new MistralAgentsAPI('https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer', {
  debug: true,
  timeout: 30000,
  retries: 3
});
```

### Test Connessione
```javascript
const testConnection = async () => {
  try {
    const test = await api.testConnection();
    if (test.success) {
      console.log('✅ Sistema connesso:', test.responseTime + 'ms');
    } else {
      console.log('❌ Errore connessione:', test.error);
    }
  } catch (error) {
    console.error('Errore test:', error);
  }
};
```

### Esecuzione Agenti Singoli
```javascript
// VisionPlanner per strategia
const planStrategy = async () => {
  const result = await api.visionPlanner('Definisci strategia per startup fintech');
  console.log('Strategia:', result.result);
};

// SEOManager per traffico organico
const optimizeSEO = async () => {
  const result = await api.seoManager('Ottimizza SEO per keyword "AI automation"');
  console.log('SEO:', result.result);
};

// MarketResearcher per analisi mercato
const analyzeMarket = async () => {
  const result = await api.marketResearcher('Analizza mercato e-commerce Italia 2025');
  console.log('Mercato:', result.result);
};
```

### Workflow Completi
```javascript
// Business Analysis completa
const analyzeStartup = async () => {
  const result = await api.businessAnalysis('Startup AI per PMI');
  console.log('Analisi:', result);
  console.log('Agenti eseguiti:', result.agents_executed);
  console.log('Tempo totale:', result.execution_time);
};

// Product Launch
const launchProduct = async () => {
  const result = await api.productLaunch('App mobile fitness');
  console.log('Launch:', result);
};
```

### Esecuzione Parallela
```javascript
// Multiple agenti in parallelo
const parallelExecution = async () => {
  const tasks = [
    { agentId: 'vision_planner', task: 'Strategia business' },
    { agentId: 'seo_manager', task: 'Piano SEO' },
    { agentId: 'social_manager', task: 'Strategia social' },
    { agentId: 'data_analyst', task: 'Analisi dati' }
  ];
  
  const results = await api.executeMultipleAgents(tasks);
  results.forEach((result, index) => {
    if (result.error) {
      console.log(`❌ ${tasks[index].agentId}: ${result.error}`);
    } else {
      console.log(`✅ ${result.agent_name}: ${result.status}`);
    }
  });
};
```

### Esecuzione Sequenziale con Handoff
```javascript
// Agenti in sequenza con passaggio dati
const sequentialExecution = async () => {
  const sequence = [
    {
      agentId: 'vision_planner',
      task: 'Definisci visione per e-commerce moda',
      useOutput: false
    },
    {
      agentId: 'market_researcher',
      task: 'Analizza mercato moda online',
      useOutput: true // Usa output del precedente
    },
    {
      agentId: 'seo_manager',
      task: 'Strategia SEO per e-commerce moda',
      useOutput: true
    }
  ];
  
  const results = await api.executeSequentialAgents(sequence);
  console.log('Sequenza completata:', results.length, 'step');
};
```

### Monitoring Sistema
```javascript
// Monitoring real-time
const startMonitoring = () => {
  const stopMonitoring = api.startMonitoring((status) => {
    if (status.error) {
      console.log('❌ Sistema offline:', status.error);
    } else {
      console.log('✅ Sistema online:', status.stats.active_agents, 'agenti');
    }
  }, 30000); // Ogni 30 secondi
  
  // Per fermare dopo 5 minuti
  setTimeout(() => {
    stopMonitoring();
    console.log('Monitoring fermato');
  }, 300000);
};
```

---

## 🔧 Configurazione CORS

Il sistema è configurato per accettare richieste cross-origin. Per integrare nel tuo sito:

```javascript
// Headers automatici per CORS
const headers = {
  'Content-Type': 'application/json',
  'Accept': 'application/json'
};

// Fetch con CORS
const response = await fetch('https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer/api/stats', {
  method: 'GET',
  headers: headers,
  mode: 'cors' // Importante per cross-origin
});
```

---

## 📊 Rate Limiting e Best Practices

### Rate Limits
- **API Calls:** Illimitati per uso personale
- **Mistral API:** Limitato dalla tua quota API key
- **Timeout:** 30 secondi per request
- **Retry:** 3 tentativi automatici

### Best Practices
1. **Usa timeout appropriati** (30s per workflow, 15s per agenti singoli)
2. **Implementa retry logic** per robustezza
3. **Monitora usage Mistral API** per controllo costi
4. **Cache risultati** quando possibile
5. **Usa batch operations** per efficienza

### Error Handling
```javascript
const safeApiCall = async (apiFunction) => {
  try {
    const result = await apiFunction();
    return { success: true, data: result };
  } catch (error) {
    console.error('API Error:', error.message);
    return { success: false, error: error.message };
  }
};

// Utilizzo
const result = await safeApiCall(() => api.visionPlanner('Task'));
if (result.success) {
  console.log('Risultato:', result.data);
} else {
  console.log('Errore:', result.error);
}
```

---

## 🎯 Casi d'Uso Comuni

### 1. Analisi Business Startup
```javascript
const analyzeStartup = async (name, sector) => {
  // Sequenza completa analisi
  const vision = await api.visionPlanner(`Visione strategica ${name} settore ${sector}`);
  const market = await api.marketResearcher(`Analisi mercato ${sector}`);
  const finance = await api.financePlanner(`Business plan ${name}`);
  const legal = await api.executeAgent('legal_advisor', `Struttura legale ${name}`);
  
  return { vision, market, finance, legal };
};
```

### 2. Campagna Marketing Completa
```javascript
const createCampaign = async (product, target) => {
  const tasks = [
    { agentId: 'content_strategist', task: `Strategia contenuti ${product} per ${target}` },
    { agentId: 'seo_manager', task: `SEO strategy ${product}` },
    { agentId: 'social_manager', task: `Piano social ${product}` },
    { agentId: 'email_marketer', task: `Email campaign ${product}` }
  ];
  
  return await api.executeMultipleAgents(tasks);
};
```

### 3. Sviluppo Prodotto End-to-End
```javascript
const developProduct = async (productName) => {
  // Workflow completo sviluppo
  return await api.developmentCycle(`Sviluppo ${productName}`);
};
```

---

**🎯 Sistema pronto per integrazione nel tuo sito web!**

Tutti gli endpoint sono testati e funzionanti. Usa il file `mistral_agents_integration.js` per una integrazione rapida e completa.

