#!/usr/bin/env python3
"""
Render Deploy Completo Finale

Deploy Render completo con serviceDetails e configurazione corretta
"""

import asyncio
import json
import time
import httpx
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def deploy_render_complete_final():
    """Deploy Render completo finale."""
    logger.info("🚀 Deploy Render Completo Finale")
    
    # Configurazione corretta
    render_api_key = "rnd_3zUfxJUXfFLeP5CyVmCxv9ppypPF"
    mistral_api_key = "gJ200l66zgUiRZcUji9Sbr0bz8H8ALwz"
    correct_owner_id = "tea-d2k58um3jp1c73fr2vr0"
    
    headers = {
        "Authorization": f"Bearer {render_api_key}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    
    # Payload completo con serviceDetails
    payload = {
        "ownerId": correct_owner_id,
        "name": "mistral-agents-dashboard",
        "type": "web_service",
        "serviceDetails": {
            "env": "python",
            "buildCommand": "pip install -r requirements.txt",
            "startCommand": "gunicorn --bind 0.0.0.0:$PORT app:app",
            "publishPath": "./",
            "pullRequestPreviewsEnabled": False,
            "autoDeploy": True
        },
        "envVars": [
            {
                "key": "MISTRAL_API_KEY",
                "value": mistral_api_key
            },
            {
                "key": "PORT",
                "value": "10000"
            }
        ]
    }
    
    logger.info(f"🔑 Owner ID: {correct_owner_id}")
    logger.info("📦 Payload con serviceDetails completo")
    logger.info("🚀 Creazione servizio...")
    
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                "https://api.render.com/v1/services",
                headers=headers,
                json=payload
            )
            
            logger.info(f"📡 Response Status: {response.status_code}")
            
            if response.status_code == 201:
                data = response.json()
                service_id = data.get("id")
                service_url = data.get("serviceDetails", {}).get("url")
                
                logger.info(f"✅ Servizio creato con successo!")
                logger.info(f"   Service ID: {service_id}")
                logger.info(f"   Nome: {data.get('name')}")
                logger.info(f"   URL: {service_url}")
                logger.info(f"   Status: {data.get('status')}")
                
                # Attendi deploy
                logger.info("⏳ Attendo completamento deploy...")
                await asyncio.sleep(30)
                
                # Verifica URL
                if service_url:
                    logger.info(f"🔍 Verifica URL: {service_url}")
                    try:
                        verify_response = await client.get(service_url, timeout=30.0)
                        logger.info(f"   Status: {verify_response.status_code}")
                        if verify_response.status_code == 200:
                            logger.info("✅ URL funzionante!")
                        else:
                            logger.warning(f"⚠️ URL non ancora pronto: {verify_response.status_code}")
                    except Exception as e:
                        logger.warning(f"⚠️ Errore verifica URL: {e}")
                
                # Salva risultato
                result = {
                    "status": "success",
                    "service_id": service_id,
                    "service_url": service_url,
                    "service_data": data,
                    "owner_id_used": correct_owner_id,
                    "timestamp": datetime.now().isoformat(),
                    "deploy_successful": True
                }
                
                with open('render_deploy_final_success.json', 'w') as f:
                    json.dump(result, f, indent=2)
                
                return result
            
            else:
                try:
                    error_data = response.json()
                except:
                    error_data = {"raw_response": response.text}
                
                logger.error(f"❌ Errore {response.status_code}: {error_data}")
                
                result = {
                    "status": "failed",
                    "error_code": response.status_code,
                    "error_data": error_data,
                    "owner_id_used": correct_owner_id,
                    "timestamp": datetime.now().isoformat(),
                    "deploy_successful": False
                }
                
                with open('render_deploy_final_error.json', 'w') as f:
                    json.dump(result, f, indent=2)
                
                return result
    
    except Exception as e:
        logger.error(f"❌ Exception: {e}")
        
        result = {
            "status": "exception",
            "error": str(e),
            "owner_id_used": correct_owner_id,
            "timestamp": datetime.now().isoformat(),
            "deploy_successful": False
        }
        
        with open('render_deploy_final_exception.json', 'w') as f:
            json.dump(result, f, indent=2)
        
        return result

async def verify_render_url_final(url: str, max_attempts: int = 5):
    """Verifica URL Render finale."""
    logger.info(f"🔍 Verifica URL Finale: {url}")
    
    for attempt in range(max_attempts):
        try:
            logger.info(f"   Tentativo {attempt+1}/{max_attempts}")
            
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
                response = await client.get(url)
                
                status_code = response.status_code
                content = response.text
                content_size = len(content)
                
                logger.info(f"   Status: {status_code}")
                logger.info(f"   Content Size: {content_size} bytes")
                
                if status_code == 200:
                    # Analisi contenuto
                    has_dashboard = "dashboard" in content.lower()
                    has_agents = "agenti" in content.lower() or "agents" in content.lower()
                    has_mistral = "mistral" in content.lower()
                    
                    logger.info(f"   Dashboard: {'✅' if has_dashboard else '❌'}")
                    logger.info(f"   Agents: {'✅' if has_agents else '❌'}")
                    logger.info(f"   Mistral: {'✅' if has_mistral else '❌'}")
                    
                    if has_dashboard and has_agents:
                        logger.info("✅ URL verificato con successo!")
                        return {
                            "status": "success",
                            "url": url,
                            "status_code": status_code,
                            "content_size": content_size,
                            "has_dashboard": has_dashboard,
                            "has_agents": has_agents,
                            "has_mistral": has_mistral
                        }
                
                # Attendi prima del prossimo tentativo
                if attempt < max_attempts - 1:
                    await asyncio.sleep(30)
        
        except Exception as e:
            logger.warning(f"   ❌ Exception: {e}")
            if attempt < max_attempts - 1:
                await asyncio.sleep(10)
    
    logger.error("❌ Verifica URL fallita")
    return {
        "status": "failed",
        "url": url,
        "max_attempts": max_attempts
    }

async def main():
    """Main function."""
    print("🚀 Deploy Render Completo Finale")
    print("=" * 50)
    
    # Deploy servizio
    deploy_result = await deploy_render_complete_final()
    
    print("\n📊 RISULTATO DEPLOY:")
    print(f"Status: {deploy_result['status']}")
    
    if deploy_result['status'] == 'success':
        print(f"✅ Service ID: {deploy_result['service_id']}")
        print(f"✅ Service URL: {deploy_result.get('service_url', 'N/A')}")
        print("✅ Deploy riuscito!")
        
        # Verifica URL se disponibile
        service_url = deploy_result.get('service_url')
        if service_url:
            print(f"\n🔍 Verifica URL: {service_url}")
            verify_result = await verify_render_url_final(service_url)
            
            print(f"Verifica Status: {verify_result['status']}")
            if verify_result['status'] == 'success':
                print("✅ URL completamente funzionante!")
            else:
                print("⚠️ URL non ancora completamente pronto")
        
        # Verifica anche URL standard
        standard_url = "https://mistral-agents-dashboard.onrender.com"
        print(f"\n🔍 Verifica URL Standard: {standard_url}")
        standard_verify = await verify_render_url_final(standard_url)
        
        print(f"Standard URL Status: {standard_verify['status']}")
        if standard_verify['status'] == 'success':
            print("✅ URL standard funzionante!")
        
    else:
        print(f"❌ Errore: {deploy_result.get('error_data', deploy_result.get('error', 'Unknown'))}")
    
    return deploy_result

if __name__ == "__main__":
    asyncio.run(main())

