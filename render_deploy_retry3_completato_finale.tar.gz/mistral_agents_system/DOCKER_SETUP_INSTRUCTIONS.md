# 🐳 Setup Locale Docker - Sistema 36 Agenti AI

## Prerequisiti
- Docker e Docker Compose installati
- Porta 5000 e 80 disponibili

## Installazione Rapida

1. **Estrai il sistema:**
```bash
tar -xzf sistema_mistral_36_agenti_finale_completo.tar.gz
cd mistral_agents_system
```

2. **Configura environment:**
```bash
# Copia file env di esempio
cp .env.example .env

# Modifica la tua API key Mistral (opzionale, già configurata)
# MISTRAL_API_KEY=gJ200l66zgUiRZcUji9Sbr0bz8H8ALwz
```

3. **Avvia il sistema:**
```bash
# Build e start
docker-compose up --build -d

# Verifica status
docker-compose ps
```

4. **Accesso:**
- **Dashboard:** http://localhost
- **API:** http://localhost/api/stats
- **Health Check:** http://localhost/api/health

## Comandi Utili

```bash
# Logs in tempo reale
docker-compose logs -f

# Restart servizi
docker-compose restart

# Stop sistema
docker-compose down

# Update sistema
docker-compose pull && docker-compose up -d

# Backup configurazione
docker-compose exec mistral-agents-dashboard cp -r /app/config /app/logs/backup
```

## Test Sistema

```bash
# Test API
curl http://localhost/api/stats

# Test agente
curl -X POST http://localhost/api/agents/vision_planner/execute \
  -H "Content-Type: application/json" \
  -d '{"task": "Pianifica strategia startup"}'

# Test workflow
curl -X POST http://localhost/api/workflows/business_analysis/execute \
  -H "Content-Type: application/json" \
  -d '{"project": "Nuovo progetto AI"}'
```

## Configurazione Avanzata

### SSL/HTTPS (Opzionale)
```bash
# Genera certificati self-signed
mkdir ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout ssl/nginx.key -out ssl/nginx.crt

# Modifica nginx.conf per HTTPS
# Riavvia: docker-compose restart nginx
```

### Monitoring
```bash
# Prometheus metrics (opzionale)
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d
```

### Backup Automatico
```bash
# Crea script backup
cat > backup.sh << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
docker-compose exec mistral-agents-dashboard tar -czf /app/logs/backup_$DATE.tar.gz /app/config /app/logs
EOF

chmod +x backup.sh
```

## Troubleshooting

### Problemi Comuni

1. **Porta occupata:**
```bash
# Cambia porta in docker-compose.yml
ports:
  - "8080:5000"  # Usa porta 8080 invece di 5000
```

2. **Errori API Mistral:**
```bash
# Verifica API key
docker-compose exec mistral-agents-dashboard env | grep MISTRAL

# Test connessione
docker-compose exec mistral-agents-dashboard curl -H "Authorization: Bearer $MISTRAL_API_KEY" https://api.mistral.ai/v1/models
```

3. **Performance lenta:**
```bash
# Aumenta workers
# Modifica CMD in Dockerfile: --workers 4
docker-compose up --build -d
```

4. **Logs debug:**
```bash
# Abilita debug mode
echo "FLASK_DEBUG=1" >> .env
docker-compose restart
```

## Integrazione Sito Web

### JavaScript Client
```javascript
// Usa il client fornito
const api = new MistralAgentsAPI('http://localhost');

// Test connessione
const test = await api.testConnection();
console.log('Sistema locale:', test.success);

// Esegui agente
const result = await api.visionPlanner('Pianifica strategia');
console.log('Risultato:', result);
```

### CORS Configuration
Il sistema è già configurato per CORS. Per domini specifici, modifica `nginx.conf`:
```nginx
add_header Access-Control-Allow-Origin "https://mio-sito.com";
```

## Monitoraggio

### Health Checks
```bash
# Status sistema
curl http://localhost/api/health

# Metriche dettagliate
curl http://localhost/api/stats
```

### Logs
```bash
# Logs applicazione
docker-compose logs mistral-agents-dashboard

# Logs nginx
docker-compose logs nginx

# Logs in tempo reale
docker-compose logs -f --tail=100
```

## Aggiornamenti

```bash
# Backup configurazione
docker-compose exec mistral-agents-dashboard cp -r /app/config /tmp/backup

# Update immagini
docker-compose pull

# Restart con nuove immagini
docker-compose up -d

# Restore configurazione se necessario
docker-compose exec mistral-agents-dashboard cp -r /tmp/backup/* /app/config/
```

## Supporto

- **Logs:** `docker-compose logs`
- **Health Check:** `http://localhost/api/health`
- **API Documentation:** Vedi `api_documentation.md`
- **JavaScript SDK:** Vedi `mistral_agents_integration.js`

**🎉 Sistema pronto per uso locale! 🚀**
