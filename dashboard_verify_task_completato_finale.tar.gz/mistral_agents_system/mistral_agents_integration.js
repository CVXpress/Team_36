/**
 * Mistral AI - 36 Agenti Integration Script
 * 
 * Script JavaScript per integrare il sistema 36 Agenti AI nel tuo sito web.
 * Fornisce funzioni per chiamare API, eseguire agenti e gestire workflow.
 * 
 * @version 3.0
 * @author Manus AI
 * @date 2025-08-22
 */

class MistralAgentsAPI {
    /**
     * Inizializza client API per sistema 36 Agenti AI
     * @param {string} baseUrl - URL base dashboard (es. https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer)
     * @param {Object} options - Opzioni configurazione
     */
    constructor(baseUrl, options = {}) {
        this.baseUrl = baseUrl.replace(/\/$/, ''); // Rimuovi trailing slash
        this.timeout = options.timeout || 30000; // 30 secondi default
        this.retries = options.retries || 3;
        this.debug = options.debug || false;
        
        // Headers default
        this.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            ...options.headers
        };
        
        this.log('🚀 Mistral Agents API Client inizializzato', { baseUrl: this.baseUrl });
    }
    
    /**
     * Log debug se abilitato
     */
    log(message, data = null) {
        if (this.debug) {
            console.log(`[MistralAgentsAPI] ${message}`, data || '');
        }
    }
    
    /**
     * Esegue chiamata HTTP con retry automatico
     * @param {string} endpoint - Endpoint API
     * @param {Object} options - Opzioni fetch
     * @returns {Promise<Object>} Response JSON
     */
    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        const config = {
            timeout: this.timeout,
            headers: this.headers,
            ...options
        };
        
        this.log(`📡 API Call: ${options.method || 'GET'} ${endpoint}`, config.body);
        
        for (let attempt = 1; attempt <= this.retries; attempt++) {
            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), this.timeout);
                
                const response = await fetch(url, {
                    ...config,
                    signal: controller.signal
                });
                
                clearTimeout(timeoutId);
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                
                const data = await response.json();
                this.log(`✅ API Success: ${endpoint}`, data);
                return data;
                
            } catch (error) {
                this.log(`❌ API Error (attempt ${attempt}/${this.retries}): ${endpoint}`, error.message);
                
                if (attempt === this.retries) {
                    throw new Error(`API call failed after ${this.retries} attempts: ${error.message}`);
                }
                
                // Delay esponenziale per retry
                await this.delay(Math.pow(2, attempt) * 1000);
            }
        }
    }
    
    /**
     * Delay helper per retry
     */
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // ==================== API ENDPOINTS ====================
    
    /**
     * Ottieni statistiche sistema
     * @returns {Promise<Object>} Statistiche sistema
     */
    async getStats() {
        return await this.request('/api/stats');
    }
    
    /**
     * Ottieni lista di tutti i 36 agenti
     * @returns {Promise<Object>} Lista agenti con categorie
     */
    async getAgents() {
        return await this.request('/api/agents');
    }
    
    /**
     * Ottieni workflow disponibili
     * @returns {Promise<Object>} Lista workflow
     */
    async getWorkflows() {
        return await this.request('/api/workflows');
    }
    
    /**
     * Health check sistema
     * @returns {Promise<Object>} Status salute sistema
     */
    async getHealth() {
        return await this.request('/api/health');
    }
    
    /**
     * Esegui agente specifico con task
     * @param {string} agentId - ID agente (es. 'vision_planner')
     * @param {string} task - Task da eseguire
     * @param {Object} options - Opzioni aggiuntive
     * @returns {Promise<Object>} Risultato esecuzione agente
     */
    async executeAgent(agentId, task, options = {}) {
        const payload = {
            task: task,
            ...options
        };
        
        return await this.request(`/api/agents/${agentId}/execute`, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    }
    
    /**
     * Esegui workflow completo
     * @param {string} workflowId - ID workflow (es. 'business_analysis')
     * @param {string} project - Nome progetto
     * @param {Object} options - Opzioni aggiuntive
     * @returns {Promise<Object>} Risultato workflow
     */
    async executeWorkflow(workflowId, project, options = {}) {
        const payload = {
            project: project,
            ...options
        };
        
        return await this.request(`/api/workflows/${workflowId}/execute`, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    }
    
    // ==================== AGENTI SPECIFICI ====================
    
    /**
     * VisionPlanner AI - Strategia aziendale
     */
    async visionPlanner(task) {
        return await this.executeAgent('vision_planner', task);
    }
    
    /**
     * MarketResearcher AI - Ricerca mercato
     */
    async marketResearcher(task) {
        return await this.executeAgent('market_researcher', task);
    }
    
    /**
     * FinancePlanner AI - Pianificazione finanziaria
     */
    async financePlanner(task) {
        return await this.executeAgent('finance_planner', task);
    }
    
    /**
     * SEOManager AI - Ottimizzazione SEO
     */
    async seoManager(task) {
        return await this.executeAgent('seo_manager', task);
    }
    
    /**
     * ContentStrategist AI - Strategia contenuti
     */
    async contentStrategist(task) {
        return await this.executeAgent('content_strategist', task);
    }
    
    /**
     * SocialManager AI - Social media management
     */
    async socialManager(task) {
        return await this.executeAgent('social_manager', task);
    }
    
    /**
     * DataAnalyst AI - Analisi dati
     */
    async dataAnalyst(task) {
        return await this.executeAgent('data_analyst', task);
    }
    
    /**
     * FrontendDeveloper AI - Sviluppo frontend
     */
    async frontendDeveloper(task) {
        return await this.executeAgent('frontend_developer', task);
    }
    
    /**
     * BackendDeveloper AI - Sviluppo backend
     */
    async backendDeveloper(task) {
        return await this.executeAgent('backend_developer', task);
    }
    
    // ==================== WORKFLOW PREDEFINITI ====================
    
    /**
     * Business Analysis completa (8 agenti)
     */
    async businessAnalysis(project) {
        return await this.executeWorkflow('business_analysis', project);
    }
    
    /**
     * Product Launch workflow (8 agenti)
     */
    async productLaunch(project) {
        return await this.executeWorkflow('product_launch', project);
    }
    
    /**
     * Marketing Automation (6 agenti)
     */
    async marketingAutomation(project) {
        return await this.executeWorkflow('marketing_automation', project);
    }
    
    /**
     * Development Cycle (5 agenti)
     */
    async developmentCycle(project) {
        return await this.executeWorkflow('development_cycle', project);
    }
    
    // ==================== BATCH OPERATIONS ====================
    
    /**
     * Esegui multiple agenti in parallelo
     * @param {Array} tasks - Array di {agentId, task}
     * @returns {Promise<Array>} Risultati paralleli
     */
    async executeMultipleAgents(tasks) {
        this.log('🔄 Esecuzione batch agenti', { count: tasks.length });
        
        const promises = tasks.map(({ agentId, task, options }) => 
            this.executeAgent(agentId, task, options)
                .catch(error => ({ error: error.message, agentId, task }))
        );
        
        const results = await Promise.all(promises);
        
        const successful = results.filter(r => !r.error).length;
        this.log(`✅ Batch completato: ${successful}/${tasks.length} successi`);
        
        return results;
    }
    
    /**
     * Esegui agenti in sequenza con handoff dati
     * @param {Array} sequence - Array di {agentId, task, useOutput}
     * @returns {Promise<Array>} Risultati sequenziali
     */
    async executeSequentialAgents(sequence) {
        this.log('🔄 Esecuzione sequenziale agenti', { count: sequence.length });
        
        const results = [];
        let previousOutput = null;
        
        for (const { agentId, task, useOutput } of sequence) {
            try {
                const finalTask = useOutput && previousOutput 
                    ? `${task}\n\nInput dal precedente agente: ${JSON.stringify(previousOutput)}`
                    : task;
                
                const result = await this.executeAgent(agentId, finalTask);
                results.push(result);
                previousOutput = result;
                
                this.log(`✅ Agente ${agentId} completato`);
                
            } catch (error) {
                this.log(`❌ Agente ${agentId} fallito: ${error.message}`);
                results.push({ error: error.message, agentId, task });
                break; // Interrompi sequenza su errore
            }
        }
        
        return results;
    }
    
    // ==================== MONITORING E UTILITIES ====================
    
    /**
     * Monitora status sistema
     * @param {Function} callback - Callback per aggiornamenti status
     * @param {number} interval - Intervallo polling (ms)
     * @returns {Function} Stop function
     */
    startMonitoring(callback, interval = 30000) {
        this.log('📊 Avvio monitoring sistema', { interval });
        
        const monitor = async () => {
            try {
                const [stats, health] = await Promise.all([
                    this.getStats(),
                    this.getHealth()
                ]);
                
                callback({
                    timestamp: new Date().toISOString(),
                    stats,
                    health,
                    status: 'online'
                });
                
            } catch (error) {
                callback({
                    timestamp: new Date().toISOString(),
                    error: error.message,
                    status: 'error'
                });
            }
        };
        
        // Prima esecuzione immediata
        monitor();
        
        // Polling periodico
        const intervalId = setInterval(monitor, interval);
        
        // Ritorna funzione per fermare monitoring
        return () => {
            clearInterval(intervalId);
            this.log('⏹️ Monitoring fermato');
        };
    }
    
    /**
     * Test connessione sistema
     * @returns {Promise<Object>} Risultato test
     */
    async testConnection() {
        this.log('🧪 Test connessione sistema');
        
        try {
            const start = Date.now();
            const health = await this.getHealth();
            const responseTime = Date.now() - start;
            
            return {
                success: true,
                responseTime,
                health,
                timestamp: new Date().toISOString()
            };
            
        } catch (error) {
            return {
                success: false,
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }
}

// ==================== ESEMPI DI UTILIZZO ====================

/**
 * Esempi pratici di utilizzo del sistema
 */
class MistralAgentsExamples {
    constructor(api) {
        this.api = api;
    }
    
    /**
     * Esempio: Analisi completa startup
     */
    async analyzeStartup(startupName, sector) {
        console.log(`🚀 Analisi startup: ${startupName} (${sector})`);
        
        // Sequenza agenti per analisi completa
        const sequence = [
            {
                agentId: 'vision_planner',
                task: `Definisci visione strategica per startup ${startupName} nel settore ${sector}`,
                useOutput: false
            },
            {
                agentId: 'market_researcher',
                task: `Analizza mercato ${sector} per startup ${startupName}`,
                useOutput: true
            },
            {
                agentId: 'finance_planner',
                task: `Crea business plan finanziario per ${startupName}`,
                useOutput: true
            },
            {
                agentId: 'seo_manager',
                task: `Strategia SEO per ${startupName} nel settore ${sector}`,
                useOutput: true
            }
        ];
        
        return await this.api.executeSequentialAgents(sequence);
    }
    
    /**
     * Esempio: Campagna marketing completa
     */
    async createMarketingCampaign(product, target) {
        console.log(`📢 Campagna marketing: ${product} per ${target}`);
        
        const tasks = [
            { agentId: 'content_strategist', task: `Strategia contenuti per ${product} target ${target}` },
            { agentId: 'social_manager', task: `Piano social media per ${product}` },
            { agentId: 'seo_manager', task: `SEO strategy per ${product}` },
            { agentId: 'email_marketer', task: `Email campaign per ${product}` }
        ];
        
        return await this.api.executeMultipleAgents(tasks);
    }
    
    /**
     * Esempio: Sviluppo app completo
     */
    async developApp(appName, features) {
        console.log(`💻 Sviluppo app: ${appName}`);
        
        // Workflow development completo
        return await this.api.developmentCycle(`App ${appName} con features: ${features.join(', ')}`);
    }
}

// ==================== EXPORT E INIZIALIZZAZIONE ====================

// Per uso in browser (global)
if (typeof window !== 'undefined') {
    window.MistralAgentsAPI = MistralAgentsAPI;
    window.MistralAgentsExamples = MistralAgentsExamples;
}

// Per uso in Node.js (module)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MistralAgentsAPI, MistralAgentsExamples };
}

// ==================== QUICK START GUIDE ====================

/*
QUICK START GUIDE:

1. Inizializzazione:
```javascript
const api = new MistralAgentsAPI('https://5000-igxrw3pz80542qv7o93r9-ab33dbfc.manusvm.computer', {
    debug: true,
    timeout: 30000
});
```

2. Test connessione:
```javascript
const test = await api.testConnection();
console.log('Test:', test);
```

3. Esegui singolo agente:
```javascript
const result = await api.visionPlanner('Pianifica strategia per e-commerce moda');
console.log('Risultato:', result);
```

4. Esegui workflow completo:
```javascript
const analysis = await api.businessAnalysis('Startup AI per PMI');
console.log('Analisi:', analysis);
```

5. Monitoring sistema:
```javascript
const stopMonitoring = api.startMonitoring((status) => {
    console.log('Status sistema:', status);
}, 30000);

// Per fermare: stopMonitoring();
```

6. Esempi avanzati:
```javascript
const examples = new MistralAgentsExamples(api);

// Analisi startup completa
const startupAnalysis = await examples.analyzeStartup('TechCorp', 'AI/ML');

// Campagna marketing
const campaign = await examples.createMarketingCampaign('App Fitness', 'Millennials');

// Sviluppo app
const appDev = await examples.developApp('FoodDelivery', ['GPS', 'Payment', 'Reviews']);
```

ENDPOINTS DISPONIBILI:
- GET /api/stats - Statistiche sistema
- GET /api/agents - Lista 36 agenti
- GET /api/workflows - Workflow disponibili
- GET /api/health - Health check
- POST /api/agents/{id}/execute - Esegui agente
- POST /api/workflows/{id}/execute - Esegui workflow

AGENTI DISPONIBILI (36 totali):
- vision_planner, market_researcher, finance_planner, legal_advisor
- brand_designer, seo_manager, copywriter, content_strategist
- social_manager, ad_optimizer, email_marketer, crm_manager
- sales_assistant, customer_support, chatbot, feedback_analyzer
- ecommerce_manager, inventory_manager, supplier_coordinator
- production_planner, quality_control, it_manager, hr_manager
- training_coach, data_analyst, performance_tracker
- compliance_monitor, security_auditor, innovation_scout
- growth_strategist, frontend_developer, backend_developer
- mobile_developer, devops_engineer, qa_engineer

WORKFLOW DISPONIBILI:
- business_analysis (8 agenti)
- product_launch (8 agenti)
- marketing_automation (6 agenti)
- development_cycle (5 agenti)
*/

