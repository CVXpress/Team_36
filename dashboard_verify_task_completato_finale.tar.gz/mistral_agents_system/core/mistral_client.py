"""
Mistral AI Client Module

Client per integrazione con Mistral AI API con gestione avanzata
di rate limiting, retry logic e error handling.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import json
import time
from typing import Dict, List, Optional, Any, AsyncGenerator
import httpx
import logging
from dataclasses import dataclass, asdict
from enum import Enum

from config.mistral_config import MistralConfig, SystemConfig


class MessageRole(Enum):
    """Ruoli dei messaggi nella conversazione."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


@dataclass
class ChatMessage:
    """Messaggio nella conversazione."""
    role: MessageRole
    content: str
    
    def to_dict(self) -> Dict[str, str]:
        return {
            "role": self.role.value,
            "content": self.content
        }


@dataclass
class ChatCompletionRequest:
    """Richiesta di chat completion."""
    messages: List[ChatMessage]
    model: str
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    stream: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        data = {
            "model": self.model,
            "messages": [msg.to_dict() for msg in self.messages]
        }
        
        if self.max_tokens is not None:
            data["max_tokens"] = self.max_tokens
        if self.temperature is not None:
            data["temperature"] = self.temperature
        if self.top_p is not None:
            data["top_p"] = self.top_p
        if self.stream:
            data["stream"] = self.stream
            
        return data


@dataclass
class ChatCompletionResponse:
    """Risposta di chat completion."""
    id: str
    model: str
    content: str
    usage: Dict[str, int]
    finish_reason: str
    created: int
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ChatCompletionResponse':
        choice = data["choices"][0]
        return cls(
            id=data["id"],
            model=data["model"],
            content=choice["message"]["content"],
            usage=data.get("usage", {}),
            finish_reason=choice.get("finish_reason", "stop"),
            created=data.get("created", int(time.time()))
        )


class MistralClient:
    """
    Client per Mistral AI API con funzionalità avanzate.
    
    Features:
    - Rate limiting automatico
    - Retry logic con backoff esponenziale
    - Streaming support
    - Error handling robusto
    - Metrics e logging
    """
    
    def __init__(self, config: MistralConfig = None):
        """
        Inizializza client Mistral AI.
        
        Args:
            config: Configurazione Mistral AI
        """
        self.config = config or SystemConfig.MISTRAL_CONFIG
        self.logger = logging.getLogger(__name__)
        
        # Setup HTTP client
        self.client = httpx.AsyncClient(
            base_url=self.config.base_url,
            timeout=self.config.timeout,
            headers={
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "MistralAgentsSystem/2.0"
            }
        )
        
        # Rate limiting
        self.rate_limit_requests = 100  # requests per minute
        self.rate_limit_window = 60  # seconds
        self.request_times = []
        
        # Metrics
        self.metrics = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "total_tokens": 0,
            "average_response_time": 0.0
        }
    
    async def __aenter__(self):
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
    
    async def close(self):
        """Chiude il client HTTP."""
        await self.client.aclose()
    
    def _check_rate_limit(self) -> bool:
        """Verifica rate limiting."""
        now = time.time()
        
        # Rimuovi richieste vecchie
        self.request_times = [
            req_time for req_time in self.request_times 
            if now - req_time < self.rate_limit_window
        ]
        
        # Verifica limite
        if len(self.request_times) >= self.rate_limit_requests:
            return False
        
        self.request_times.append(now)
        return True
    
    async def _wait_for_rate_limit(self):
        """Attende per rispettare rate limiting."""
        while not self._check_rate_limit():
            await asyncio.sleep(1)
    
    async def _make_request(
        self, 
        endpoint: str, 
        data: Dict[str, Any],
        stream: bool = False
    ) -> Dict[str, Any]:
        """
        Effettua richiesta HTTP con retry logic.
        
        Args:
            endpoint: Endpoint API
            data: Dati della richiesta
            stream: Se utilizzare streaming
            
        Returns:
            Risposta API
        """
        await self._wait_for_rate_limit()
        
        start_time = time.time()
        last_exception = None
        
        for attempt in range(self.config.max_retries):
            try:
                self.logger.debug(f"Richiesta a {endpoint}, tentativo {attempt + 1}")
                
                if stream:
                    response = await self.client.post(
                        endpoint,
                        json=data,
                        headers={"Accept": "text/event-stream"}
                    )
                else:
                    response = await self.client.post(endpoint, json=data)
                
                response.raise_for_status()
                
                # Update metrics
                response_time = time.time() - start_time
                self.metrics["total_requests"] += 1
                self.metrics["successful_requests"] += 1
                self._update_average_response_time(response_time)
                
                if stream:
                    return response
                else:
                    return response.json()
                
            except httpx.HTTPStatusError as e:
                last_exception = e
                self.logger.warning(f"HTTP error {e.response.status_code}: {e}")
                
                # Non fare retry per errori client (4xx)
                if 400 <= e.response.status_code < 500:
                    break
                
                # Backoff esponenziale per errori server (5xx)
                if attempt < self.config.max_retries - 1:
                    wait_time = 2 ** attempt
                    await asyncio.sleep(wait_time)
                    
            except Exception as e:
                last_exception = e
                self.logger.warning(f"Errore richiesta: {e}")
                
                if attempt < self.config.max_retries - 1:
                    wait_time = 2 ** attempt
                    await asyncio.sleep(wait_time)
        
        # Update failed metrics
        self.metrics["failed_requests"] += 1
        raise last_exception
    
    def _update_average_response_time(self, response_time: float):
        """Aggiorna tempo medio di risposta."""
        total_requests = self.metrics["successful_requests"]
        current_avg = self.metrics["average_response_time"]
        
        self.metrics["average_response_time"] = (
            (current_avg * (total_requests - 1) + response_time) / total_requests
        )
    
    async def chat_completion(
        self,
        messages: List[ChatMessage],
        model: str = None,
        max_tokens: int = None,
        temperature: float = None,
        top_p: float = None
    ) -> ChatCompletionResponse:
        """
        Effettua chat completion.
        
        Args:
            messages: Lista messaggi conversazione
            model: Modello da utilizzare
            max_tokens: Numero massimo token
            temperature: Temperatura per sampling
            top_p: Top-p per nucleus sampling
            
        Returns:
            Risposta chat completion
        """
        request = ChatCompletionRequest(
            messages=messages,
            model=model or self.config.model,
            max_tokens=max_tokens or self.config.max_tokens,
            temperature=temperature or self.config.temperature,
            top_p=top_p or self.config.top_p
        )
        
        self.logger.info(f"Chat completion con {len(messages)} messaggi")
        
        response_data = await self._make_request("/chat/completions", request.to_dict())
        response = ChatCompletionResponse.from_dict(response_data)
        
        # Update token metrics
        if response.usage:
            self.metrics["total_tokens"] += response.usage.get("total_tokens", 0)
        
        return response
    
    async def chat_completion_stream(
        self,
        messages: List[ChatMessage],
        model: str = None,
        max_tokens: int = None,
        temperature: float = None,
        top_p: float = None
    ) -> AsyncGenerator[str, None]:
        """
        Effettua chat completion con streaming.
        
        Args:
            messages: Lista messaggi conversazione
            model: Modello da utilizzare
            max_tokens: Numero massimo token
            temperature: Temperatura per sampling
            top_p: Top-p per nucleus sampling
            
        Yields:
            Chunk di testo della risposta
        """
        request = ChatCompletionRequest(
            messages=messages,
            model=model or self.config.model,
            max_tokens=max_tokens or self.config.max_tokens,
            temperature=temperature or self.config.temperature,
            top_p=top_p or self.config.top_p,
            stream=True
        )
        
        self.logger.info(f"Chat completion streaming con {len(messages)} messaggi")
        
        response = await self._make_request("/chat/completions", request.to_dict(), stream=True)
        
        async for line in response.aiter_lines():
            if line.startswith("data: "):
                data_str = line[6:]  # Rimuovi "data: "
                
                if data_str.strip() == "[DONE]":
                    break
                
                try:
                    data = json.loads(data_str)
                    if "choices" in data and data["choices"]:
                        delta = data["choices"][0].get("delta", {})
                        if "content" in delta:
                            yield delta["content"]
                except json.JSONDecodeError:
                    continue
    
    async def simple_completion(
        self,
        prompt: str,
        system_message: str = None,
        **kwargs
    ) -> str:
        """
        Effettua completion semplice con prompt.
        
        Args:
            prompt: Prompt utente
            system_message: Messaggio di sistema (opzionale)
            **kwargs: Parametri aggiuntivi
            
        Returns:
            Risposta del modello
        """
        messages = []
        
        if system_message:
            messages.append(ChatMessage(MessageRole.SYSTEM, system_message))
        
        messages.append(ChatMessage(MessageRole.USER, prompt))
        
        response = await self.chat_completion(messages, **kwargs)
        return response.content
    
    async def agent_completion(
        self,
        agent_name: str,
        task_description: str,
        context: Dict[str, Any] = None,
        **kwargs
    ) -> str:
        """
        Effettua completion per agente specifico.
        
        Args:
            agent_name: Nome dell'agente
            task_description: Descrizione del task
            context: Context aggiuntivo
            **kwargs: Parametri aggiuntivi
            
        Returns:
            Risposta dell'agente
        """
        from config.mistral_config import get_agent_config
        
        agent_config = get_agent_config(agent_name)
        if not agent_config:
            raise ValueError(f"Agente {agent_name} non trovato")
        
        # Costruisci system message
        system_message = f"""Sei {agent_config.name}, un {agent_config.role}.

Il tuo obiettivo è: {agent_config.goal}

Background: {agent_config.backstory}

Strumenti disponibili: {', '.join(agent_config.tools)}

Rispondi sempre nel ruolo dell'agente, fornendo soluzioni pratiche e actionable."""
        
        # Aggiungi context se fornito
        user_message = task_description
        if context:
            user_message += f"\n\nContext aggiuntivo:\n{json.dumps(context, indent=2)}"
        
        return await self.simple_completion(
            user_message,
            system_message,
            **kwargs
        )
    
    def get_metrics(self) -> Dict[str, Any]:
        """Restituisce metriche del client."""
        return self.metrics.copy()
    
    async def health_check(self) -> bool:
        """Verifica salute del servizio Mistral AI."""
        try:
            response = await self.simple_completion(
                "Test di connessione. Rispondi solo 'OK'.",
                max_tokens=10
            )
            return "OK" in response.upper()
        except Exception as e:
            self.logger.error(f"Health check fallito: {e}")
            return False


# Factory function per creare client
def create_mistral_client(config: MistralConfig = None) -> MistralClient:
    """Crea istanza client Mistral AI."""
    return MistralClient(config)


# Singleton client globale
_global_client: Optional[MistralClient] = None


async def get_global_client() -> MistralClient:
    """Ottiene client globale singleton."""
    global _global_client
    
    if _global_client is None:
        _global_client = create_mistral_client()
    
    return _global_client


async def close_global_client():
    """Chiude client globale."""
    global _global_client
    
    if _global_client:
        await _global_client.close()
        _global_client = None


# Utility functions
async def quick_completion(prompt: str, **kwargs) -> str:
    """Completion rapida con client globale."""
    client = await get_global_client()
    return await client.simple_completion(prompt, **kwargs)


async def quick_agent_completion(agent_name: str, task: str, **kwargs) -> str:
    """Completion rapida per agente con client globale."""
    client = await get_global_client()
    return await client.agent_completion(agent_name, task, **kwargs)


if __name__ == "__main__":
    import asyncio
    
    async def test_client():
        """Test del client Mistral AI."""
        print("=== Test Mistral AI Client ===")
        
        async with MistralClient() as client:
            # Health check
            print("🔍 Health check...")
            healthy = await client.health_check()
            print(f"   Status: {'✅ OK' if healthy else '❌ FAIL'}")
            
            if healthy:
                # Test completion semplice
                print("\n💬 Test completion semplice...")
                response = await client.simple_completion(
                    "Ciao! Come stai?",
                    max_tokens=50
                )
                print(f"   Risposta: {response}")
                
                # Test agent completion
                print("\n🤖 Test agent completion...")
                agent_response = await client.agent_completion(
                    "tech_lead",
                    "Progetta l'architettura per un'app mobile di e-commerce",
                    max_tokens=200
                )
                print(f"   Risposta TechLead: {agent_response[:100]}...")
                
                # Mostra metriche
                print("\n📊 Metriche:")
                metrics = client.get_metrics()
                for key, value in metrics.items():
                    print(f"   {key}: {value}")
    
    # Esegui test
    asyncio.run(test_client())

