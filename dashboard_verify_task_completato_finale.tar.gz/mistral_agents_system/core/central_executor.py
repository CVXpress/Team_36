"""
Central Executor for Multi-Agent System

Executor centrale che orchestra tutti i 36 agenti AI specializzati,
gestisce task complessi, workflow e comunicazione inter-agente.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import json
import time
import uuid
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging
from concurrent.futures import ThreadPoolExecutor
import threading

from agents.base_agent import BaseAgent, Task, TaskStatus, TaskPriority, AgentFactory
from agents.core.workflow_orchestrator import WorkflowOrchestratorAgent, Workflow
from core.mistral_client import MistralClient, create_mistral_client
from config.mistral_config import SystemConfig, get_all_agents_config


class ExecutorStatus(Enum):
    """Stati dell'executor centrale."""
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class ExecutionContext:
    """Context di esecuzione per task complessi."""
    session_id: str
    user_id: Optional[str] = None
    priority: TaskPriority = TaskPriority.MEDIUM
    timeout: int = 600  # 10 minutes default
    metadata: Dict[str, Any] = field(default_factory=dict)
    shared_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionResult:
    """Risultato di esecuzione task/workflow."""
    success: bool
    result: Dict[str, Any]
    execution_time: float
    agents_involved: List[str]
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class CentralExecutor:
    """
    Executor centrale per sistema multi-agente.
    
    Responsabilità:
    - Orchestrazione di tutti i 36 agenti AI
    - Gestione task complessi e workflow
    - Load balancing e resource management
    - Inter-agent communication
    - Monitoring e analytics
    - Error handling e recovery
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inizializza executor centrale.
        
        Args:
            config: Configurazione personalizzata
        """
        self.config = config or {}
        self.logger = logging.getLogger(__name__)
        
        # Stato executor
        self.status = ExecutorStatus.INITIALIZING
        self.start_time = time.time()
        
        # Agenti registrati
        self.agents: Dict[str, BaseAgent] = {}
        self.agent_status: Dict[str, Dict[str, Any]] = {}
        
        # Task management
        self.active_tasks: Dict[str, Task] = {}
        self.task_queue: asyncio.Queue = asyncio.Queue()
        self.completed_tasks: List[Task] = []
        
        # Workflow management
        self.workflow_orchestrator: Optional[WorkflowOrchestratorAgent] = None
        self.active_workflows: Dict[str, Dict[str, Any]] = {}
        
        # Execution management
        self.execution_contexts: Dict[str, ExecutionContext] = {}
        self.max_concurrent_tasks = self.config.get('max_concurrent_tasks', SystemConfig.MAX_CONCURRENT_AGENTS)
        self.task_semaphore = asyncio.Semaphore(self.max_concurrent_tasks)
        
        # Mistral client
        self.mistral_client: Optional[MistralClient] = None
        
        # Metrics e monitoring
        self.metrics = {
            'total_tasks_executed': 0,
            'successful_tasks': 0,
            'failed_tasks': 0,
            'total_execution_time': 0.0,
            'average_task_time': 0.0,
            'agents_utilization': {},
            'workflow_metrics': {}
        }
        
        # Event callbacks
        self.event_callbacks: Dict[str, List[Callable]] = {
            'task_started': [],
            'task_completed': [],
            'task_failed': [],
            'workflow_started': [],
            'workflow_completed': [],
            'agent_error': []
        }
        
        # Background tasks
        self.background_tasks: List[asyncio.Task] = []
        self._shutdown_event = asyncio.Event()
        
        self.logger.info("Central Executor inizializzato")
    
    async def initialize(self) -> bool:
        """
        Inizializza executor e tutti gli agenti.
        
        Returns:
            True se inizializzazione riuscita
        """
        try:
            self.logger.info("Inizializzazione Central Executor...")
            
            # Inizializza Mistral client
            self.mistral_client = create_mistral_client()
            
            # Health check Mistral
            if not await self.mistral_client.health_check():
                raise RuntimeError("Mistral AI non disponibile")
            
            # Inizializza tutti gli agenti
            await self._initialize_agents()
            
            # Inizializza workflow orchestrator
            await self._initialize_workflow_orchestrator()
            
            # Avvia background tasks
            await self._start_background_tasks()
            
            self.status = ExecutorStatus.RUNNING
            self.logger.info(f"Central Executor inizializzato con {len(self.agents)} agenti")
            
            return True
            
        except Exception as e:
            self.status = ExecutorStatus.ERROR
            self.logger.error(f"Errore inizializzazione: {e}")
            return False
    
    async def _initialize_agents(self):
        """Inizializza tutti i 36 agenti."""
        
        agents_config = get_all_agents_config()
        
        for agent_name, agent_config in agents_config.items():
            try:
                # Crea agente usando factory
                agent = AgentFactory.create_agent(
                    agent_name,
                    agent_config,
                    self.mistral_client
                )
                
                # Setup callbacks
                agent.on_task_completed = self._on_agent_task_completed
                agent.on_task_failed = self._on_agent_task_failed
                agent.on_delegation_request = self._on_agent_delegation_request
                
                # Registra agente
                self.agents[agent_name] = agent
                self.agent_status[agent_name] = {
                    'status': 'active',
                    'last_activity': time.time(),
                    'tasks_completed': 0,
                    'tasks_failed': 0
                }
                
                self.logger.debug(f"Agente {agent_name} inizializzato")
                
            except Exception as e:
                self.logger.error(f"Errore inizializzazione agente {agent_name}: {e}")
                
                # Crea placeholder agent se fallisce
                self.agents[agent_name] = self._create_placeholder_agent(agent_config)
                self.agent_status[agent_name] = {
                    'status': 'placeholder',
                    'error': str(e),
                    'last_activity': time.time()
                }
    
    def _create_placeholder_agent(self, config) -> BaseAgent:
        """Crea agente placeholder per fallback."""
        
        class PlaceholderAgent(BaseAgent):
            async def _execute_specific_task(self, task: Task) -> Dict[str, Any]:
                return {
                    'status': 'placeholder_executed',
                    'message': f'Task eseguito da placeholder agent {self.name}',
                    'note': 'Questo è un placeholder - implementazione completa necessaria'
                }
        
        return PlaceholderAgent(config, self.mistral_client)
    
    async def _initialize_workflow_orchestrator(self):
        """Inizializza workflow orchestrator."""
        
        if 'workflow_orchestrator' in self.agents:
            self.workflow_orchestrator = self.agents['workflow_orchestrator']
            self.logger.info("Workflow Orchestrator inizializzato")
        else:
            self.logger.warning("Workflow Orchestrator non disponibile")
    
    async def _start_background_tasks(self):
        """Avvia task in background."""
        
        # Task processor
        task_processor = asyncio.create_task(self._process_task_queue())
        self.background_tasks.append(task_processor)
        
        # Metrics collector
        metrics_collector = asyncio.create_task(self._collect_metrics())
        self.background_tasks.append(metrics_collector)
        
        # Health monitor
        health_monitor = asyncio.create_task(self._monitor_system_health())
        self.background_tasks.append(health_monitor)
        
        self.logger.info("Background tasks avviati")
    
    async def execute_task(
        self,
        agent_name: str,
        description: str,
        expected_output: str,
        context: ExecutionContext = None,
        priority: TaskPriority = TaskPriority.MEDIUM,
        **kwargs
    ) -> ExecutionResult:
        """
        Esegue task su agente specifico.
        
        Args:
            agent_name: Nome dell'agente
            description: Descrizione del task
            expected_output: Output atteso
            context: Context di esecuzione
            priority: Priorità del task
            **kwargs: Parametri aggiuntivi
            
        Returns:
            Risultato dell'esecuzione
        """
        if self.status != ExecutorStatus.RUNNING:
            raise RuntimeError(f"Executor non in stato RUNNING: {self.status}")
        
        if agent_name not in self.agents:
            raise ValueError(f"Agente {agent_name} non trovato")
        
        # Crea task
        task = Task(
            id=str(uuid.uuid4()),
            agent_name=agent_name,
            description=description,
            expected_output=expected_output,
            priority=priority,
            context=kwargs
        )
        
        # Crea execution context se non fornito
        if context is None:
            context = ExecutionContext(
                session_id=str(uuid.uuid4()),
                priority=priority
            )
        
        self.execution_contexts[task.id] = context
        
        self.logger.info(f"Esecuzione task {task.id} su agente {agent_name}")
        
        start_time = time.time()
        
        try:
            # Emit event
            await self._emit_event('task_started', task, context)
            
            # Esegui task con semaforo per limitare concorrenza
            async with self.task_semaphore:
                agent = self.agents[agent_name]
                result = await agent.execute_task(task)
            
            execution_time = time.time() - start_time
            
            # Aggiorna metriche
            self._update_task_metrics(task, execution_time, True)
            
            # Emit event
            await self._emit_event('task_completed', task, result)
            
            return ExecutionResult(
                success=True,
                result=result,
                execution_time=execution_time,
                agents_involved=[agent_name]
            )
            
        except Exception as e:
            execution_time = time.time() - start_time
            
            # Aggiorna metriche
            self._update_task_metrics(task, execution_time, False)
            
            # Emit event
            await self._emit_event('task_failed', task, e)
            
            return ExecutionResult(
                success=False,
                result={'error': str(e)},
                execution_time=execution_time,
                agents_involved=[agent_name],
                errors=[str(e)]
            )
        
        finally:
            # Cleanup
            if task.id in self.execution_contexts:
                del self.execution_contexts[task.id]
    
    async def execute_workflow(
        self,
        workflow_name: str,
        parameters: Dict[str, Any] = None,
        context: ExecutionContext = None
    ) -> ExecutionResult:
        """
        Esegue workflow predefinito o personalizzato.
        
        Args:
            workflow_name: Nome del workflow
            parameters: Parametri per il workflow
            context: Context di esecuzione
            
        Returns:
            Risultato dell'esecuzione
        """
        if not self.workflow_orchestrator:
            raise RuntimeError("Workflow Orchestrator non disponibile")
        
        # Crea task per workflow orchestrator
        workflow_task = Task(
            id=str(uuid.uuid4()),
            agent_name='workflow_orchestrator',
            description=f'Esegui workflow: {workflow_name}',
            expected_output='Risultato completo del workflow',
            context={
                'task_type': 'workflow_execution',
                'workflow_name': workflow_name,
                'workflow_params': parameters or {}
            }
        )
        
        self.logger.info(f"Esecuzione workflow {workflow_name}")
        
        start_time = time.time()
        
        try:
            # Emit event
            await self._emit_event('workflow_started', workflow_name, parameters)
            
            # Esegui workflow
            result = await self.workflow_orchestrator.execute_task(workflow_task)
            
            execution_time = time.time() - start_time
            
            # Emit event
            await self._emit_event('workflow_completed', workflow_name, result)
            
            return ExecutionResult(
                success=True,
                result=result,
                execution_time=execution_time,
                agents_involved=['workflow_orchestrator']  # + altri agenti coinvolti
            )
            
        except Exception as e:
            execution_time = time.time() - start_time
            
            return ExecutionResult(
                success=False,
                result={'error': str(e)},
                execution_time=execution_time,
                agents_involved=['workflow_orchestrator'],
                errors=[str(e)]
            )
    
    async def execute_complex_task(
        self,
        description: str,
        expected_output: str,
        context: ExecutionContext = None,
        auto_orchestrate: bool = True
    ) -> ExecutionResult:
        """
        Esegue task complesso con orchestrazione automatica.
        
        Args:
            description: Descrizione del task complesso
            expected_output: Output atteso
            context: Context di esecuzione
            auto_orchestrate: Se utilizzare orchestrazione automatica
            
        Returns:
            Risultato dell'esecuzione
        """
        if auto_orchestrate and self.workflow_orchestrator:
            # Usa workflow orchestrator per task complessi
            return await self.execute_task(
                'workflow_orchestrator',
                description,
                expected_output,
                context
            )
        else:
            # Analizza task e seleziona agente appropriato
            best_agent = await self._select_best_agent_for_task(description)
            
            return await self.execute_task(
                best_agent,
                description,
                expected_output,
                context
            )
    
    async def _select_best_agent_for_task(self, description: str) -> str:
        """Seleziona l'agente migliore per un task."""
        
        # Usa Mistral per analizzare task e selezionare agente
        if self.mistral_client:
            analysis_prompt = f"""
            Analizza questo task e seleziona l'agente più appropriato:
            
            Task: {description}
            
            Agenti disponibili:
            {', '.join(self.agents.keys())}
            
            Rispondi solo con il nome dell'agente più appropriato.
            """
            
            try:
                response = await self.mistral_client.simple_completion(
                    analysis_prompt,
                    max_tokens=50
                )
                
                # Estrai nome agente dalla risposta
                agent_name = response.strip().lower()
                if agent_name in self.agents:
                    return agent_name
                    
            except Exception as e:
                self.logger.warning(f"Errore selezione agente automatica: {e}")
        
        # Fallback: seleziona agente basato su keywords
        description_lower = description.lower()
        
        if any(word in description_lower for word in ['code', 'develop', 'program', 'software']):
            return 'tech_lead'
        elif any(word in description_lower for word in ['design', 'ui', 'ux', 'interface']):
            return 'ui_ux_designer'
        elif any(word in description_lower for word in ['market', 'research', 'competitor']):
            return 'market_researcher'
        elif any(word in description_lower for word in ['content', 'write', 'copy']):
            return 'content_creator'
        else:
            return 'workflow_orchestrator'  # Default
    
    async def _process_task_queue(self):
        """Processa coda task in background."""
        
        while not self._shutdown_event.is_set():
            try:
                # Attendi task dalla coda
                task = await asyncio.wait_for(
                    self.task_queue.get(),
                    timeout=1.0
                )
                
                # Processa task
                await self._process_queued_task(task)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"Errore processing task queue: {e}")
    
    async def _process_queued_task(self, task: Task):
        """Processa singolo task dalla coda."""
        
        try:
            agent = self.agents[task.agent_name]
            result = await agent.execute_task(task)
            
            self.completed_tasks.append(task)
            self.logger.debug(f"Task {task.id} completato dalla coda")
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            self.logger.error(f"Task {task.id} fallito dalla coda: {e}")
    
    async def _collect_metrics(self):
        """Raccoglie metriche del sistema."""
        
        while not self._shutdown_event.is_set():
            try:
                # Aggiorna metriche agenti
                for agent_name, agent in self.agents.items():
                    agent_metrics = agent.get_status()['metrics']
                    self.metrics['agents_utilization'][agent_name] = agent_metrics
                
                # Aggiorna metriche workflow
                if self.workflow_orchestrator:
                    workflow_metrics = self.workflow_orchestrator.get_orchestration_metrics()
                    self.metrics['workflow_metrics'] = workflow_metrics
                
                await asyncio.sleep(30)  # Ogni 30 secondi
                
            except Exception as e:
                self.logger.error(f"Errore raccolta metriche: {e}")
                await asyncio.sleep(60)
    
    async def _monitor_system_health(self):
        """Monitora salute del sistema."""
        
        while not self._shutdown_event.is_set():
            try:
                # Health check agenti
                for agent_name, agent in self.agents.items():
                    healthy = await agent.health_check()
                    
                    if not healthy:
                        self.logger.warning(f"Agente {agent_name} non healthy")
                        await self._emit_event('agent_error', agent_name, 'Health check failed')
                
                await asyncio.sleep(60)  # Ogni minuto
                
            except Exception as e:
                self.logger.error(f"Errore monitoring salute: {e}")
                await asyncio.sleep(120)
    
    async def _on_agent_task_completed(self, agent: BaseAgent, task: Task, result: Dict[str, Any]):
        """Callback per task completato da agente."""
        
        self.agent_status[agent.name]['last_activity'] = time.time()
        self.agent_status[agent.name]['tasks_completed'] += 1
        
        self.logger.debug(f"Task {task.id} completato da {agent.name}")
    
    async def _on_agent_task_failed(self, agent: BaseAgent, task: Task, error: Exception):
        """Callback per task fallito da agente."""
        
        self.agent_status[agent.name]['last_activity'] = time.time()
        self.agent_status[agent.name]['tasks_failed'] += 1
        
        self.logger.warning(f"Task {task.id} fallito da {agent.name}: {error}")
    
    async def _on_agent_delegation_request(self, agent: BaseAgent, task: Task) -> Dict[str, Any]:
        """Callback per richiesta delegazione da agente."""
        
        self.logger.info(f"Delegazione da {agent.name} a {task.agent_name}: {task.description}")
        
        # Esegui task delegato
        result = await self.execute_task(
            task.agent_name,
            task.description,
            task.expected_output,
            priority=task.priority,
            **task.context
        )
        
        return result.result
    
    def _update_task_metrics(self, task: Task, execution_time: float, success: bool):
        """Aggiorna metriche task."""
        
        self.metrics['total_tasks_executed'] += 1
        self.metrics['total_execution_time'] += execution_time
        
        if success:
            self.metrics['successful_tasks'] += 1
        else:
            self.metrics['failed_tasks'] += 1
        
        # Aggiorna tempo medio
        self.metrics['average_task_time'] = (
            self.metrics['total_execution_time'] / self.metrics['total_tasks_executed']
        )
    
    async def _emit_event(self, event_type: str, *args):
        """Emette evento ai callback registrati."""
        
        if event_type in self.event_callbacks:
            for callback in self.event_callbacks[event_type]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(*args)
                    else:
                        callback(*args)
                except Exception as e:
                    self.logger.error(f"Errore callback {event_type}: {e}")
    
    def register_event_callback(self, event_type: str, callback: Callable):
        """Registra callback per eventi."""
        
        if event_type not in self.event_callbacks:
            self.event_callbacks[event_type] = []
        
        self.event_callbacks[event_type].append(callback)
    
    def get_system_status(self) -> Dict[str, Any]:
        """Restituisce stato completo del sistema."""
        
        return {
            'executor_status': self.status.value,
            'uptime': time.time() - self.start_time,
            'agents_count': len(self.agents),
            'active_tasks': len(self.active_tasks),
            'completed_tasks': len(self.completed_tasks),
            'metrics': self.metrics,
            'agent_status': self.agent_status,
            'mistral_client_metrics': self.mistral_client.get_metrics() if self.mistral_client else {}
        }
    
    def get_available_agents(self) -> List[Dict[str, Any]]:
        """Restituisce lista agenti disponibili."""
        
        return [
            {
                'name': agent.name,
                'role': agent.role,
                'status': self.agent_status[name]['status'],
                'tools': agent.tools,
                'last_activity': self.agent_status[name]['last_activity']
            }
            for name, agent in self.agents.items()
        ]
    
    def get_predefined_workflows(self) -> Dict[str, Any]:
        """Restituisce workflow predefiniti disponibili."""
        
        if self.workflow_orchestrator:
            return self.workflow_orchestrator.get_predefined_workflows()
        return {}
    
    async def shutdown(self):
        """Shutdown graceful dell'executor."""
        
        self.logger.info("Shutdown Central Executor...")
        self.status = ExecutorStatus.STOPPING
        
        # Segnala shutdown ai background tasks
        self._shutdown_event.set()
        
        # Attendi completamento background tasks
        if self.background_tasks:
            await asyncio.gather(*self.background_tasks, return_exceptions=True)
        
        # Chiudi Mistral client
        if self.mistral_client:
            await self.mistral_client.close()
        
        self.status = ExecutorStatus.STOPPED
        self.logger.info("Central Executor fermato")


# Factory function
def create_central_executor(config: Dict[str, Any] = None) -> CentralExecutor:
    """Crea istanza Central Executor."""
    return CentralExecutor(config)


# Singleton globale
_global_executor: Optional[CentralExecutor] = None


async def get_global_executor() -> CentralExecutor:
    """Ottiene executor globale singleton."""
    global _global_executor
    
    if _global_executor is None:
        _global_executor = create_central_executor()
        await _global_executor.initialize()
    
    return _global_executor


async def shutdown_global_executor():
    """Shutdown executor globale."""
    global _global_executor
    
    if _global_executor:
        await _global_executor.shutdown()
        _global_executor = None


if __name__ == "__main__":
    import asyncio
    
    async def test_central_executor():
        """Test del Central Executor."""
        print("=== Test Central Executor ===")
        
        # Crea e inizializza executor
        executor = create_central_executor()
        
        if await executor.initialize():
            print(f"✅ Executor inizializzato con {len(executor.agents)} agenti")
            
            # Test esecuzione task semplice
            result = await executor.execute_task(
                'tech_lead',
                'Progetta architettura per app mobile di e-commerce',
                'Documento architettura completo'
            )
            
            print(f"✅ Task completato: {result.success}")
            print(f"   Tempo esecuzione: {result.execution_time:.2f}s")
            
            # Test workflow
            if executor.workflow_orchestrator:
                workflow_result = await executor.execute_workflow(
                    'full_app_development',
                    {'project_type': 'mobile_app', 'budget': 'medium'}
                )
                print(f"✅ Workflow completato: {workflow_result.success}")
            
            # Mostra stato sistema
            status = executor.get_system_status()
            print(f"📊 Task totali: {status['metrics']['total_tasks_executed']}")
            print(f"📊 Task riusciti: {status['metrics']['successful_tasks']}")
            
            # Shutdown
            await executor.shutdown()
            print("✅ Executor fermato")
            
        else:
            print("❌ Errore inizializzazione executor")
    
    # Esegui test
    asyncio.run(test_central_executor())

