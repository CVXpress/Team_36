#!/usr/bin/env python3
import requests
import time
import json
from datetime import datetime

def check_system_health(url):
    try:
        response = requests.get(f"{url}/api/stats", timeout=10)
        if response.status_code == 200:
            data = response.json()
            return {
                "status": "healthy",
                "response_time": response.elapsed.total_seconds(),
                "data": data
            }
        else:
            return {
                "status": "unhealthy",
                "error": f"HTTP {response.status_code}"
            }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e)
        }

def main():
    urls = [
        "https://mistral-agents-dashboard.railway.app",
        "https://mistral-agents-dashboard.onrender.com"
    ]
    
    for url in urls:
        health = check_system_health(url)
        timestamp = datetime.now().isoformat()
        
        print(f"[{timestamp}] {url}: {health['status']}")
        
        if health['status'] != 'healthy':
            print(f"  Error: {health.get('error', 'Unknown')}")
        else:
            print(f"  Response time: {health['response_time']:.2f}s")

if __name__ == "__main__":
    main()
