"""
Tech Lead Agent

Agente specializzato in leadership tecnica, architettura software
e coordinamento team di sviluppo.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import json
from typing import Dict, List, Any
import re

from agents.base_agent import BaseAgent, Task, agent_decorator
from config.mistral_config import AgentConfig


@agent_decorator('tech_lead')
class TechLeadAgent(BaseAgent):
    """
    Agente Tech Lead per leadership tecnica e architettura.
    
    Responsabilità:
    - Progettazione architettura software
    - Definizione stack tecnologico
    - Code review e best practices
    - Coordinamento team di sviluppo
    - Pianificazione tecnica e roadmap
    - Risoluzione problemi tecnici complessi
    """
    
    def __init__(self, config: AgentConfig, mistral_client=None):
        super().__init__(config, mistral_client)
        
        # Knowledge base tecnica
        self.tech_stack_knowledge = {
            'frontend': {
                'frameworks': ['React', 'Vue.js', 'Angular', 'Svelte', 'Next.js'],
                'languages': ['JavaScript', 'TypeScript', 'HTML5', 'CSS3'],
                'tools': ['Webpack', 'Vite', 'ESLint', 'Prettier', 'Storybook']
            },
            'backend': {
                'frameworks': ['Node.js', 'Python/Django', 'Python/FastAPI', 'Java/Spring', 'Go', 'Rust'],
                'databases': ['PostgreSQL', 'MongoDB', 'Redis', 'Elasticsearch'],
                'tools': ['Docker', 'Kubernetes', 'Jenkins', 'GitLab CI']
            },
            'mobile': {
                'frameworks': ['React Native', 'Flutter', 'Ionic', 'Native iOS/Android'],
                'tools': ['Expo', 'Fastlane', 'Firebase', 'App Center']
            },
            'cloud': {
                'providers': ['AWS', 'Google Cloud', 'Azure', 'DigitalOcean'],
                'services': ['Lambda', 'Cloud Functions', 'Container Registry', 'CDN']
            }
        }
        
        # Patterns architetturali
        self.architecture_patterns = {
            'microservices': 'Architettura a microservizi per scalabilità',
            'monolith': 'Architettura monolitica per semplicità iniziale',
            'serverless': 'Architettura serverless per costi ottimizzati',
            'event_driven': 'Architettura event-driven per disaccoppiamento',
            'layered': 'Architettura a layer per separazione concerns'
        }
    
    async def _execute_specific_task(self, task: Task) -> Dict[str, Any]:
        """Esegue task specifico del Tech Lead."""
        
        # Analizza tipo di task tecnico
        task_type = self._analyze_task_type(task.description)
        
        if task_type == 'architecture_design':
            return await self._design_architecture_task(task)
        elif task_type == 'tech_stack_selection':
            return await self._select_tech_stack_task(task)
        elif task_type == 'code_review':
            return await self._code_review_task(task)
        elif task_type == 'technical_planning':
            return await self._technical_planning_task(task)
        elif task_type == 'problem_solving':
            return await self._technical_problem_solving_task(task)
        elif task_type == 'team_coordination':
            return await self._team_coordination_task(task)
        else:
            return await self._general_technical_task(task)
    
    def _analyze_task_type(self, description: str) -> str:
        """Analizza il tipo di task tecnico."""
        description_lower = description.lower()
        
        if any(word in description_lower for word in ['architettura', 'architecture', 'design', 'progetta']):
            return 'architecture_design'
        elif any(word in description_lower for word in ['stack', 'tecnologie', 'framework', 'linguaggio']):
            return 'tech_stack_selection'
        elif any(word in description_lower for word in ['review', 'codice', 'code', 'qualità']):
            return 'code_review'
        elif any(word in description_lower for word in ['pianificazione', 'planning', 'roadmap', 'timeline']):
            return 'technical_planning'
        elif any(word in description_lower for word in ['problema', 'bug', 'errore', 'debug', 'risolvi']):
            return 'problem_solving'
        elif any(word in description_lower for word in ['team', 'coordinamento', 'gestione', 'leadership']):
            return 'team_coordination'
        else:
            return 'general_technical'
    
    async def _design_architecture_task(self, task: Task) -> Dict[str, Any]:
        """Progetta architettura software."""
        
        # Estrai requisiti dal context
        requirements = task.context.get('requirements', {})
        scale = task.context.get('scale', 'medium')
        budget = task.context.get('budget', 'medium')
        timeline = task.context.get('timeline', '6 months')
        
        architecture_prompt = f"""
        Come Tech Lead senior, progetta un'architettura software completa per:
        
        Progetto: {task.description}
        Output richiesto: {task.expected_output}
        
        Requisiti:
        - Scala: {scale}
        - Budget: {budget}
        - Timeline: {timeline}
        - Requisiti specifici: {json.dumps(requirements, indent=2)}
        
        Fornisci:
        1. **Architettura Overview**: Diagramma concettuale e pattern scelto
        2. **Stack Tecnologico**: Frontend, Backend, Database, Infrastructure
        3. **Componenti Principali**: Microservizi/moduli e loro responsabilità
        4. **Data Flow**: Come i dati fluiscono nel sistema
        5. **Scalabilità**: Strategie per gestire crescita
        6. **Security**: Considerazioni di sicurezza
        7. **Deployment**: Strategia di deployment e CI/CD
        8. **Monitoring**: Logging, metrics e alerting
        9. **Timeline**: Fasi di sviluppo e milestone
        10. **Rischi**: Potenziali rischi tecnici e mitigazioni
        
        Sii specifico e pratico, fornendo soluzioni implementabili.
        """
        
        architecture_design = await self._call_mistral(
            architecture_prompt,
            max_tokens=2000
        )
        
        # Genera raccomandazioni specifiche
        recommendations = await self._generate_architecture_recommendations(
            task.description, requirements, scale
        )
        
        return {
            'architecture_design': architecture_design,
            'recommended_stack': recommendations['stack'],
            'architecture_pattern': recommendations['pattern'],
            'estimated_complexity': recommendations['complexity'],
            'development_phases': recommendations['phases'],
            'risk_assessment': recommendations['risks'],
            'next_steps': [
                'Validare architettura con stakeholder',
                'Creare proof of concept per componenti critici',
                'Definire standard di sviluppo e coding guidelines',
                'Setup ambiente di sviluppo e CI/CD pipeline'
            ]
        }
    
    async def _select_tech_stack_task(self, task: Task) -> Dict[str, Any]:
        """Seleziona stack tecnologico ottimale."""
        
        project_type = task.context.get('project_type', 'web_app')
        team_skills = task.context.get('team_skills', [])
        constraints = task.context.get('constraints', {})
        
        stack_selection_prompt = f"""
        Come Tech Lead esperto, seleziona lo stack tecnologico ottimale per:
        
        Progetto: {task.description}
        Tipo: {project_type}
        Competenze team: {', '.join(team_skills)}
        Vincoli: {json.dumps(constraints, indent=2)}
        
        Considera:
        1. **Frontend**: Framework, linguaggi, tools
        2. **Backend**: Runtime, framework, API design
        3. **Database**: Tipo, schema, performance
        4. **Infrastructure**: Cloud provider, containerization
        5. **DevOps**: CI/CD, monitoring, deployment
        6. **Mobile**: Se necessario, approccio native vs cross-platform
        
        Per ogni scelta, spiega:
        - Perché è la migliore opzione
        - Pro e contro
        - Alternative considerate
        - Impatto su timeline e budget
        
        Fornisci anche:
        - Learning curve per il team
        - Costi di licensing/hosting
        - Scalabilità a lungo termine
        """
        
        stack_analysis = await self._call_mistral(
            stack_selection_prompt,
            max_tokens=1500
        )
        
        # Genera stack recommendation strutturata
        recommended_stack = self._generate_structured_stack_recommendation(
            project_type, team_skills, constraints
        )
        
        return {
            'stack_analysis': stack_analysis,
            'recommended_stack': recommended_stack,
            'implementation_order': [
                'Setup development environment',
                'Configure CI/CD pipeline',
                'Implement core backend services',
                'Develop frontend components',
                'Integrate and test',
                'Deploy to staging/production'
            ],
            'team_training_needs': self._assess_training_needs(team_skills, recommended_stack),
            'estimated_setup_time': '2-3 weeks'
        }
    
    async def _code_review_task(self, task: Task) -> Dict[str, Any]:
        """Esegue code review e fornisce feedback."""
        
        code_snippet = task.context.get('code', '')
        language = task.context.get('language', 'javascript')
        review_focus = task.context.get('focus', 'general')
        
        code_review_prompt = f"""
        Come Tech Lead senior, esegui un code review approfondito per:
        
        Linguaggio: {language}
        Focus: {review_focus}
        
        Codice da revieware:
        ```{language}
        {code_snippet}
        ```
        
        Analizza:
        1. **Code Quality**: Leggibilità, maintainability, structure
        2. **Best Practices**: Aderenza a standard e convenzioni
        3. **Performance**: Ottimizzazioni possibili
        4. **Security**: Vulnerabilità e rischi
        5. **Testing**: Testabilità e coverage
        6. **Documentation**: Commenti e documentazione
        
        Fornisci:
        - Feedback specifico con esempi
        - Suggerimenti di miglioramento
        - Codice refactorato dove necessario
        - Rating complessivo (1-10)
        """
        
        review_feedback = await self._call_mistral(
            code_review_prompt,
            max_tokens=1200
        )
        
        # Analisi automatica del codice
        code_metrics = self._analyze_code_metrics(code_snippet, language)
        
        return {
            'review_feedback': review_feedback,
            'code_metrics': code_metrics,
            'severity_issues': code_metrics['issues'],
            'refactoring_suggestions': code_metrics['suggestions'],
            'approval_status': 'approved' if code_metrics['score'] >= 7 else 'needs_changes',
            'next_steps': [
                'Implementare suggerimenti di miglioramento',
                'Aggiungere test unitari se mancanti',
                'Aggiornare documentazione',
                'Re-submit per review finale'
            ]
        }
    
    async def _technical_planning_task(self, task: Task) -> Dict[str, Any]:
        """Crea pianificazione tecnica dettagliata."""
        
        project_scope = task.context.get('scope', '')
        team_size = task.context.get('team_size', 5)
        deadline = task.context.get('deadline', '3 months')
        
        planning_prompt = f"""
        Come Tech Lead esperto, crea una pianificazione tecnica dettagliata per:
        
        Progetto: {task.description}
        Scope: {project_scope}
        Team size: {team_size} developers
        Deadline: {deadline}
        
        Crea:
        1. **Work Breakdown Structure**: Decomposizione in task specifici
        2. **Sprint Planning**: Organizzazione in sprint/milestone
        3. **Resource Allocation**: Assegnazione sviluppatori per competenza
        4. **Dependencies**: Identificazione dipendenze critiche
        5. **Risk Management**: Rischi tecnici e piani di mitigazione
        6. **Quality Gates**: Checkpoint qualità e review
        7. **Timeline**: Cronogramma dettagliato con buffer
        8. **Deliverables**: Output specifici per ogni fase
        
        Considera:
        - Complessità tecnica
        - Learning curve
        - Integration challenges
        - Testing requirements
        """
        
        technical_plan = await self._call_mistral(
            planning_prompt,
            max_tokens=1800
        )
        
        # Genera timeline strutturata
        timeline = self._generate_development_timeline(project_scope, team_size, deadline)
        
        return {
            'technical_plan': technical_plan,
            'development_timeline': timeline,
            'resource_allocation': self._allocate_resources(team_size),
            'critical_path': timeline['critical_path'],
            'risk_mitigation': timeline['risks'],
            'quality_checkpoints': [
                'Architecture review (Week 2)',
                'Code review checkpoint (Week 4)',
                'Integration testing (Week 6)',
                'Performance testing (Week 8)',
                'Security audit (Week 10)',
                'Final review (Week 12)'
            ]
        }
    
    async def _technical_problem_solving_task(self, task: Task) -> Dict[str, Any]:
        """Risolve problemi tecnici complessi."""
        
        problem_description = task.description
        error_logs = task.context.get('error_logs', '')
        system_context = task.context.get('system_context', {})
        
        problem_solving_prompt = f"""
        Come Tech Lead senior, analizza e risolvi questo problema tecnico:
        
        Problema: {problem_description}
        
        Error logs:
        {error_logs}
        
        System context: {json.dumps(system_context, indent=2)}
        
        Fornisci:
        1. **Root Cause Analysis**: Identificazione causa principale
        2. **Immediate Fix**: Soluzione rapida per mitigare il problema
        3. **Long-term Solution**: Soluzione definitiva e robusta
        4. **Prevention**: Come prevenire problemi simili
        5. **Testing Strategy**: Come testare la soluzione
        6. **Monitoring**: Metriche per monitorare la risoluzione
        
        Sii specifico con:
        - Codice di esempio per le fix
        - Comandi specifici da eseguire
        - Configurazioni da modificare
        - Test da implementare
        """
        
        solution = await self._call_mistral(
            problem_solving_prompt,
            max_tokens=1500
        )
        
        # Analisi automatica del problema
        problem_analysis = self._analyze_technical_problem(
            problem_description, error_logs, system_context
        )
        
        return {
            'solution': solution,
            'problem_category': problem_analysis['category'],
            'severity': problem_analysis['severity'],
            'estimated_fix_time': problem_analysis['fix_time'],
            'required_resources': problem_analysis['resources'],
            'implementation_steps': [
                'Backup current system state',
                'Implement immediate fix',
                'Test fix in staging environment',
                'Deploy to production with monitoring',
                'Implement long-term solution',
                'Update documentation and runbooks'
            ]
        }
    
    async def _team_coordination_task(self, task: Task) -> Dict[str, Any]:
        """Coordina team di sviluppo."""
        
        team_info = task.context.get('team_info', {})
        current_challenges = task.context.get('challenges', [])
        project_status = task.context.get('project_status', {})
        
        coordination_prompt = f"""
        Come Tech Lead, coordina il team di sviluppo per:
        
        Obiettivo: {task.description}
        
        Team info: {json.dumps(team_info, indent=2)}
        Sfide attuali: {', '.join(current_challenges)}
        Status progetto: {json.dumps(project_status, indent=2)}
        
        Fornisci:
        1. **Team Organization**: Struttura ottimale del team
        2. **Task Assignment**: Assegnazione task per competenza
        3. **Communication Plan**: Struttura meeting e reporting
        4. **Mentoring Strategy**: Piano sviluppo competenze
        5. **Conflict Resolution**: Gestione conflitti tecnici
        6. **Performance Tracking**: KPI e metriche team
        7. **Process Improvement**: Ottimizzazioni workflow
        
        Considera:
        - Skill level di ogni membro
        - Carico di lavoro bilanciato
        - Crescita professionale
        - Team morale e produttività
        """
        
        coordination_plan = await self._call_mistral(
            coordination_prompt,
            max_tokens=1400
        )
        
        return {
            'coordination_plan': coordination_plan,
            'team_structure': self._optimize_team_structure(team_info),
            'communication_framework': {
                'daily_standups': '15 min every morning',
                'sprint_planning': '2h every 2 weeks',
                'retrospectives': '1h every 2 weeks',
                'tech_reviews': '1h weekly',
                'one_on_ones': '30 min bi-weekly'
            },
            'development_standards': {
                'code_review_required': True,
                'test_coverage_minimum': '80%',
                'documentation_required': True,
                'ci_cd_mandatory': True
            }
        }
    
    async def _general_technical_task(self, task: Task) -> Dict[str, Any]:
        """Gestisce task tecnici generali."""
        
        general_prompt = f"""
        Come Tech Lead senior con esperienza in architettura software e leadership tecnica:
        
        Task: {task.description}
        Output richiesto: {task.expected_output}
        Context: {json.dumps(task.context, indent=2)}
        
        Fornisci una soluzione tecnica completa che includa:
        1. Analisi del problema/requisito
        2. Approccio tecnico raccomandato
        3. Considerazioni architetturali
        4. Implementazione step-by-step
        5. Best practices applicabili
        6. Potenziali rischi e mitigazioni
        7. Metriche di successo
        
        Mantieni focus su:
        - Scalabilità e maintainability
        - Performance e security
        - Team productivity
        - Long-term sustainability
        """
        
        technical_solution = await self._call_mistral(
            general_prompt,
            max_tokens=1600
        )
        
        return {
            'technical_solution': technical_solution,
            'implementation_complexity': 'medium',
            'estimated_effort': '2-4 weeks',
            'required_skills': ['Software Architecture', 'System Design', 'Leadership'],
            'success_metrics': [
                'Solution meets all requirements',
                'Code quality standards maintained',
                'Performance targets achieved',
                'Team productivity improved'
            ]
        }
    
    def _generate_architecture_recommendations(
        self, 
        description: str, 
        requirements: Dict[str, Any], 
        scale: str
    ) -> Dict[str, Any]:
        """Genera raccomandazioni architetturali strutturate."""
        
        # Seleziona pattern architetturale
        if scale == 'large' or 'microservices' in description.lower():
            pattern = 'microservices'
            stack = {
                'frontend': 'React + TypeScript',
                'backend': 'Node.js + Express / Python + FastAPI',
                'database': 'PostgreSQL + Redis',
                'infrastructure': 'Kubernetes + Docker'
            }
        elif 'serverless' in description.lower():
            pattern = 'serverless'
            stack = {
                'frontend': 'React + Next.js',
                'backend': 'AWS Lambda / Vercel Functions',
                'database': 'DynamoDB / Supabase',
                'infrastructure': 'AWS / Vercel'
            }
        else:
            pattern = 'monolith'
            stack = {
                'frontend': 'React + Vite',
                'backend': 'Node.js + Express',
                'database': 'PostgreSQL',
                'infrastructure': 'Docker + Cloud hosting'
            }
        
        return {
            'pattern': pattern,
            'stack': stack,
            'complexity': 'high' if scale == 'large' else 'medium',
            'phases': [
                'MVP Development (4-6 weeks)',
                'Core Features (6-8 weeks)',
                'Advanced Features (4-6 weeks)',
                'Optimization & Scaling (2-4 weeks)'
            ],
            'risks': [
                'Integration complexity',
                'Performance bottlenecks',
                'Security vulnerabilities',
                'Scalability challenges'
            ]
        }
    
    def _generate_structured_stack_recommendation(
        self,
        project_type: str,
        team_skills: List[str],
        constraints: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Genera raccomandazione stack strutturata."""
        
        # Logica di selezione basata su project_type e skills
        if project_type == 'mobile_app':
            if 'React' in team_skills:
                return {
                    'mobile': 'React Native + Expo',
                    'backend': 'Node.js + Express',
                    'database': 'Firebase / Supabase',
                    'deployment': 'App Store + Google Play'
                }
            else:
                return {
                    'mobile': 'Flutter',
                    'backend': 'Python + FastAPI',
                    'database': 'PostgreSQL',
                    'deployment': 'App Store + Google Play'
                }
        
        elif project_type == 'web_app':
            return {
                'frontend': 'React + TypeScript + Vite',
                'backend': 'Node.js + Express' if 'JavaScript' in team_skills else 'Python + FastAPI',
                'database': 'PostgreSQL + Redis',
                'deployment': 'Vercel + Railway'
            }
        
        else:  # Default
            return {
                'frontend': 'React + TypeScript',
                'backend': 'Node.js + Express',
                'database': 'PostgreSQL',
                'deployment': 'Docker + Cloud'
            }
    
    def _analyze_code_metrics(self, code: str, language: str) -> Dict[str, Any]:
        """Analizza metriche del codice."""
        
        lines = code.split('\n')
        
        # Metriche base
        metrics = {
            'lines_of_code': len([line for line in lines if line.strip()]),
            'comment_lines': len([line for line in lines if line.strip().startswith('//')]),
            'blank_lines': len([line for line in lines if not line.strip()]),
            'complexity': 'medium',  # Simplified
            'score': 7,  # Default score
            'issues': [],
            'suggestions': []
        }
        
        # Analisi semplificata per demo
        if len(code) > 1000:
            metrics['issues'].append('Function too long - consider breaking down')
        
        if 'console.log' in code:
            metrics['issues'].append('Remove console.log statements')
        
        if not any(word in code for word in ['test', 'spec', 'describe']):
            metrics['suggestions'].append('Add unit tests')
        
        return metrics
    
    def _generate_development_timeline(
        self,
        scope: str,
        team_size: int,
        deadline: str
    ) -> Dict[str, Any]:
        """Genera timeline di sviluppo."""
        
        # Timeline semplificata
        phases = [
            'Planning & Architecture (Week 1-2)',
            'Core Development (Week 3-8)',
            'Integration & Testing (Week 9-10)',
            'Deployment & Launch (Week 11-12)'
        ]
        
        return {
            'phases': phases,
            'critical_path': ['Architecture Design', 'Core Backend', 'Frontend Integration'],
            'risks': [
                'Integration delays',
                'Performance issues',
                'Third-party dependencies'
            ],
            'buffers': '20% time buffer for each phase'
        }
    
    def _allocate_resources(self, team_size: int) -> Dict[str, Any]:
        """Alloca risorse del team."""
        
        if team_size <= 3:
            return {
                'full_stack_developers': team_size,
                'specialization': 'minimal'
            }
        else:
            return {
                'frontend_developers': max(1, team_size // 3),
                'backend_developers': max(1, team_size // 3),
                'full_stack_developers': team_size - (2 * (team_size // 3)),
                'specialization': 'moderate'
            }
    
    def _analyze_technical_problem(
        self,
        description: str,
        logs: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analizza problema tecnico."""
        
        # Analisi semplificata
        if 'error' in logs.lower() or 'exception' in logs.lower():
            severity = 'high'
            category = 'runtime_error'
            fix_time = '2-4 hours'
        elif 'performance' in description.lower():
            severity = 'medium'
            category = 'performance'
            fix_time = '1-2 days'
        else:
            severity = 'low'
            category = 'general'
            fix_time = '4-8 hours'
        
        return {
            'category': category,
            'severity': severity,
            'fix_time': fix_time,
            'resources': ['Senior Developer', 'DevOps Engineer']
        }
    
    def _optimize_team_structure(self, team_info: Dict[str, Any]) -> Dict[str, Any]:
        """Ottimizza struttura del team."""
        
        return {
            'structure': 'Cross-functional squads',
            'communication': 'Agile ceremonies + async updates',
            'decision_making': 'Tech Lead + Senior Developers',
            'knowledge_sharing': 'Weekly tech talks + pair programming'
        }
    
    def _assess_training_needs(
        self,
        current_skills: List[str],
        recommended_stack: Dict[str, str]
    ) -> List[str]:
        """Valuta necessità di training."""
        
        training_needs = []
        
        # Logica semplificata
        for component, technology in recommended_stack.items():
            if not any(skill in technology for skill in current_skills):
                training_needs.append(f'{component}: {technology}')
        
        return training_needs

