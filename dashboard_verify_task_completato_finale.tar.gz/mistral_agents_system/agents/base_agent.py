"""
Base Agent Class for Mistral AI Multi-Agent System

Classe base per tutti i 36 agenti specializzati che utilizzano Mistral AI
per l'esecuzione di task complessi con orchestrazione avanzata.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import json
import time
import uuid
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

from core.mistral_client import MistralClient, ChatMessage, MessageRole
from config.mistral_config import AgentConfig, SystemConfig


class TaskStatus(Enum):
    """Stati possibili di un task."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(Enum):
    """Priorità dei task."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class Task:
    """Rappresenta un task da eseguire."""
    id: str
    agent_name: str
    description: str
    expected_output: str
    priority: TaskPriority = TaskPriority.MEDIUM
    context: Dict[str, Any] = field(default_factory=dict)
    tools: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    
    # Stato e timing
    status: TaskStatus = TaskStatus.PENDING
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    
    # Risultati
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte task in dizionario."""
        return {
            'id': self.id,
            'agent_name': self.agent_name,
            'description': self.description,
            'expected_output': self.expected_output,
            'priority': self.priority.value,
            'context': self.context,
            'tools': self.tools,
            'dependencies': self.dependencies,
            'status': self.status.value,
            'created_at': self.created_at,
            'started_at': self.started_at,
            'completed_at': self.completed_at,
            'result': self.result,
            'error': self.error
        }


@dataclass
class AgentMetrics:
    """Metriche di performance per agente."""
    total_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0
    average_execution_time: float = 0.0
    total_tokens_used: int = 0
    last_activity: Optional[float] = None
    
    def update_completion(self, execution_time: float, tokens_used: int = 0):
        """Aggiorna metriche per task completato."""
        self.completed_tasks += 1
        self.total_tasks += 1
        self.total_tokens_used += tokens_used
        self.last_activity = time.time()
        
        # Aggiorna tempo medio
        if self.completed_tasks > 1:
            self.average_execution_time = (
                (self.average_execution_time * (self.completed_tasks - 1) + execution_time) 
                / self.completed_tasks
            )
        else:
            self.average_execution_time = execution_time
    
    def update_failure(self):
        """Aggiorna metriche per task fallito."""
        self.failed_tasks += 1
        self.total_tasks += 1
        self.last_activity = time.time()
    
    @property
    def success_rate(self) -> float:
        """Calcola tasso di successo."""
        if self.total_tasks == 0:
            return 0.0
        return self.completed_tasks / self.total_tasks
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte metriche in dizionario."""
        return {
            'total_tasks': self.total_tasks,
            'completed_tasks': self.completed_tasks,
            'failed_tasks': self.failed_tasks,
            'success_rate': self.success_rate,
            'average_execution_time': self.average_execution_time,
            'total_tokens_used': self.total_tokens_used,
            'last_activity': self.last_activity
        }


class BaseAgent(ABC):
    """
    Classe base per tutti gli agenti del sistema multi-agente.
    
    Ogni agente specializzato eredita da questa classe e implementa
    la logica specifica per il proprio dominio di competenza.
    """
    
    def __init__(self, config: AgentConfig, mistral_client: MistralClient = None):
        """
        Inizializza agente base.
        
        Args:
            config: Configurazione dell'agente
            mistral_client: Client Mistral AI (opzionale)
        """
        self.config = config
        self.mistral_client = mistral_client
        self.logger = logging.getLogger(f"agent.{config.name}")
        
        # Stato agente
        self.is_active = True
        self.current_task: Optional[Task] = None
        self.metrics = AgentMetrics()
        
        # Callback per comunicazione con orchestratore
        self.on_task_completed: Optional[Callable] = None
        self.on_task_failed: Optional[Callable] = None
        self.on_delegation_request: Optional[Callable] = None
        
        # Cache per risultati
        self.result_cache: Dict[str, Any] = {}
        
        self.logger.info(f"Agente {self.config.name} inizializzato")
    
    @property
    def name(self) -> str:
        """Nome dell'agente."""
        return self.config.name
    
    @property
    def role(self) -> str:
        """Ruolo dell'agente."""
        return self.config.role
    
    @property
    def tools(self) -> List[str]:
        """Strumenti disponibili per l'agente."""
        return self.config.tools
    
    async def execute_task(self, task: Task) -> Dict[str, Any]:
        """
        Esegue un task assegnato all'agente.
        
        Args:
            task: Task da eseguire
            
        Returns:
            Risultato dell'esecuzione
        """
        if not self.is_active:
            raise RuntimeError(f"Agente {self.name} non è attivo")
        
        if self.current_task is not None:
            raise RuntimeError(f"Agente {self.name} sta già eseguendo un task")
        
        self.current_task = task
        task.status = TaskStatus.RUNNING
        task.started_at = time.time()
        
        self.logger.info(f"Inizio esecuzione task {task.id}: {task.description}")
        
        try:
            # Esegui task specifico dell'agente
            result = await self._execute_specific_task(task)
            
            # Aggiorna stato task
            task.status = TaskStatus.COMPLETED
            task.completed_at = time.time()
            task.result = result
            
            # Aggiorna metriche
            execution_time = task.completed_at - task.started_at
            tokens_used = result.get('tokens_used', 0)
            self.metrics.update_completion(execution_time, tokens_used)
            
            self.logger.info(f"Task {task.id} completato in {execution_time:.2f}s")
            
            # Notifica completamento
            if self.on_task_completed:
                await self.on_task_completed(self, task, result)
            
            return result
            
        except Exception as e:
            # Gestisci errore
            task.status = TaskStatus.FAILED
            task.completed_at = time.time()
            task.error = str(e)
            
            self.metrics.update_failure()
            self.logger.error(f"Task {task.id} fallito: {e}")
            
            # Notifica fallimento
            if self.on_task_failed:
                await self.on_task_failed(self, task, e)
            
            raise
            
        finally:
            self.current_task = None
    
    @abstractmethod
    async def _execute_specific_task(self, task: Task) -> Dict[str, Any]:
        """
        Implementa la logica specifica dell'agente per eseguire il task.
        
        Questo metodo deve essere implementato da ogni agente specializzato.
        
        Args:
            task: Task da eseguire
            
        Returns:
            Risultato dell'esecuzione
        """
        pass
    
    async def _call_mistral(
        self,
        prompt: str,
        system_message: str = None,
        context: Dict[str, Any] = None,
        **kwargs
    ) -> str:
        """
        Effettua chiamata a Mistral AI con il contesto dell'agente.
        
        Args:
            prompt: Prompt per il modello
            system_message: Messaggio di sistema personalizzato
            context: Context aggiuntivo
            **kwargs: Parametri aggiuntivi per Mistral
            
        Returns:
            Risposta del modello
        """
        if not self.mistral_client:
            raise RuntimeError("Client Mistral AI non configurato")
        
        # Costruisci system message se non fornito
        if not system_message:
            system_message = self._build_system_message()
        
        # Aggiungi context al prompt se fornito
        if context:
            prompt += f"\n\nContext aggiuntivo:\n{json.dumps(context, indent=2)}"
        
        # Effettua chiamata
        response = await self.mistral_client.simple_completion(
            prompt,
            system_message,
            model=self.config.model,
            **kwargs
        )
        
        return response
    
    def _build_system_message(self) -> str:
        """Costruisce messaggio di sistema per l'agente."""
        return f"""Sei {self.config.name}, un {self.config.role}.

Il tuo obiettivo principale è: {self.config.goal}

Background e competenze: {self.config.backstory}

Strumenti a tua disposizione: {', '.join(self.config.tools)}

Linee guida:
1. Rispondi sempre nel ruolo dell'agente specificato
2. Fornisci soluzioni pratiche e actionable
3. Usa i tuoi strumenti quando appropriato
4. Mantieni un approccio professionale e competente
5. Se hai bisogno di delegare, specifica chiaramente quale agente contattare

Formato risposta: Fornisci sempre una risposta strutturata con sezioni chiare."""
    
    async def delegate_task(
        self,
        target_agent: str,
        task_description: str,
        expected_output: str,
        context: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Delega un task a un altro agente.
        
        Args:
            target_agent: Nome dell'agente target
            task_description: Descrizione del task
            expected_output: Output atteso
            context: Context da passare
            
        Returns:
            Risultato della delegazione
        """
        if not self.config.allow_delegation:
            raise RuntimeError(f"Agente {self.name} non può delegare task")
        
        if not self.on_delegation_request:
            raise RuntimeError("Callback delegazione non configurato")
        
        self.logger.info(f"Delegando task a {target_agent}: {task_description}")
        
        # Crea task di delegazione
        delegation_task = Task(
            id=str(uuid.uuid4()),
            agent_name=target_agent,
            description=task_description,
            expected_output=expected_output,
            context=context or {},
            priority=TaskPriority.HIGH  # Task delegati hanno priorità alta
        )
        
        # Richiedi delegazione all'orchestratore
        result = await self.on_delegation_request(self, delegation_task)
        
        return result
    
    def get_status(self) -> Dict[str, Any]:
        """Restituisce stato corrente dell'agente."""
        return {
            'name': self.name,
            'role': self.role,
            'is_active': self.is_active,
            'current_task': self.current_task.to_dict() if self.current_task else None,
            'metrics': self.metrics.to_dict(),
            'tools': self.tools,
            'config': {
                'model': self.config.model,
                'allow_delegation': self.config.allow_delegation,
                'max_execution_time': self.config.max_execution_time
            }
        }
    
    def activate(self):
        """Attiva l'agente."""
        self.is_active = True
        self.logger.info(f"Agente {self.name} attivato")
    
    def deactivate(self):
        """Disattiva l'agente."""
        self.is_active = False
        self.logger.info(f"Agente {self.name} disattivato")
    
    async def health_check(self) -> bool:
        """Verifica salute dell'agente."""
        try:
            if not self.is_active:
                return False
            
            if self.mistral_client:
                # Test connessione Mistral
                test_response = await self.mistral_client.simple_completion(
                    "Test di connessione. Rispondi solo 'OK'.",
                    max_tokens=10
                )
                return "OK" in test_response.upper()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Health check fallito: {e}")
            return False
    
    def clear_cache(self):
        """Pulisce cache risultati."""
        self.result_cache.clear()
        self.logger.info(f"Cache agente {self.name} pulita")
    
    def __str__(self) -> str:
        """Rappresentazione stringa dell'agente."""
        return f"{self.name} ({self.role})"
    
    def __repr__(self) -> str:
        """Rappresentazione debug dell'agente."""
        return f"BaseAgent(name='{self.name}', role='{self.role}', active={self.is_active})"


class AgentFactory:
    """Factory per creare agenti specializzati."""
    
    _agent_classes: Dict[str, type] = {}
    
    @classmethod
    def register_agent(cls, agent_name: str, agent_class: type):
        """Registra classe agente."""
        cls._agent_classes[agent_name.lower()] = agent_class
    
    @classmethod
    def create_agent(
        cls,
        agent_name: str,
        config: AgentConfig,
        mistral_client: MistralClient = None
    ) -> BaseAgent:
        """Crea istanza agente."""
        agent_class = cls._agent_classes.get(agent_name.lower())
        
        if not agent_class:
            raise ValueError(f"Classe agente {agent_name} non registrata")
        
        return agent_class(config, mistral_client)
    
    @classmethod
    def get_available_agents(cls) -> List[str]:
        """Restituisce lista agenti disponibili."""
        return list(cls._agent_classes.keys())


def agent_decorator(agent_name: str):
    """Decorator per registrare automaticamente agenti."""
    def decorator(agent_class):
        AgentFactory.register_agent(agent_name, agent_class)
        return agent_class
    return decorator


if __name__ == "__main__":
    import asyncio
    from config.mistral_config import get_agent_config
    
    # Test classe base
    class TestAgent(BaseAgent):
        async def _execute_specific_task(self, task: Task) -> Dict[str, Any]:
            # Simulazione task
            await asyncio.sleep(0.1)
            return {
                'status': 'completed',
                'message': f'Task {task.id} completato da {self.name}',
                'tokens_used': 50
            }
    
    async def test_base_agent():
        print("=== Test Base Agent ===")
        
        # Crea configurazione test
        config = get_agent_config('tech_lead')
        if not config:
            print("❌ Configurazione agente non trovata")
            return
        
        # Crea agente test
        agent = TestAgent(config)
        print(f"✅ Agente creato: {agent}")
        
        # Test health check
        healthy = await agent.health_check()
        print(f"🔍 Health check: {'✅ OK' if healthy else '❌ FAIL'}")
        
        # Test esecuzione task
        task = Task(
            id="test-001",
            agent_name=agent.name,
            description="Task di test",
            expected_output="Risultato di test"
        )
        
        try:
            result = await agent.execute_task(task)
            print(f"✅ Task completato: {result['message']}")
            
            # Mostra metriche
            status = agent.get_status()
            print(f"📊 Metriche: {status['metrics']}")
            
        except Exception as e:
            print(f"❌ Errore esecuzione task: {e}")
    
    # Esegui test
    asyncio.run(test_base_agent())

