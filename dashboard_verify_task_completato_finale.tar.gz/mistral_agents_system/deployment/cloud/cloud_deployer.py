"""
Cloud Deployer

Sistema automatico per deployment su multiple piattaforme cloud
con orchestrazione, scaling e monitoring.

Author: Manus AI
Version: v2.0
Date: 2025-01-18
"""

import asyncio
import json
import os
import subprocess
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
import logging
import yaml
from pathlib import Path


class CloudProvider(Enum):
    """Provider cloud supportati."""
    AWS = "aws"
    GOOGLE_CLOUD = "gcp"
    AZURE = "azure"
    DIGITAL_OCEAN = "digitalocean"
    HEROKU = "heroku"
    VERCEL = "vercel"
    RAILWAY = "railway"


class DeploymentType(Enum):
    """Tipi di deployment."""
    CONTAINER = "container"
    SERVERLESS = "serverless"
    KUBERNETES = "kubernetes"
    STATIC = "static"
    FULL_STACK = "full_stack"


@dataclass
class DeploymentConfig:
    """Configurazione deployment."""
    name: str
    provider: CloudProvider
    deployment_type: DeploymentType
    region: str = "us-east-1"
    instance_type: str = "small"
    auto_scaling: bool = True
    environment_vars: Dict[str, str] = field(default_factory=dict)
    custom_domain: Optional[str] = None
    ssl_enabled: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'provider': self.provider.value,
            'deployment_type': self.deployment_type.value,
            'region': self.region,
            'instance_type': self.instance_type,
            'auto_scaling': self.auto_scaling,
            'environment_vars': self.environment_vars,
            'custom_domain': self.custom_domain,
            'ssl_enabled': self.ssl_enabled
        }


@dataclass
class DeploymentResult:
    """Risultato deployment."""
    success: bool
    deployment_id: str
    url: str
    deployment_time: float
    logs: List[str] = field(default_factory=list)
    error_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'deployment_id': self.deployment_id,
            'url': self.url,
            'deployment_time': self.deployment_time,
            'logs': self.logs,
            'error_message': self.error_message
        }


class CloudDeployer:
    """
    Deployer automatico per multiple piattaforme cloud.
    
    Features:
    - Deployment automatico su AWS, GCP, Azure, etc.
    - Containerization con Docker
    - Kubernetes orchestration
    - Auto-scaling e load balancing
    - SSL e custom domains
    - Monitoring e logging
    """
    
    def __init__(self, project_root: str):
        """
        Inizializza cloud deployer.
        
        Args:
            project_root: Directory root del progetto
        """
        self.project_root = Path(project_root)
        self.logger = logging.getLogger(__name__)
        
        # Deployment configurations
        self.deployment_configs: Dict[str, DeploymentConfig] = {}
        self.active_deployments: Dict[str, Dict[str, Any]] = {}
        
        # Cloud CLI tools
        self.cli_tools = {
            CloudProvider.AWS: 'aws',
            CloudProvider.GOOGLE_CLOUD: 'gcloud',
            CloudProvider.AZURE: 'az',
            CloudProvider.HEROKU: 'heroku',
            CloudProvider.VERCEL: 'vercel',
            CloudProvider.RAILWAY: 'railway'
        }
        
        # Metriche deployment
        self.deployment_metrics = {
            'total_deployments': 0,
            'successful_deployments': 0,
            'failed_deployments': 0,
            'average_deployment_time': 0.0,
            'providers_used': {}
        }
    
    async def deploy(
        self,
        config: DeploymentConfig,
        source_path: str = None
    ) -> DeploymentResult:
        """
        Esegue deployment su cloud provider.
        
        Args:
            config: Configurazione deployment
            source_path: Path sorgenti (default: project_root)
            
        Returns:
            Risultato del deployment
        """
        start_time = time.time()
        
        if source_path is None:
            source_path = str(self.project_root)
        
        self.logger.info(f"Deployment {config.name} su {config.provider.value}")
        
        try:
            # Prepara ambiente
            await self._prepare_deployment_environment(config, source_path)
            
            # Esegui deployment specifico per provider
            if config.provider == CloudProvider.HEROKU:
                result = await self._deploy_heroku(config, source_path)
            elif config.provider == CloudProvider.VERCEL:
                result = await self._deploy_vercel(config, source_path)
            elif config.provider == CloudProvider.RAILWAY:
                result = await self._deploy_railway(config, source_path)
            elif config.provider == CloudProvider.AWS:
                result = await self._deploy_aws(config, source_path)
            elif config.provider == CloudProvider.GOOGLE_CLOUD:
                result = await self._deploy_gcp(config, source_path)
            elif config.provider == CloudProvider.AZURE:
                result = await self._deploy_azure(config, source_path)
            elif config.provider == CloudProvider.DIGITAL_OCEAN:
                result = await self._deploy_digitalocean(config, source_path)
            else:
                raise ValueError(f"Provider {config.provider} non supportato")
            
            # Aggiorna metriche
            deployment_time = time.time() - start_time
            result.deployment_time = deployment_time
            self._update_deployment_metrics(config.provider, deployment_time, result.success)
            
            # Salva deployment attivo
            if result.success:
                self.active_deployments[config.name] = {
                    'config': config.to_dict(),
                    'result': result.to_dict(),
                    'deployed_at': time.time()
                }
            
            return result
            
        except Exception as e:
            deployment_time = time.time() - start_time
            self._update_deployment_metrics(config.provider, deployment_time, False)
            
            return DeploymentResult(
                success=False,
                deployment_id="",
                url="",
                deployment_time=deployment_time,
                error_message=str(e)
            )
    
    async def _prepare_deployment_environment(self, config: DeploymentConfig, source_path: str):
        """Prepara ambiente per deployment."""
        
        source_dir = Path(source_path)
        
        # Crea Dockerfile se non esiste
        dockerfile_path = source_dir / "Dockerfile"
        if not dockerfile_path.exists() and config.deployment_type == DeploymentType.CONTAINER:
            await self._create_dockerfile(source_dir, config)
        
        # Crea docker-compose.yml se necessario
        compose_path = source_dir / "docker-compose.yml"
        if not compose_path.exists() and config.deployment_type == DeploymentType.FULL_STACK:
            await self._create_docker_compose(source_dir, config)
        
        # Crea file di configurazione cloud-specific
        await self._create_cloud_config_files(source_dir, config)
    
    async def _create_dockerfile(self, source_dir: Path, config: DeploymentConfig):
        """Crea Dockerfile ottimizzato."""
        
        dockerfile_content = f"""# Multi-stage build per ottimizzazione
FROM python:3.11-slim as builder

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    gcc \\
    g++ \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir --user -r requirements.txt

# Production stage
FROM python:3.11-slim

# Create non-root user
RUN useradd --create-home --shell /bin/bash app

# Set working directory
WORKDIR /app

# Copy Python dependencies from builder stage
COPY --from=builder /root/.local /home/app/.local

# Copy application code
COPY . .

# Change ownership to app user
RUN chown -R app:app /app

# Switch to non-root user
USER app

# Add local bin to PATH
ENV PATH=/home/app/.local/bin:$PATH

# Set environment variables
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1

# Expose port
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:8000/health || exit 1

# Start application
CMD ["python", "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
"""
        
        dockerfile_path = source_dir / "Dockerfile"
        dockerfile_path.write_text(dockerfile_content)
        
        self.logger.info(f"Dockerfile creato: {dockerfile_path}")
    
    async def _create_docker_compose(self, source_dir: Path, config: DeploymentConfig):
        """Crea docker-compose.yml per full-stack deployment."""
        
        compose_content = {
            'version': '3.8',
            'services': {
                'app': {
                    'build': '.',
                    'ports': ['8000:8000'],
                    'environment': config.environment_vars,
                    'depends_on': ['redis', 'postgres'],
                    'restart': 'unless-stopped'
                },
                'redis': {
                    'image': 'redis:7-alpine',
                    'ports': ['6379:6379'],
                    'restart': 'unless-stopped'
                },
                'postgres': {
                    'image': 'postgres:15-alpine',
                    'environment': {
                        'POSTGRES_DB': 'mistral_agents',
                        'POSTGRES_USER': 'postgres',
                        'POSTGRES_PASSWORD': 'password'
                    },
                    'ports': ['5432:5432'],
                    'volumes': ['postgres_data:/var/lib/postgresql/data'],
                    'restart': 'unless-stopped'
                }
            },
            'volumes': {
                'postgres_data': {}
            }
        }
        
        compose_path = source_dir / "docker-compose.yml"
        with open(compose_path, 'w') as f:
            yaml.dump(compose_content, f, default_flow_style=False)
        
        self.logger.info(f"docker-compose.yml creato: {compose_path}")
    
    async def _create_cloud_config_files(self, source_dir: Path, config: DeploymentConfig):
        """Crea file di configurazione specifici per cloud provider."""
        
        if config.provider == CloudProvider.HEROKU:
            # Procfile per Heroku
            procfile_content = "web: python -m uvicorn main:app --host 0.0.0.0 --port $PORT"
            (source_dir / "Procfile").write_text(procfile_content)
            
            # app.json per Heroku
            app_json = {
                "name": config.name,
                "description": "Mistral AI Agents System",
                "image": "heroku/python",
                "addons": ["heroku-postgresql", "heroku-redis"],
                "env": {key: {"required": True} for key in config.environment_vars.keys()}
            }
            
            with open(source_dir / "app.json", 'w') as f:
                json.dump(app_json, f, indent=2)
        
        elif config.provider == CloudProvider.VERCEL:
            # vercel.json per Vercel
            vercel_config = {
                "version": 2,
                "builds": [
                    {"src": "main.py", "use": "@vercel/python"}
                ],
                "routes": [
                    {"src": "/(.*)", "dest": "main.py"}
                ],
                "env": config.environment_vars
            }
            
            with open(source_dir / "vercel.json", 'w') as f:
                json.dump(vercel_config, f, indent=2)
        
        elif config.provider == CloudProvider.AWS:
            # Elastic Beanstalk configuration
            eb_config_dir = source_dir / ".ebextensions"
            eb_config_dir.mkdir(exist_ok=True)
            
            eb_config = {
                "option_settings": {
                    "aws:elasticbeanstalk:container:python": {
                        "WSGIPath": "main.py"
                    },
                    "aws:elasticbeanstalk:application:environment": config.environment_vars
                }
            }
            
            with open(eb_config_dir / "python.config", 'w') as f:
                yaml.dump(eb_config, f)
    
    async def _deploy_heroku(self, config: DeploymentConfig, source_path: str) -> DeploymentResult:
        """Deploy su Heroku."""
        
        logs = []
        
        try:
            # Verifica Heroku CLI
            result = await self._run_command("heroku --version")
            if result.returncode != 0:
                raise RuntimeError("Heroku CLI non installato")
            
            # Login check
            result = await self._run_command("heroku auth:whoami")
            if result.returncode != 0:
                logs.append("Heroku login richiesto: heroku login")
                raise RuntimeError("Heroku login richiesto")
            
            # Crea app Heroku
            app_name = config.name.lower().replace('_', '-')
            create_cmd = f"heroku create {app_name} --region {config.region}"
            result = await self._run_command(create_cmd, cwd=source_path)
            
            if result.returncode == 0:
                logs.append(f"App Heroku creata: {app_name}")
            else:
                logs.append("App potrebbe già esistere, continuo...")
            
            # Set environment variables
            for key, value in config.environment_vars.items():
                env_cmd = f"heroku config:set {key}={value} --app {app_name}"
                await self._run_command(env_cmd, cwd=source_path)
            
            logs.append("Environment variables configurate")
            
            # Deploy con Git
            git_commands = [
                "git init",
                "git add .",
                "git commit -m 'Initial deployment'",
                f"heroku git:remote --app {app_name}",
                "git push heroku main"
            ]
            
            for cmd in git_commands:
                result = await self._run_command(cmd, cwd=source_path)
                if result.returncode != 0 and "git push" in cmd:
                    # Retry con master branch
                    result = await self._run_command("git push heroku master", cwd=source_path)
            
            if result.returncode == 0:
                logs.append("Deployment completato")
                
                return DeploymentResult(
                    success=True,
                    deployment_id=app_name,
                    url=f"https://{app_name}.herokuapp.com",
                    deployment_time=0.0,
                    logs=logs
                )
            else:
                raise RuntimeError("Git push fallito")
                
        except Exception as e:
            return DeploymentResult(
                success=False,
                deployment_id="",
                url="",
                deployment_time=0.0,
                logs=logs,
                error_message=str(e)
            )
    
    async def _deploy_vercel(self, config: DeploymentConfig, source_path: str) -> DeploymentResult:
        """Deploy su Vercel."""
        
        logs = []
        
        try:
            # Verifica Vercel CLI
            result = await self._run_command("vercel --version")
            if result.returncode != 0:
                raise RuntimeError("Vercel CLI non installato")
            
            # Deploy
            deploy_cmd = f"vercel --prod --yes --name {config.name}"
            result = await self._run_command(deploy_cmd, cwd=source_path)
            
            if result.returncode == 0:
                logs.append("Deployment Vercel completato")
                
                # Estrai URL dal output (semplificato)
                deployment_url = f"https://{config.name}.vercel.app"
                
                return DeploymentResult(
                    success=True,
                    deployment_id=config.name,
                    url=deployment_url,
                    deployment_time=0.0,
                    logs=logs
                )
            else:
                raise RuntimeError("Vercel deployment fallito")
                
        except Exception as e:
            return DeploymentResult(
                success=False,
                deployment_id="",
                url="",
                deployment_time=0.0,
                logs=logs,
                error_message=str(e)
            )
    
    async def _deploy_railway(self, config: DeploymentConfig, source_path: str) -> DeploymentResult:
        """Deploy su Railway."""
        
        logs = []
        
        try:
            # Verifica Railway CLI
            result = await self._run_command("railway --version")
            if result.returncode != 0:
                raise RuntimeError("Railway CLI non installato")
            
            # Login check
            result = await self._run_command("railway whoami")
            if result.returncode != 0:
                logs.append("Railway login richiesto: railway login")
                raise RuntimeError("Railway login richiesto")
            
            # Inizializza progetto
            init_cmd = f"railway init {config.name}"
            await self._run_command(init_cmd, cwd=source_path)
            
            # Set environment variables
            for key, value in config.environment_vars.items():
                env_cmd = f"railway variables set {key}={value}"
                await self._run_command(env_cmd, cwd=source_path)
            
            # Deploy
            deploy_cmd = "railway up"
            result = await self._run_command(deploy_cmd, cwd=source_path)
            
            if result.returncode == 0:
                logs.append("Deployment Railway completato")
                
                # Ottieni URL
                url_result = await self._run_command("railway domain", cwd=source_path)
                deployment_url = url_result.stdout.strip() if url_result.stdout else f"https://{config.name}.railway.app"
                
                return DeploymentResult(
                    success=True,
                    deployment_id=config.name,
                    url=deployment_url,
                    deployment_time=0.0,
                    logs=logs
                )
            else:
                raise RuntimeError("Railway deployment fallito")
                
        except Exception as e:
            return DeploymentResult(
                success=False,
                deployment_id="",
                url="",
                deployment_time=0.0,
                logs=logs,
                error_message=str(e)
            )
    
    async def _deploy_aws(self, config: DeploymentConfig, source_path: str) -> DeploymentResult:
        """Deploy su AWS (Elastic Beanstalk)."""
        
        logs = []
        
        try:
            # Verifica AWS CLI
            result = await self._run_command("aws --version")
            if result.returncode != 0:
                raise RuntimeError("AWS CLI non installato")
            
            # Verifica EB CLI
            result = await self._run_command("eb --version")
            if result.returncode != 0:
                raise RuntimeError("EB CLI non installato")
            
            # Inizializza EB
            eb_init_cmd = f"eb init {config.name} --platform python-3.11 --region {config.region}"
            await self._run_command(eb_init_cmd, cwd=source_path)
            
            # Crea environment
            eb_create_cmd = f"eb create {config.name}-env --instance-type {config.instance_type}"
            result = await self._run_command(eb_create_cmd, cwd=source_path)
            
            if result.returncode == 0:
                logs.append("AWS Elastic Beanstalk deployment completato")
                
                # Ottieni URL
                url_result = await self._run_command("eb status", cwd=source_path)
                deployment_url = f"http://{config.name}-env.{config.region}.elasticbeanstalk.com"
                
                return DeploymentResult(
                    success=True,
                    deployment_id=f"{config.name}-env",
                    url=deployment_url,
                    deployment_time=0.0,
                    logs=logs
                )
            else:
                raise RuntimeError("AWS deployment fallito")
                
        except Exception as e:
            return DeploymentResult(
                success=False,
                deployment_id="",
                url="",
                deployment_time=0.0,
                logs=logs,
                error_message=str(e)
            )
    
    async def _deploy_gcp(self, config: DeploymentConfig, source_path: str) -> DeploymentResult:
        """Deploy su Google Cloud Platform."""
        
        # Implementazione semplificata per demo
        return DeploymentResult(
            success=False,
            deployment_id="",
            url="",
            deployment_time=0.0,
            error_message="GCP deployment non ancora implementato"
        )
    
    async def _deploy_azure(self, config: DeploymentConfig, source_path: str) -> DeploymentResult:
        """Deploy su Microsoft Azure."""
        
        # Implementazione semplificata per demo
        return DeploymentResult(
            success=False,
            deployment_id="",
            url="",
            deployment_time=0.0,
            error_message="Azure deployment non ancora implementato"
        )
    
    async def _deploy_digitalocean(self, config: DeploymentConfig, source_path: str) -> DeploymentResult:
        """Deploy su DigitalOcean."""
        
        # Implementazione semplificata per demo
        return DeploymentResult(
            success=False,
            deployment_id="",
            url="",
            deployment_time=0.0,
            error_message="DigitalOcean deployment non ancora implementato"
        )
    
    async def _run_command(self, command: str, cwd: str = None) -> subprocess.CompletedProcess:
        """Esegue comando shell."""
        
        self.logger.debug(f"Esecuzione comando: {command}")
        
        process = await asyncio.create_subprocess_shell(
            command,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        return subprocess.CompletedProcess(
            args=command,
            returncode=process.returncode,
            stdout=stdout.decode() if stdout else "",
            stderr=stderr.decode() if stderr else ""
        )
    
    def _update_deployment_metrics(
        self,
        provider: CloudProvider,
        deployment_time: float,
        success: bool
    ):
        """Aggiorna metriche deployment."""
        
        self.deployment_metrics['total_deployments'] += 1
        
        if success:
            self.deployment_metrics['successful_deployments'] += 1
        else:
            self.deployment_metrics['failed_deployments'] += 1
        
        # Aggiorna tempo medio
        total = self.deployment_metrics['total_deployments']
        current_avg = self.deployment_metrics['average_deployment_time']
        self.deployment_metrics['average_deployment_time'] = (
            (current_avg * (total - 1) + deployment_time) / total
        )
        
        # Aggiorna statistiche provider
        provider_key = provider.value
        if provider_key not in self.deployment_metrics['providers_used']:
            self.deployment_metrics['providers_used'][provider_key] = 0
        self.deployment_metrics['providers_used'][provider_key] += 1
    
    async def undeploy(self, deployment_name: str) -> bool:
        """
        Rimuove deployment.
        
        Args:
            deployment_name: Nome del deployment
            
        Returns:
            True se rimozione riuscita
        """
        if deployment_name not in self.active_deployments:
            return False
        
        deployment_info = self.active_deployments[deployment_name]
        config = DeploymentConfig(**deployment_info['config'])
        
        try:
            if config.provider == CloudProvider.HEROKU:
                await self._run_command(f"heroku apps:destroy {deployment_name} --confirm {deployment_name}")
            elif config.provider == CloudProvider.VERCEL:
                await self._run_command(f"vercel remove {deployment_name} --yes")
            elif config.provider == CloudProvider.RAILWAY:
                await self._run_command(f"railway delete --yes")
            
            # Rimuovi da deployments attivi
            del self.active_deployments[deployment_name]
            
            self.logger.info(f"Deployment {deployment_name} rimosso")
            return True
            
        except Exception as e:
            self.logger.error(f"Errore rimozione deployment {deployment_name}: {e}")
            return False
    
    def get_active_deployments(self) -> Dict[str, Dict[str, Any]]:
        """Restituisce deployments attivi."""
        return self.active_deployments.copy()
    
    def get_deployment_metrics(self) -> Dict[str, Any]:
        """Restituisce metriche deployment."""
        return self.deployment_metrics.copy()
    
    async def health_check_deployment(self, deployment_name: str) -> Dict[str, Any]:
        """
        Controlla salute di un deployment.
        
        Args:
            deployment_name: Nome del deployment
            
        Returns:
            Stato salute del deployment
        """
        if deployment_name not in self.active_deployments:
            return {'status': 'not_found'}
        
        deployment_info = self.active_deployments[deployment_name]
        url = deployment_info['result']['url']
        
        try:
            import aiohttp
            
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{url}/health", timeout=10) as response:
                    if response.status == 200:
                        return {
                            'status': 'healthy',
                            'response_time': response.headers.get('X-Response-Time', 'unknown'),
                            'last_check': time.time()
                        }
                    else:
                        return {
                            'status': 'unhealthy',
                            'status_code': response.status,
                            'last_check': time.time()
                        }
                        
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e),
                'last_check': time.time()
            }


# Factory function
def create_cloud_deployer(project_root: str) -> CloudDeployer:
    """Crea istanza Cloud Deployer."""
    return CloudDeployer(project_root)


# Predefined deployment configurations
def get_predefined_deployment_configs() -> Dict[str, DeploymentConfig]:
    """Restituisce configurazioni deployment predefinite."""
    
    return {
        'heroku_production': DeploymentConfig(
            name='mistral-agents-prod',
            provider=CloudProvider.HEROKU,
            deployment_type=DeploymentType.CONTAINER,
            region='us',
            instance_type='standard-1x',
            auto_scaling=True,
            environment_vars={
                'MISTRAL_API_KEY': 'gJ200l66zgUiRZcUji9Sbr0bz8H8ALwz',
                'ENVIRONMENT': 'production',
                'LOG_LEVEL': 'INFO'
            },
            ssl_enabled=True
        ),
        
        'vercel_frontend': DeploymentConfig(
            name='mistral-agents-ui',
            provider=CloudProvider.VERCEL,
            deployment_type=DeploymentType.STATIC,
            region='iad1',
            auto_scaling=True,
            environment_vars={
                'NEXT_PUBLIC_API_URL': 'https://mistral-agents-prod.herokuapp.com'
            },
            ssl_enabled=True
        ),
        
        'railway_api': DeploymentConfig(
            name='mistral-agents-api',
            provider=CloudProvider.RAILWAY,
            deployment_type=DeploymentType.CONTAINER,
            region='us-west1',
            auto_scaling=True,
            environment_vars={
                'MISTRAL_API_KEY': 'gJ200l66zgUiRZcUji9Sbr0bz8H8ALwz',
                'DATABASE_URL': 'postgresql://...',
                'REDIS_URL': 'redis://...'
            },
            ssl_enabled=True
        )
    }


if __name__ == "__main__":
    import asyncio
    
    async def test_cloud_deployer():
        """Test del Cloud Deployer."""
        print("=== Test Cloud Deployer ===")
        
        deployer = create_cloud_deployer("/tmp/test_project")
        
        # Test configurazioni predefinite
        configs = get_predefined_deployment_configs()
        print(f"📋 Configurazioni predefinite: {len(configs)}")
        
        for name, config in configs.items():
            print(f"   - {name}: {config.provider.value} ({config.deployment_type.value})")
        
        # Test preparazione ambiente (simulato)
        print("\n🔧 Test preparazione ambiente...")
        
        # Simula deployment (senza eseguire realmente)
        print("\n🚀 Test deployment simulato...")
        
        test_config = DeploymentConfig(
            name='test-deployment',
            provider=CloudProvider.HEROKU,
            deployment_type=DeploymentType.CONTAINER
        )
        
        print(f"   Config: {test_config.name} su {test_config.provider.value}")
        print(f"   Tipo: {test_config.deployment_type.value}")
        
        # Mostra metriche
        print("\n📊 Metriche:")
        metrics = deployer.get_deployment_metrics()
        for key, value in metrics.items():
            print(f"   {key}: {value}")
    
    # Esegui test
    asyncio.run(test_cloud_deployer())

